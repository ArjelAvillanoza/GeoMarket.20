import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Box, Button, Divider, FormControl, InputLabel, MenuItem, Select,
  Stack, TextField, Typography, IconButton, Alert, Paper, Tooltip, InputAdornment
} from "@mui/material";
import { Stage, Layer, Rect, Circle, Line, Text, Group, Image as KonvaImage, Transformer } from "react-konva";
import useImage from "use-image";
import { v4 as uuidv4 } from "uuid";
import mapLayoutApi from "../../api/mapLayoutApi";
import { resolveImageUrl } from "../../utils/url";
import AddIcon from "@mui/icons-material/Add";
import RemoveIcon from "@mui/icons-material/Remove";
import FitScreenIcon from "@mui/icons-material/FitScreen";
import ZoomOutMapIcon from "@mui/icons-material/ZoomOutMap";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import OpenInNewIcon from "@mui/icons-material/OpenInNew";
import DownloadIcon from "@mui/icons-material/Download";
import QrCode2Icon from "@mui/icons-material/QrCode2";
import Street360Viewer from "./Street360Viewer";
import userApi from "../../api/userApi";
import stallApi from "../../api/stallApi";

const TOOL = {
  SELECT: "select",
  PAN: "pan",
  STALL: "stall",
  ENTRANCE: "entrance",
  NODE: "node",
  EDGE: "edge",
  STREET: "street",
};

const SHAPE_KEYS = {
  stall: "stalls",
  entrance: "entrances",
  node: "pathNodes",
  street: "streetViews",
};

const STATUS_COLORS = {
  vacant: "#2196f3",
  delinquent: "#e53935",
  promissory: "#fb8c00",
  no_permit: "#43a047",
  occupied: "#90a4ae",
};

const SID = (type, id) => `${type}:${id}`;
const parseSID = (sid) => { const i = sid.indexOf(":"); return { type: sid.slice(0, i), id: sid.slice(i + 1) }; };

function incrementText (s = "", n = 1) {
  const m = s.match(/^(.*?)(\d+)\s*$/);
  if (m) {
    const base = s.slice(0, m.index) + m[1];
    const num = parseInt(m[2], 10) + n;
    return `${base}${num}`;
  }
  if (/-$/.test(s)) return `${s}${n}`;
  if (s.includes("-")) return `${s}-${n}`;
  return s ? `${s} ${n}` : s;
}

export default function MapEditor ({ layout, onChange, onSave }) {
  const stageRef = useRef(null);
  const scrollRef = useRef(null);
  const stallNodeRefs = useRef({});
  const stallTrRef = useRef(null);
  const [bgImage] = useImage(resolveImageUrl(layout.backgroundImage || ""), "anonymous");

  const [tool, setTool] = useState(TOOL.SELECT);
  const [tempPan, setTempPan] = useState(false);
  const [isPanning, setIsPanning] = useState(false);
  const [scale, setScale] = useState(1);

  const [selection, setSelection] = useState(new Set());
  const [marquee, setMarquee] = useState(null);

  // ---- NEW: street image upload UI state ----
  const fileInputRef = useRef(null);
  const [streetUploadTargetId, setStreetUploadTargetId] = useState(null);
  // ------------------------------------------

  const size = layout.size || { width: 1600, height: 1200, grid: 10 };
  const setLayout = (next) => onChange({ ...next, updatedAt: new Date().toISOString() });

  const activeTool = tempPan ? TOOL.PAN : tool;
  const snap = useCallback((v) => Math.round(v / size.grid) * size.grid, [size.grid]);
  const clearSelection = () => setSelection(new Set());

  const isMulti = selection.size > 1;
  const isNone = selection.size === 0;
  const isSingle = selection.size === 1;
  const singleSel = useMemo(() => {
    if (!isSingle) return null;
    return parseSID([...selection][0]);
  }, [selection, isSingle]);

  const arrFor = (type) => layout[SHAPE_KEYS[type]] || [];

  const [route, setRoute] = useState(null);
  const entrances = layout.entrances || [];
  const stalls = layout.stalls || [];

  const [vendors, setVendors] = useState([]);
  const [loadingVendors, setLoadingVendors] = useState(false);

  async function findRoute ({ fromEntranceId, toStallId }) {
    try {
      const res = await mapLayoutApi.getDirections(layout._id, {
        fromType: "entrance",
        fromId: fromEntranceId,
        toType: "stall",
        toId: toStallId,
      });
      setRoute(res.data);
    } catch (e) {
      console.error(e);
      alert(e?.response?.data?.message || "Failed to compute route");
    }
  }

  const updateShape = (type, id, patch) => {
    const key = SHAPE_KEYS[type];
    const nextArr = (layout[key] || []).map((o) => (o.id === id ? { ...o, ...patch } : o));
    setLayout({ ...layout, [key]: nextArr });
  };
  const updateMany = (type, ids, patchOrFn) => {
    const key = SHAPE_KEYS[type];
    const nextArr = (layout[key] || []).map((o) => {
      if (!ids.includes(o.id)) return o;
      const patch = typeof patchOrFn === "function" ? patchOrFn(o) : patchOrFn;
      return { ...o, ...patch };
    });
    setLayout({ ...layout, [key]: nextArr });
  };

  // hotkeys + selection
  useEffect(() => {
    const onKeyDown = (e) => {
      const tag = (e.target instanceof HTMLElement ? e.target.tagName : "").toLowerCase();
      if (tag === "input" || tag === "textarea" || (e.target?.isContentEditable)) return;

      if (e.code === "Space" && !e.repeat) { setTempPan(true); e.preventDefault(); return; }
      const cmd = e.ctrlKey || e.metaKey;

      if (cmd && e.key.toLowerCase() === "a") {
        e.preventDefault();
        const all = new Set();
        for (const t of Object.keys(SHAPE_KEYS)) for (const it of arrFor(t)) all.add(SID(t, it.id));
        setSelection(all);
        return;
      }
      if (cmd && e.key.toLowerCase() === "c") { e.preventDefault(); copySelectionToClipboard(); return; }
      if (cmd && e.key.toLowerCase() === "v") { e.preventDefault(); pasteFromClipboard(); return; }
      if (e.key === "Delete" || e.key === "Backspace") { e.preventDefault(); deleteSelection(); return; }

      if (selection.size > 0 && ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key)) {
        e.preventDefault();
        const step = e.shiftKey ? size.grid : 1;
        let dx = 0, dy = 0;
        if (e.key === "ArrowLeft") dx = -step;
        if (e.key === "ArrowRight") dx = step;
        if (e.key === "ArrowUp") dy = -step;
        if (e.key === "ArrowDown") dy = step;

        const byType = {};
        for (const sid of selection) {
          const { type, id } = parseSID(sid);
          (byType[type] ||= []).push(id);
        }
        Object.entries(byType).forEach(([type, ids]) => {
          if (!["stall", "entrance", "node", "street", "boundary", "label"].includes(type)) return;
          updateMany(type, ids, (o) => {
            const nx = (o.x ?? 0) + dx;
            const ny = (o.y ?? 0) + dy;
            return e.shiftKey ? { x: snap(nx), y: snap(ny) } : { x: nx, y: ny };
          });
        });
      }
    };
    const onKeyUp = (e) => { if (e.code === "Space") { setTempPan(false); e.preventDefault(); } };
    window.addEventListener("keydown", onKeyDown, { passive: false });
    window.addEventListener("keyup", onKeyUp, { passive: false });
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
    };
  }, [selection, layout, size.grid, snap]);

  useEffect(() => {
    if (singleSel?.type !== "stall") return;
    const node = stallNodeRefs.current[singleSel.id];
    const tr = stallTrRef.current;
    if (node && tr) { tr.nodes([node]); tr.getLayer()?.batchDraw(); }
  }, [singleSel]);

  useEffect(() => {
    if (singleSel?.type !== "stall") return;
    (async () => {
      setLoadingVendors(true);
      try {
        const res = await userApi.getUsers();
        setVendors(res.data.filter((u) => u.role === "vendor"));
      } catch (err) { console.error("Failed to load vendors:", err); }
      finally { setLoadingVendors(false); }
    })();
  }, [singleSel]);

  const handleAssignVendor = async (vendorId) => {
    if (!singleSel || singleSel.type !== "stall") return;
    try {
      await stallApi.assignVendor(singleSel.id, vendorId);
      updateShape("stall", singleSel.id, {
        meta: { ...(layout.stalls.find(s => s.id === singleSel.id)?.meta || {}), vendorId },
        status: vendorId ? "occupied" : "vacant",
        fill: vendorId ? "#90a4ae" : STATUS_COLORS.vacant,
      });
      alert("Vendor assignment updated!");
    } catch (err) {
      console.error("Vendor assignment failed:", err);
      alert("Failed to assign vendor. " + (err?.response?.data?.message || err.message));
    }
  };

  const [gen, setGen] = useState({ x: 40, y: 40, count: 6, w: 60, h: 40, gap: 8, prefix: "" });

  const createStallsRow = (x, y, count, w, h, gap, prefix = "") =>
    Array.from({ length: count }, (_, i) => ({
      id: uuidv4(), name: `${prefix}${i + 1}`, label: `${i + 1}`,
      x: snap(x + i * (w + gap)), y: snap(y),
      width: w, height: h, rotation: 0,
      fill: STATUS_COLORS.occupied, status: "occupied", meta: {},
    }));

  const createStallsColumn = (x, y, count, w, h, gap, prefix = "") =>
    Array.from({ length: count }, (_, i) => ({
      id: uuidv4(), name: `${prefix}${i + 1}`, label: `${i + 1}`,
      x: snap(x), y: snap(y + i * (h + gap)),
      width: w, height: h, rotation: 0,
      fill: STATUS_COLORS.occupied, status: "occupied", meta: {},
    }));

  const addRow = () => setLayout({ ...layout, stalls: [...layout.stalls, ...createStallsRow(gen.x, gen.y, gen.count, gen.w, gen.h, gen.gap, gen.prefix)] });
  const addColumn = () => setLayout({ ...layout, stalls: [...layout.stalls, ...createStallsColumn(gen.x, gen.y, gen.count, gen.w, gen.h, gen.gap, gen.prefix)] });

  function bboxOf (type, obj) {
    switch (type) {
      case "stall": return { x: obj.x, y: obj.y, w: obj.width, h: obj.height };
      case "boundary": return { x: obj.x, y: obj.y, w: obj.width || 0, h: obj.height || 0 };
      case "entrance": return { x: obj.x - (obj.radius || 10), y: obj.y - (obj.radius || 10), w: 2 * (obj.radius || 10), h: 2 * (obj.radius || 10) };
      case "node": return { x: obj.x - 4, y: obj.y - 4, w: 8, h: 8 };
      case "street": return { x: obj.x - 6, y: obj.y - 6, w: 12, h: 12 };
      case "label": return { x: obj.x - 2, y: obj.y - 10, w: 80, h: 20 };
      default: return { x: obj.x || 0, y: obj.y || 0, w: 0, h: 0 };
    }
  }
  function rectsIntersect (a, b) { return !(a.x + a.w < b.x || b.x + b.w < a.x || a.y + a.h < b.y || b.y + b.h < a.y); }

  // ---- NEW: street upload helpers ----
  const triggerStreetUpload = (streetId) => {
    setStreetUploadTargetId(streetId);
    setTimeout(() => fileInputRef.current?.click(), 0);
  };

  const pollStreetStatus = async (pinId) => {
    try {
      const st = await mapLayoutApi.streetStatus(layout._id, pinId);
      if (st.data.status === "ready") {
        updateShape("street", pinId, {
          status: "ready",
          imagePath: st.data.imagePath,
          sourceImagePath: st.data.sourceImagePath,
          error: "",
        });
        return "ready";
      }
      if (st.data.status === "error") {
        updateShape("street", pinId, {
          status: "error",
          imagePath: st.data.imagePath,
          sourceImagePath: st.data.sourceImagePath,
          error: st.data.error || "Unknown error",
        });
        return "error";
      }
      // still processing
      return "processing";
    } catch {
      return "error";
    }
  };

  const handleStreetFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file || !streetUploadTargetId) return;
    try {
      const res = await mapLayoutApi.uploadStreetView(layout._id, streetUploadTargetId, file);
      // move to processing
      updateShape("street", streetUploadTargetId, {
        status: "processing",
        sourceImagePath: res?.data?.sourceImagePath || "",
        error: "",
      });
      setSelection(new Set([SID("street", streetUploadTargetId)]));

      // Poll
      let tries = 0;
      const timer = setInterval(async () => {
        const s = await pollStreetStatus(streetUploadTargetId);
        if (s === "ready" || s === "error" || ++tries > 120) clearInterval(timer);
      }, 2000);
    } catch (err) {
      console.error(err);
      alert("Failed to upload image. " + (err?.response?.data?.message || err.message));
    } finally {
      e.target.value = "";
      setStreetUploadTargetId(null);
    }
  };
  // --------------------------------------

  const handleStageMouseDown = (e) => {
    if (activeTool === TOOL.PAN) { setIsPanning(true); return; }
    if (activeTool === TOOL.SELECT && e.target === e.target.getStage()) {
      const p = stageRef.current?.getPointerPosition();
      if (!p) return;
      setMarquee({ x1: p.x, y1: p.y, x2: p.x, y2: p.y });
    }
  };
  const handleStageMouseMove = (e) => {
    if (isPanning && activeTool === TOOL.PAN) {
      const stage = stageRef.current;
      stage.x(stage.x() + e.evt.movementX);
      stage.y(stage.y() + e.evt.movementY);
      stage.batchDraw();
      return;
    }
    if (marquee && activeTool === TOOL.SELECT) {
      const p = stageRef.current?.getPointerPosition();
      if (!p) return;
      setMarquee((m) => ({ ...m, x2: p.x, y2: p.y }));
    }
  };
  const handleStageMouseUp = () => {
    if (isPanning) setIsPanning(false);
    if (marquee) {
      const { x1, y1, x2, y2 } = marquee;
      const mx = Math.min(x1, x2), my = Math.min(y1, y2);
      const mw = Math.abs(x2 - x1), mh = Math.abs(y2 - y1);
      const box = { x: mx, y: my, w: mw, h: mh };
      const next = new Set(selection);
      for (const type of Object.keys(SHAPE_KEYS)) {
        for (const obj of arrFor(type)) {
          const bb = bboxOf(type, obj);
          if (rectsIntersect(box, bb)) next.add(SID(type, obj.id));
        }
      }
      setSelection(next);
      setMarquee(null);
    }
  };
  const clickShape = (type, id, ev) => {
    ev.cancelBubble = true;
    const mod = ev.evt.ctrlKey || ev.evt.metaKey || ev.evt.shiftKey;
    if (mod) {
      const key = SID(type, id);
      const next = new Set(selection);
      if (next.has(key)) next.delete(key); else next.add(key);
      setSelection(next);
    } else {
      setSelection(new Set([SID(type, id)]));
    }
  };

  const handleWheel = (e) => {
    if (e.evt.ctrlKey || e.evt.metaKey) {
      e.evt.preventDefault();
      const stage = stageRef.current;
      const scaleBy = 1.08;
      const oldScale = scale;
      const pointer = stage.getPointerPosition();
      const newScale = e.evt.deltaY > 0 ? oldScale / scaleBy : oldScale * scaleBy;
      const mousePointTo = { x: (pointer.x - stage.x()) / oldScale, y: (pointer.y - stage.y()) / oldScale };
      setScale(newScale);
      stage.scale({ x: newScale, y: newScale });
      stage.position({ x: pointer.x - mousePointTo.x * newScale, y: pointer.y - mousePointTo.y * newScale });
      stage.batchDraw();
    }
  };

  const handleStageClick = async (e) => {
    if (activeTool === TOOL.PAN) return;
    if (e.target !== e.target.getStage()) return;
    const stage = stageRef.current;
    const pos = stage?.getPointerPosition();
    if (!pos) return;

    const add = (type, obj) => {
      const key = SHAPE_KEYS[type];
      const next = { ...layout, [key]: [...(layout[key] || []), obj] };
      setLayout(next);
      setSelection(new Set([SID(type, obj.id)]));
    };

    if (tool === TOOL.STALL) {
      const id = uuidv4();
      add("stall", {
        id, name: `Stall ${layout.stalls.length + 1}`, label: "1",
        x: snap(pos.x), y: snap(pos.y), width: 60, height: 40, rotation: 0,
        fill: STATUS_COLORS.occupied, status: "occupied", meta: {},
      });
      return;
    }
    if (tool === TOOL.ENTRANCE) {
      const id = uuidv4();
      const ent = { id, name: `Entrance ${layout.entrances.length + 1}`, x: snap(pos.x), y: snap(pos.y), radius: 10, qrPublicUrl: "", qrImagePath: "" };
      const nextLayout = { ...layout, entrances: [...layout.entrances, ent] };
      setLayout(nextLayout);
      setSelection(new Set([SID("entrance", id)]));
      try { await mapLayoutApi.update(layout._id, { ...nextLayout, updatedAt: undefined }); } catch { }
      return;
    }
    if (tool === TOOL.NODE) {
      const id = uuidv4();
      add("node", { id, x: snap(pos.x), y: snap(pos.y) });
      return;
    }
    if (tool === TOOL.STREET) {
      const id = uuidv4();
      const pin = { id, x: snap(pos.x), y: snap(pos.y), title: "Street View", imagePath: "", sourceImagePath: "", status: "idle", error: "" };
      const nextLayout = { ...layout, streetViews: [...(layout.streetViews || []), pin] };
      setLayout(nextLayout);
      setSelection(new Set([SID("street", id)]));
      try {
        await mapLayoutApi.update(layout._id, { ...nextLayout, updatedAt: undefined });
        triggerStreetUpload(id);
      } catch (err) {
        console.error("Auto-save street pin failed:", err);
        alert("Failed to save the new street pin. Please try again.");
      }
      return;
    }
    if (tool === TOOL.BOUNDARY) {
      const id = uuidv4();
      add("boundary", { id, x: snap(pos.x), y: snap(pos.y), width: 200, height: 60 });
      return;
    }
    if (tool === TOOL.LABEL) {
      const id = uuidv4();
      add("label", { id, x: snap(pos.x), y: snap(pos.y), text: "BLOCK X - DRT", fontSize: 16 });
      return;
    }
    clearSelection();
  };

  const removeBySet = (set) => {
    let next = { ...layout };
    for (const sid of set) {
      const { type, id } = parseSID(sid);
      const key = SHAPE_KEYS[type];
      next[key] = (next[key] || []).filter((x) => x.id !== id);
      if (type === "node") next.pathEdges = (next.pathEdges || []).filter((e) => e.from !== id && e.to !== id);
    }
    setLayout(next);
  };
  const deleteSelection = () => { if (selection.size === 0) return; removeBySet(selection); clearSelection(); };

  const clipboardRef = useRef(null);
  const copySelectionToClipboard = () => {
    if (selection.size === 0) return;
    const items = [];
    let minX = Infinity, minY = Infinity;
    for (const sid of selection) {
      const { type, id } = parseSID(sid);
      const key = SHAPE_KEYS[type];
      const obj = (layout[key] || []).find((x) => x.id === id);
      if (!obj) continue;
      const bb = bboxOf(type, obj);
      minX = Math.min(minX, bb.x); minY = Math.min(minY, bb.y);
      items.push({ type, obj });
    }
    clipboardRef.current = { items, anchor: { x: minX, y: minY }, count: 0 };
  };
  const pasteFromClipboard = () => {
    if (!clipboardRef.current) return;
    const { items } = clipboardRef.current;
    clipboardRef.current.count += 1;
    const n = clipboardRef.current.count;
    const dx = 20 * n, dy = 20 * n;

    const next = { ...layout };
    const newSelection = new Set();

    for (const { type, obj } of items) {
      const key = SHAPE_KEYS[type];
      const clone = JSON.parse(JSON.stringify(obj));
      clone.id = uuidv4();
      if (["stall", "entrance", "node", "street", "boundary", "label"].includes(type)) {
        clone.x = snap((clone.x ?? 0) + dx);
        clone.y = snap((clone.y ?? 0) + dy);
      }
      if (type === "stall") {
        if (clone.name) clone.name = incrementText(clone.name, n);
        if (clone.label) clone.label = incrementText(clone.label, n);
      }
      if (type === "label" && clone.text) clone.text = incrementText(clone.text, n);
      if (type === "entrance") { if (clone.name) clone.name = incrementText(clone.name, n); clone.qrPublicUrl = ""; clone.qrImagePath = ""; }
      next[key] = [...(next[key] || []), clone];
      newSelection.add(SID(type, clone.id));
    }
    setLayout(next);
    setSelection(newSelection);
  };

  const [edgeDraft, setEdgeDraft] = useState(null);
  const onNodeClick = (node, ev) => {
    ev.cancelBubble = true;
    if (tool !== TOOL.EDGE) { clickShape("node", node.id, ev); return; }
    if (!edgeDraft) { setEdgeDraft(node); setSelection(new Set([SID("node", node.id)])); }
    else {
      const id = uuidv4();
      const newEdge = { id, from: edgeDraft.id, to: node.id, weight: 1, walkable: true };
      setLayout({ ...layout, pathEdges: [...(layout.pathEdges || []), newEdge] });
      setEdgeDraft(null);
    }
  };

  const selectedObj = useMemo(() => {
    if (!singleSel) return null;
    const key = SHAPE_KEYS[singleSel.type];
    return (layout[key] || []).find((x) => x.id === singleSel.id) || null;
  }, [singleSel, layout]);

  const patchSelected = (patch) => { if (!singleSel) return; updateShape(singleSel.type, singleSel.id, patch); };

  const generateQR = async () => {
    if (!singleSel || singleSel.type !== "entrance") return;
    try {
      await mapLayoutApi.update(layout._id, { ...layout, updatedAt: undefined });
      const res = await mapLayoutApi.genEntranceQR(layout._id, singleSel.id);
      patchSelected({ qrPublicUrl: res.data.publicUrl, qrImagePath: res.data.qrImagePath });
    } catch (err) {
      console.error(err);
      alert("Failed to generate QR. " + (err?.response?.data?.message || err.message));
    }
  };

  const gridLines = useMemo(() => {
    const parts = [];
    for (let x = 0; x < size.width; x += size.grid) parts.push(<Line key={`v${x}`} points={[x, 0, x, size.height]} stroke="#eee" strokeWidth={1} listening={false} />);
    for (let y = 0; y < size.height; y += size.grid) parts.push(<Line key={`h${y}`} points={[0, y, size.width, y]} stroke="#eee" strokeWidth={1} listening={false} />);
    return parts;
  }, [size]);

  const zoomTo = (next) => { const stage = stageRef.current; setScale(next); stage.scale({ x: next, y: next }); stage.batchDraw(); };
  const fitToViewport = () => {
    const el = scrollRef.current; if (!el) return;
    const padding = 24;
    const sx = (el.clientWidth - padding) / size.width;
    const sy = (el.clientHeight - padding) / size.height;
    const next = Math.min(sx, sy);
    zoomTo(Math.max(0.1, Math.min(next, 4)));
    stageRef.current.position({ x: 0, y: 0 });
    el.scrollLeft = 0; el.scrollTop = 0;
  };

  const isSelected = (type, id) => selection.has(SID(type, id));

  const handleStallTransformEnd = (stallId, ev, original) => {
    const node = ev.target;
    const scaleX = node.scaleX();
    const scaleY = node.scaleY();
    let newW = Math.max(10, Math.round(node.width() * scaleX));
    let newH = Math.max(10, Math.round(node.height() * scaleY));
    const localDx = node.x();
    const localDy = node.y();
    let newX = original.x + localDx;
    let newY = original.y + localDy;
    newW = snap(newW); newH = snap(newH); newX = snap(newX); newY = snap(newY);
    updateShape("stall", stallId, { x: newX, y: newY, width: newW, height: newH });
    node.scaleX(1); node.scaleY(1); node.position({ x: 0, y: 0 });
    node.getLayer()?.batchDraw();
  };

  const multiType = useMemo(() => {
    if (!isMulti) return null;
    const types = new Set([...selection].map((sid) => parseSID(sid).type));
    return types.size === 1 ? [...types][0] : null;
  }, [selection, isMulti]);

  const bulkSetStallStatus = (status) => {
    const ids = [...selection].map(parseSID).filter(x => x.type === "stall").map(x => x.id);
    if (!ids.length) return;
    updateMany("stall", ids, (o) => ({ status, fill: STATUS_COLORS[status] }));
  };
  const bulkSetStallNumber = (field, value) => {
    const v = parseInt(value || 0, 10);
    if (Number.isNaN(v) || v <= 0) return;
    const ids = [...selection].map(parseSID).filter(x => x.type === "stall").map(x => x.id);
    updateMany("stall", ids, { [field]: v });
  };

  return (
    <Stack direction="row" spacing={2}>
      {/* Left panel */}
      <Stack sx={{ width: 300, p: 2, border: "1px solid #eee", borderRadius: 2 }} spacing={1}>
        <Typography variant="subtitle1">Tools</Typography>
        <Stack direction="row" spacing={1} flexWrap="wrap">
          {Object.values(TOOL).map((t) => (
            <Button key={t} size="small" variant={tool === t ? "contained" : "outlined"} onClick={() => setTool(t)}>
              {t}
            </Button>
          ))}
        </Stack>

        <Divider sx={{ my: 1 }} />

        <Stack direction="row" spacing={1} alignItems="center">
          <IconButton size="small" onClick={() => zoomTo(Math.max(0.1, scale / 1.2))}><RemoveIcon /></IconButton>
          <Typography variant="body2" width={72} textAlign="center">{(scale * 100).toFixed(0)}%</Typography>
          <IconButton size="small" onClick={() => zoomTo(Math.min(4, scale * 1.2))}><AddIcon /></IconButton>
          <IconButton size="small" onClick={() => zoomTo(1)} title="Actual size"><ZoomOutMapIcon /></IconButton>
          <IconButton size="small" onClick={fitToViewport} title="Fit"><FitScreenIcon /></IconButton>
        </Stack>

        <Button size="small" onClick={() => {
          zoomTo(1);
          const s = stageRef.current; s.position({ x: 0, y: 0 }); s.batchDraw();
          if (scrollRef.current) { scrollRef.current.scrollLeft = 0; scrollRef.current.scrollTop = 0; }
        }}>
          Reset View
        </Button>

        <Stack direction="row" spacing={1}>
          <Button size="small" color="error" onClick={deleteSelection} disabled={isNone}>Delete</Button>
          <Button size="small" onClick={copySelectionToClipboard} disabled={isNone}>Copy</Button>
        </Stack>
        <Button size="small" variant="contained" onClick={onSave}>Save Layout</Button>

        {!isNone && !isSingle && (
          <Alert severity="info" sx={{ mt: 1, py: 0.5 }}>
            {selection.size} selected — Arrow keys to move (Shift = snap by grid), Ctrl/Cmd+C, Ctrl/Cmd+V, Delete
          </Alert>
        )}

        <Divider sx={{ my: 1 }} />
        <Typography variant="subtitle2">Legend</Typography>
        {Object.entries(STATUS_COLORS).map(([k, v]) => (
          <Stack key={k} direction="row" spacing={1} alignItems="center">
            <Box sx={{ width: 16, height: 16, bgcolor: v, borderRadius: 0.5 }} />
            <Typography variant="caption">{k}</Typography>
          </Stack>
        ))}

        <Divider sx={{ my: 1 }} />
        <Typography variant="subtitle2">Block / Row generator</Typography>
        <TextField size="small" label="Start X" type="number" value={gen.x} onChange={(e) => setGen((p) => ({ ...p, x: +e.target.value }))} />
        <TextField size="small" label="Start Y" type="number" value={gen.y} onChange={(e) => setGen((p) => ({ ...p, y: +e.target.value }))} />
        <TextField size="small" label="Count" type="number" value={gen.count} onChange={(e) => setGen((p) => ({ ...p, count: +e.target.value }))} />
        <TextField size="small" label="Width" type="number" value={gen.w} onChange={(e) => setGen((p) => ({ ...p, w: +e.target.value }))} />
        <TextField size="small" label="Height" type="number" value={gen.h} onChange={(e) => setGen((p) => ({ ...p, h: +e.target.value }))} />
        <TextField size="small" label="Gap" type="number" value={gen.gap} onChange={(e) => setGen((p) => ({ ...p, gap: +e.target.value }))} />
        <TextField size="small" label="Prefix (e.g. E-)" value={gen.prefix} onChange={(e) => setGen((p) => ({ ...p, prefix: e.target.value }))} />
        <Stack direction="row" spacing={1}>
          <Button size="small" variant="outlined" onClick={addRow}>Add Row →</Button>
          <Button size="small" variant="outlined" onClick={addColumn}>Add Column ↓</Button>
        </Stack>
      </Stack>

      {/* Canvas */}
      <Box
        ref={scrollRef}
        sx={{
          width: "calc(100vw - 820px)",
          height: "78vh",
          border: "1px solid #eee",
          borderRadius: 2,
          overflow: "auto",
          position: "relative",
          cursor: activeTool === TOOL.PAN ? (isPanning ? "grabbing" : "grab") : "default",
          backgroundColor: "#fff",
        }}
      >
        <Stage
          ref={stageRef}
          width={size.width}
          height={size.height}
          onMouseDown={handleStageMouseDown}
          onMouseMove={handleStageMouseMove}
          onMouseUp={handleStageMouseUp}
          onClick={handleStageClick}
          onWheel={handleWheel}
          listening={true}
        >
          <Layer listening={activeTool !== TOOL.PAN}>
            {bgImage && <KonvaImage image={bgImage} width={size.width} height={size.height} opacity={0.8} listening={false} />}
            <Group listening={false}>{gridLines}</Group>

            <Group listening={false}>
              {(layout.pathEdges || []).map((e) => {
                const a = (layout.pathNodes || []).find((n) => n.id === e.from);
                const b = (layout.pathNodes || []).find((n) => n.id === e.to);
                if (!a || !b) return null;
                return <Line key={e.id} points={[a.x, a.y, b.x, b.y]} stroke="#2196f3" dash={[4, 4]} />;
              })}
            </Group>

            {/* ✅ FIXED: Stall labels with responsive font size and ellipsis */}
            {(layout.stalls || []).map((s) => {
              // 📏 Calculate responsive font size based on stall dimensions
              const minDim = Math.min(s.width, s.height);
              const fontSize = Math.max(10, Math.min(14, minDim * 0.3)); // 30% of smallest dimension, capped at 10-14px
              const maxTextWidth = s.width - 8; // padding of 4px on each side

              return (
                <Group
                  key={s.id}
                  x={s.x}
                  y={s.y}
                  draggable={activeTool === TOOL.SELECT}
                  onDragEnd={(ev) => updateShape("stall", s.id, { x: snap(ev.target.x()), y: snap(ev.target.y()) })}
                  onClick={(ev) => clickShape("stall", s.id, ev)}
                >
                  <Rect
                    width={s.width}
                    height={s.height}
                    fill={s.fill}
                    stroke={isSelected("stall", s.id) ? "#000" : "#555"}
                    strokeWidth={isSelected("stall", s.id) ? 2 : 1}
                    ref={(el) => { if (el) stallNodeRefs.current[s.id] = el; }}
                    draggable={false}
                    onTransformEnd={(ev) => handleStallTransformEnd(s.id, ev, s)}
                  />
                  <Text
                    text={s.label || ""}
                    x={4}
                    y={4}
                    fontSize={fontSize}
                    fill="#fff"
                    fontStyle="bold"
                    width={maxTextWidth}
                    ellipsis={true}
                    wrap="none"
                    listening={false}
                  />
                </Group>
              );
            })}

            {singleSel?.type === "stall" && stallNodeRefs.current[singleSel.id] && (
              <Transformer
                ref={stallTrRef}
                nodes={[stallNodeRefs.current[singleSel.id]]}
                rotateEnabled={false}
                anchorSize={8}
                boundBoxFunc={(oldBox, newBox) => {
                  const min = Math.max(size.grid, 10);
                  const w = newBox.width;
                  const h = newBox.height;
                  if (Math.abs(w) < min || Math.abs(h) < min) return oldBox;
                  return newBox;
                }}
              />
            )}

            {(layout.entrances || []).map((e) => (
              <Group
                key={e.id}
                x={e.x}
                y={e.y}
                draggable={activeTool === TOOL.SELECT}
                onDragEnd={(ev) => updateShape("entrance", e.id, { x: snap(ev.target.x()), y: snap(ev.target.y()) })}
                onClick={(ev) => clickShape("entrance", e.id, ev)}
              >
                <Circle radius={e.radius} fill="#1976d2" stroke={isSelected("entrance", e.id) ? "#000" : "#333"} strokeWidth={isSelected("entrance", e.id) ? 2 : 1} />
                <Text text="E" offsetX={-4} offsetY={-7} fontSize={14} fill="#fff" />
              </Group>
            ))}

            {(layout.pathNodes || []).map((n) => (
              <Circle
                key={n.id}
                x={n.x}
                y={n.y}
                radius={4}
                fill="#000"
                onClick={(ev) => onNodeClick(n, ev)}
                draggable={activeTool === TOOL.SELECT}
                onDragEnd={(ev) => updateShape("node", n.id, { x: snap(ev.target.x()), y: snap(ev.target.y()) })}
                stroke={isSelected("node", n.id) ? "#000" : undefined}
                strokeWidth={isSelected("node", n.id) ? 2 : 0}
              />
            ))}

            {/* Street pins */}
            {(layout.streetViews || []).map((p) => (
              <Group
                key={p.id}
                x={p.x}
                y={p.y}
                draggable={activeTool === TOOL.SELECT}
                onDragEnd={(ev) => updateShape("street", p.id, { x: snap(ev.target.x()), y: snap(ev.target.y()) })}
                onClick={(ev) => clickShape("street", p.id, ev)}
              >
                <Circle radius={6} fill="#43a047" stroke={isSelected("street", p.id) ? "#000" : undefined} strokeWidth={isSelected("street", p.id) ? 2 : 0} />
              </Group>
            ))}

            {(layout.boundaries || []).map((b) => (
              <Group
                key={b.id}
                x={b.x}
                y={b.y}
                draggable={activeTool === TOOL.SELECT}
                onDragEnd={(ev) => updateShape("boundary", b.id, { x: snap(ev.target.x()), y: snap(ev.target.y()) })}
                onClick={(ev) => clickShape("boundary", b.id, ev)}
              >
                <Rect width={b.width} height={b.height} stroke={isSelected("boundary", b.id) ? "#000" : "#444"} dash={[6, 6]} strokeWidth={isSelected("boundary", b.id) ? 2 : 1} />
              </Group>
            ))}

            {(layout.labels || []).map((l) => (
              <Group
                key={l.id}
                x={l.x}
                y={l.y}
                draggable={activeTool === TOOL.SELECT}
                onDragEnd={(ev) => updateShape("label", l.id, { x: snap(ev.target.x()), y: snap(ev.target.y()) })}
                onClick={(ev) => clickShape("label", l.id, ev)}
              >
                <Text text={l.text} fontSize={l.fontSize || 16} fill="#111" fontStyle="bold" />
                {isSelected("label", l.id) && <Rect x={-2} y={-12} width={80} height={24} stroke="#000" dash={[4, 4]} />}
              </Group>
            ))}

            {marquee && (
              <Group listening={false}>
                <Rect
                  x={Math.min(marquee.x1, marquee.x2)}
                  y={Math.min(marquee.y1, marquee.y2)}
                  width={Math.abs(marquee.x2 - marquee.x1)}
                  height={Math.abs(marquee.y2 - marquee.y1)}
                  stroke="#1976d2"
                  dash={[6, 4]}
                  opacity={0.8}
                />
                <Rect
                  x={Math.min(marquee.x1, marquee.x2)}
                  y={Math.min(marquee.y1, marquee.y2)}
                  width={Math.abs(marquee.x2 - marquee.x1)}
                  height={Math.abs(marquee.y2 - marquee.y2)}
                />
              </Group>
            )}
          </Layer>

          {route?.points?.length > 1 && (
            <Layer listening={false} hitGraphEnabled={false}>
              <Line
                points={route.points.flatMap(p => [p.x, p.y])}
                stroke="#1976d2"
                strokeWidth={4}
                lineCap="round"
                lineJoin="round"
                opacity={0.9}
                listening={false}
              />
            </Layer>
          )}
        </Stage>
      </Box>

      {/* Right panel: properties */}
      <Stack sx={{ width: 320, p: 2, border: "1px solid #eee", borderRadius: 2 }} spacing={1}>
        <Typography variant="subtitle1">Properties</Typography>

        {isNone && <Typography variant="caption">Nothing selected</Typography>}
        {!isNone && !isSingle && <Typography variant="caption">{selection.size} items selected</Typography>}

        {isMulti && (
          <>
            <Typography variant="subtitle2">Bulk edit (Stalls)</Typography>
            <FormControl size="small">
              <InputLabel>Status</InputLabel>
              <Select label="Status" defaultValue="" onChange={(e) => bulkSetStallStatus(e.target.value)}>
                <MenuItem value=""><em>(keep current)</em></MenuItem>
                {Object.keys(STATUS_COLORS).map((k) => <MenuItem key={k} value={k}>{k}</MenuItem>)}
              </Select>
            </FormControl>
            <TextField size="small" type="number" label="Width (apply to all)" onChange={(e) => bulkSetStallNumber("width", e.target.value)} />
            <TextField size="small" type="number" label="Height (apply to all)" onChange={(e) => bulkSetStallNumber("height", e.target.value)} />
            <Divider sx={{ my: 1 }} />
          </>
        )}

        {selectedObj && singleSel?.type === "stall" && (
          <>
            <TextField size="small" label="Name" value={selectedObj.name || ""} onChange={(e) => patchSelected({ name: e.target.value })} />
            <TextField size="small" label="Label" value={selectedObj.label || ""} onChange={(e) => patchSelected({ label: e.target.value })} />
            <FormControl size="small">
              <InputLabel>Status</InputLabel>
              <Select
                label="Status"
                value={selectedObj.status || "occupied"}
                onChange={(e) => patchSelected({ status: e.target.value, fill: STATUS_COLORS[e.target.value] })}
              >
                {Object.keys(STATUS_COLORS).map((k) => <MenuItem key={k} value={k}>{k}</MenuItem>)}
              </Select>
            </FormControl>
            <TextField size="small" type="number" label="Width" value={selectedObj.width} onChange={(e) => patchSelected({ width: parseInt(e.target.value || 0, 10) })} />
            <TextField size="small" type="number" label="Height" value={selectedObj.height} onChange={(e) => patchSelected({ height: parseInt(e.target.value || 0, 10) })} />
            <TextField size="small" type="number" label="X" value={selectedObj.x} onChange={(e) => patchSelected({ x: parseInt(e.target.value || 0, 10) })} />
            <TextField size="small" type="number" label="Y" value={selectedObj.y} onChange={(e) => patchSelected({ y: parseInt(e.target.value || 0, 10) })} />

            <Divider sx={{ my: 1 }} />
            <Typography variant="subtitle2">Vendor Assignment</Typography>
            {loadingVendors ? (
              <Typography variant="caption">Loading vendors...</Typography>
            ) : (
              <FormControl fullWidth size="small">
                <InputLabel>Vendor</InputLabel>
                <Select
                  label="Vendor"
                  value={selectedObj.meta?.vendorId || ""}
                  onChange={(e) => handleAssignVendor(e.target.value)}
                >
                  <MenuItem value=""><em>— Vacant —</em></MenuItem>
                  {vendors.map((v) => (
                    <MenuItem key={v._id} value={v._id}>
                      {v.name || v.email}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            )}

            <TextField
              size="small"
              type="number"
              label="Rate (₱)"
              value={selectedObj.rate || 0}
              onChange={(e) => patchSelected({ rate: parseFloat(e.target.value) || 0 })}
              helperText="Enter stall rental rate"
            />
            <Button
              size="small"
              variant="outlined"
              sx={{ alignSelf: "start", mt: 0.5 }}
              onClick={async () => {
                try {
                  await mapLayoutApi.update(layout._id, { ...layout, updatedAt: undefined });
                  alert("Rate saved successfully!");
                } catch (err) {
                  console.error(err);
                  alert("Failed to save rate. " + (err?.response?.data?.message || err.message));
                }
              }}
            >
              Save Rate
            </Button>
          </>
        )}

        {selectedObj && singleSel?.type === "entrance" && (
          <Stack spacing={1.25}>
            <TextField size="small" label="Entrance name" value={selectedObj.name || ""} onChange={(e) => patchSelected({ name: e.target.value })} />
            <TextField size="small" type="number" label="Radius" value={selectedObj.radius || 10} onChange={(e) => patchSelected({ radius: parseInt(e.target.value || 10, 10) })} />
            <TextField
              size="small"
              label="Public View URL"
              value={selectedObj.qrPublicUrl || ""}
              InputProps={{
                readOnly: true,
                endAdornment: (
                  <InputAdornment position="end">
                    <Tooltip title="Copy URL">
                      <IconButton size="small" onClick={() => selectedObj.qrPublicUrl && navigator.clipboard?.writeText(selectedObj.qrPublicUrl)} aria-label="Copy public URL">
                        <ContentCopyIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Open Public View">
                      <span>
                        <IconButton size="small" disabled={!selectedObj.qrPublicUrl} onClick={() => window.open(selectedObj.qrPublicUrl, "_blank")} aria-label="Open public view">
                          <OpenInNewIcon fontSize="small" />
                        </IconButton>
                      </span>
                    </Tooltip>
                  </InputAdornment>
                ),
              }}
              helperText="Ito ang URL na lalabas kapag na-scan ang QR"
            />

            <Paper variant="outlined" sx={{ p: 1.25, pt: 3, borderRadius: 2, position: "relative" }}>
              <Typography variant="caption" sx={{ position: "absolute", top: 8, left: 8, px: 1, py: 0.25, borderRadius: 1, fontWeight: 600 }}>
                Entrance QR
              </Typography>
              <Box sx={{ display: "grid", placeItems: "center", p: 1.25, borderRadius: 3, bgcolor: "#fff", border: "1px solid #e0e0e0" }}>
                {selectedObj.qrImagePath ? (
                  <img src={resolveImageUrl(selectedObj.qrImagePath)} alt="Entrance QR" style={{ width: 220, height: 220, objectFit: "contain" }} />
                ) : (
                  <Stack alignItems="center" spacing={0.75} sx={{ py: 5 }}>
                    <QrCode2Icon />
                    <Typography variant="caption" color="text.secondary">Walang QR pa — generate muna</Typography>
                  </Stack>
                )}
              </Box>
              <Box sx={{ mt: 1, display: "flex", justifyContent: "center" }}>
                <Box sx={{ display: "flex", gap: 0.5, p: 0.5, borderRadius: 999, border: "1px solid", borderColor: "divider" }}>
                  <Tooltip title="Generate / Regenerate QR">
                    <span>
                      <IconButton size="small" onClick={generateQR} aria-label="Generate QR" sx={{ width: 36, height: 36, borderRadius: 999 }}>
                        <QrCode2Icon fontSize="small" />
                      </IconButton>
                    </span>
                  </Tooltip>
                  <Tooltip title={selectedObj.qrImagePath ? "Download QR" : "Generate first"}>
                    <span>
                      <IconButton
                        size="small"
                        aria-label="Download QR"
                        disabled={!selectedObj.qrImagePath}
                        onClick={() => {
                          const a = document.createElement("a");
                          a.href = resolveImageUrl(selectedObj.qrImagePath || "");
                          a.download = `entrance-${selectedObj.name || "qr"}.png`;
                          document.body.appendChild(a); a.click(); a.remove();
                        }}
                        sx={{ width: 36, height: 36, borderRadius: 999 }}
                      >
                        <DownloadIcon fontSize="small" />
                      </IconButton>
                    </span>
                  </Tooltip>
                  <Tooltip title="Open Public View">
                    <span>
                      <IconButton size="small" aria-label="Open public view" disabled={!selectedObj.qrPublicUrl} onClick={() => window.open(selectedObj.qrPublicUrl, "_blank")} sx={{ width: 36, height: 36, borderRadius: 999 }}>
                        <OpenInNewIcon fontSize="small" />
                      </IconButton>
                    </span>
                  </Tooltip>
                </Box>
              </Box>
            </Paper>
          </Stack>
        )}

        {selectedObj && singleSel?.type === "node" && (
          <>
            <TextField size="small" type="number" label="X" value={selectedObj.x} onChange={(e) => patchSelected({ x: parseInt(e.target.value || 0, 10) })} />
            <TextField size="small" type="number" label="Y" value={selectedObj.y} onChange={(e) => patchSelected({ y: parseInt(e.target.value || 0, 10) })} />
            <Typography variant="caption">Tip: choose <b>edge</b> tool then click two nodes to connect paths.</Typography>
          </>
        )}

        {/* STREET PROPERTIES */}
        {selectedObj && singleSel?.type === "street" && (
          <>
            <TextField size="small" label="Title" value={selectedObj.title || ""} onChange={(e) => patchSelected({ title: e.target.value })} />
            <TextField size="small" label="Image Path (/uploads/...)" value={selectedObj.imagePath || ""} onChange={(e) => patchSelected({ imagePath: e.target.value })} />
            <Stack direction="row" spacing={1} alignItems="center">
              <Button size="small" variant="outlined" onClick={() => triggerStreetUpload(selectedObj.id)}>Upload / Replace</Button>
              <Typography variant="caption" color="text.secondary">
                Status: {selectedObj.status || "idle"} {selectedObj.status === "processing" ? "— generating…" : ""}
              </Typography>
            </Stack>

            <Stack direction="row" spacing={1}>
              <Button
                size="small"
                disabled={!selectedObj.sourceImagePath || selectedObj.status === "processing"}
                onClick={async () => {
                  try {
                    await mapLayoutApi.streetRegenerate(layout._id, selectedObj.id);
                    patchSelected({ status: "processing", error: "" });
                    // poll again quickly
                    let tries = 0;
                    const timer = setInterval(async () => {
                      const s = await pollStreetStatus(selectedObj.id);
                      if (s === "ready" || s === "error" || ++tries > 120) clearInterval(timer);
                    }, 2000);
                  } catch (e) {
                    alert("Failed to start regenerate.");
                  }
                }}
              >
                Regenerate tiles
              </Button>
              <Button
                size="small"
                color="error"
                onClick={async () => {
                  if (!confirm("Delete this Street View (tiles + pin)?")) return;
                  await mapLayoutApi.streetDelete(layout._id, selectedObj.id);
                  const next = { ...layout, streetViews: (layout.streetViews || []).filter(p => p.id !== selectedObj.id) };
                  onChange(next);
                }}
              >
                Delete
              </Button>
            </Stack>

            {selectedObj.error && (
              <Alert severity="error" sx={{ my: 1 }}>{selectedObj.error}</Alert>
            )}

            <Divider sx={{ my: 1 }} />
            <Typography variant="subtitle2">360 Preview</Typography>

            {(() => {
              const base = resolveImageUrl(selectedObj.imagePath);
              // gumamit ng something that changes after upload/ready
              const v = selectedObj.sourceImagePath
                || selectedObj.updatedAt
                || layout.updatedAt
                || Date.now();

              const busted = base
                ? `${base}${base.includes("?") ? "&" : "?"}v=${encodeURIComponent(v)}`
                : "";

              return (
                <Street360Viewer
                  key={busted}        // important: force remount pag nagbago
                  src={busted}
                  height={220}
                />
              );
            })()}

            <TextField size="small" type="number" label="X" value={selectedObj.x} onChange={(e) => patchSelected({ x: parseInt(e.target.value || 0, 10) })} />
            <TextField size="small" type="number" label="Y" value={selectedObj.y} onChange={(e) => patchSelected({ y: parseInt(e.target.value || 0, 10) })} />
          </>
        )}

        <Divider sx={{ my: 1 }} />
        <Typography variant="subtitle2">Directions</Typography>
        <FormControl size="small">
          <InputLabel>From entrance</InputLabel>
          <Select label="From entrance" defaultValue="" onChange={e => setRoute(s => ({ ...(s || {}), fromEntranceId: e.target.value }))}>
            <MenuItem value=""><em>—</em></MenuItem>
            {entrances.map(en => <MenuItem key={en.id} value={en.id}>{en.name}</MenuItem>)}
          </Select>
        </FormControl>
        <FormControl size="small">
          <InputLabel>To stall</InputLabel>
          <Select label="To stall" defaultValue="" onChange={e => setRoute(s => ({ ...(s || {}), toStallId: e.target.value }))}>
            <MenuItem value=""><em>—</em></MenuItem>
            {stalls.map(s => <MenuItem key={s.id} value={s.id}>{s.name}</MenuItem>)}
          </Select>
        </FormControl>
        <Button
          size="small"
          variant="outlined"
          onClick={() => findRoute({ fromEntranceId: route?.fromEntranceId, toStallId: route?.toStallId })}
          disabled={!route?.fromEntranceId || !route?.toStallId}
        >
          Find route
        </Button>

        {/* Hidden file input for street uploads */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          style={{ display: "none" }}
          onChange={handleStreetFileChange}
        />
      </Stack>
    </Stack>
  );
}