// src/components/MapCanvas.jsx
import React, { useEffect, useRef, useState, useMemo  } from "react";
import { Stage, Layer, Rect, Circle, Line, Image, Text, Group, Label, Tag } from "react-konva";
import useImage from "use-image";
import { IconButton, Box, Paper, Drawer, useMediaQuery, useTheme, Divider, Tooltip, ToggleButtonGroup, ToggleButton, Stack } from "@mui/material";
import { alpha } from "@mui/material/styles";
import AddRoundedIcon from "@mui/icons-material/AddRounded";
import RemoveRoundedIcon from "@mui/icons-material/RemoveRounded";
import RefreshRoundedIcon from "@mui/icons-material/RefreshRounded";
import LocationPinIcon from "@mui/icons-material/LocationPin";
import MenuRoundedIcon from "@mui/icons-material/MenuRounded";
import ChevronRightRoundedIcon from "@mui/icons-material/ChevronRightRounded";
import CloseIcon from "@mui/icons-material/Close";
import Street360Viewer from "./map/Street360Viewer";
import { resolveImageUrl } from "../utils/url";
import ThreeSixtyRoundedIcon from "@mui/icons-material/ThreeSixtyRounded";

// Floating HTML icons overlay (used to show service emojis over stalls)
const FloatingIcons = React.memo(({ icons = [] }) => {
  return (
    <>
      {icons.map((f) => (
        <Box
          key={f.id}
          sx={{
            position: "absolute",
            left: (f.x || 0) - 16,
            top: (f.y || 0) - 16,
            fontSize: 24,
            zIndex: 18,
            pointerEvents: "none",
            userSelect: "none",
          }}
        >
          {f.icon}
        </Box>
      ))}
    </>
  );
});

const LocationPin = React.memo(({ pos }) => {
  if (!pos) return null;
  return (
    <LocationPinIcon
      sx={{
        position: "absolute",
        left: pos.x - 16,
        top: pos.y - 40,
        fontSize: 36,
        color: "#ff0000",
        zIndex: 10,
        pointerEvents: "none",
        cursor: "default",
        filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.4))",
        animation: "bounce 2.4s ease-in-out infinite",
        "@keyframes bounce": {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-6px)" },
        },
      }}
    />
  );
});

function MapCanvas({
  layout,
  entrance,
  path = [],
  onSelectStall,
  onSelectStreetView,
  mapEffect = false,
  focusPoint,
  destinationStall,
  streetViewOpen,
  setStreetViewOpen,
}) {
  const [bg] = useImage(layout?.backgroundImage || "");
  const stageRef = useRef();
  const [scale, setScale] = useState(1);
  const [pinPos, setPinPos] = useState(null);
  const [herePulse, setHerePulse] = useState(0);
  const [hasInitialized, setHasInitialized] = useState(false); // 👈 track if initial zoom done

  if (!layout) return null;

  const { width = 1200, height = 1200 } = layout.size || {};
  const pathEdges = layout.pathEdges || [];
  const pathNodes = layout.pathNodes || [];
  const stalls = layout.stalls || [];
  const entrances = layout.entrances || [];
  const streetViews = layout.streetViews || [];

  const vw = window.innerWidth;
  const vh = window.innerHeight * 0.8;

  // base fit scale
  const baseScale = Math.min(vw / width, vh / height);

  const [pulse, setPulse] = useState(1);

  const [svFilter, setSvFilter] = useState("none");

  const serviceIcons = useMemo(() => ({
    "apparel": "🧥",
    "apparel and accessories": "🧢",
    "tailoring and textile services": "✂️",
    "personal care and beauty products": "💄",
    "cleaning and household supplies": "🧽",
    "home furnishings and décor": "🛋️",
    "toys and general merchandise": "🧸",
    "native and local products": "🏺",
    "food and beverages": "🍔",
    "personal care and grooming services": "💇‍♀️",
    "printing and mobile payment services": "🖨️",
  }), []);

  // distance helper: point to segment (ax,ay)-(bx,by)
function distAndSideToSegment(px, py, ax, ay, bx, by) {
  const vx = bx - ax, vy = by - ay;
  const wx = px - ax, wy = py - ay;
  const segLen2 = vx*vx + vy*vy || 1;
  let t = (wx*vx + wy*vy) / segLen2;
  t = Math.max(0, Math.min(1, t));
  const cx = ax + t*vx, cy = ay + t*vy;     // closest point
  const dx = px - cx, dy = py - cy;
  const dist = Math.hypot(dx, dy);
  // side: sign of cross( v , w ) at the projection point
  const side = Math.sign(vx * (py - ay) - vy * (px - ax)) || 0;
  // projected arc-length along the polyline segment (for ordering)
  const segProj = t * Math.hypot(vx, vy);
  return { dist, side, segProj, t };
}

function nearestOnPath(px, py, pts) {
  let best = { dist: Infinity, side: 0, segIndex: -1, accLen: 0, along: 0 };
  let acc = 0;
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i], b = pts[i+1];
    const { dist, side, segProj } = distAndSideToSegment(px, py, a.x, a.y, b.x, b.y);
    if (dist < best.dist) best = { dist, side, segIndex: i, accLen: acc, along: acc + segProj };
    acc += Math.hypot(b.x - a.x, b.y - a.y);
  }
  return best;
}

  // 🔹 Keep service icons synced to map movement
// 🧩 Floating service icons overlay (HTML-based)
const [floatingIcons, setFloatingIcons] = useState([]);

  useEffect(() => {
    const stage = stageRef.current;
    if (!layout || !stage) return;

    const stalls = layout.stalls || [];
    let animId;

    const updateIcons = () => {
      const scale = stage.scaleX();
      const pos = stage.position();

      const updated = stalls
        .map((s) => {
          // 🔹 subukan parehong business at businessInfo
          const rawServices =
            s.meta?.business?.services ??
            s.meta?.businessInfo?.services ??
            [];

          const services = Array.isArray(rawServices)
            ? rawServices.map((v) => String(v).toLowerCase())
            : [];

          // 🔹 hanap matching key sa serviceIcons
          const matchKey = Object.keys(serviceIcons).find((key) =>
            services.some((sv) => sv.includes(key))
          );

          if (!matchKey) return null;

          const cx = s.x + s.width / 2;
          const cy = s.y + s.height / 2;

          return {
            id: s.id ?? s._id ?? `${s.x}-${s.y}`, // fallback kung walang id
            icon: serviceIcons[matchKey],
            x: cx * scale + pos.x,
            y: cy * scale + pos.y,
          };
        })
        .filter(Boolean);

      setFloatingIcons(updated);
      animId = requestAnimationFrame(updateIcons);
    };

    animId = requestAnimationFrame(updateIcons);
    return () => cancelAnimationFrame(animId);
  }, [layout, serviceIcons]);

  // pulse animation for entrance ("YOU ARE HERE")
  useEffect(() => {
    if (!entrance) return;
    let raf;
    let t0 = performance.now();
  const loop = (now) => {
      const dt = (now - t0) / 1000; // seconds
      t0 = now;
      setHerePulse((p) => (p + dt * 0.7) % 1); // speed ~0.7 cycles/sec
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [entrance]);


  useEffect(() => {
    if (!destinationStall) return;
    let growing = true;
    const anim = setInterval(() => {
      setPulse((prev) => {
        if (prev > 1.4) growing = false;
        if (prev < 1) growing = true;
        return growing ? prev + 0.05 : prev - 0.05;
      });
    }, 60);
    return () => clearInterval(anim);
  }, [destinationStall]);

  // Use passed-in streetViewOpen if provided, otherwise manage locally
  const [localStreetViewOpen, setLocalStreetViewOpen] = useState(false);
  const effectiveStreetViewOpen = streetViewOpen !== undefined ? streetViewOpen : localStreetViewOpen;
  const effectiveSetStreetViewOpen = setStreetViewOpen || setLocalStreetViewOpen;

  const [selectedStreetView, setSelectedStreetView] = useState(null);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  // Controls collapsed state (for mobile split-view)
  const [controlsCollapsed, setControlsCollapsed] = useState(false);

  // Auto-collapse when entering mobile split-view, expand when leaving
  useEffect(() => {
    if (effectiveStreetViewOpen && isMobile) setControlsCollapsed(true);
    else setControlsCollapsed(false);
  }, [effectiveStreetViewOpen, isMobile]);

  // Handler kapag may na-click na streetView dot
  const handleStreetViewSelect = (view) => {
    if (!view) return;
    const resolved = {
      ...view,
      imagePath: resolveImageUrl(view.imagePath),
    };
    setSelectedStreetView(resolved);
    effectiveSetStreetViewOpen(true);
  };


  // ✅ INITIAL ZOOM TO ENTRANCE - Automatically center and zoom to "YOU ARE HERE"
  useEffect(() => {
    const stage = stageRef.current;
    if (!stage || !entrance || hasInitialized) return;

    // Delay para siguradong loaded na lahat
    const timer = setTimeout(() => {
      const { x: ex, y: ey } = entrance;
      const targetZoom = baseScale * 1.8; // zoom level (adjust kung gusto mo mas zoom in/out)

      const targetPos = {
        x: vw / 2 - ex * targetZoom,
        y: vh / 2 - ey * targetZoom,
      };

      // Smooth animation
      const duration = 800;
      const startTime = performance.now();
      const startZoom = stage.scaleX();
      const startPos = stage.position();

      const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);

      const animate = (now) => {
        const t = Math.min((now - startTime) / duration, 1);
        const ease = easeOutCubic(t);
        const newZoom = startZoom + (targetZoom - startZoom) * ease;
        const newX = startPos.x + (targetPos.x - startPos.x) * ease;
        const newY = startPos.y + (targetPos.y - startPos.y) * ease;

        stage.scale({ x: newZoom, y: newZoom });
        stage.position({ x: newX, y: newY });
        stage.batchDraw();
        setScale(newZoom);

        if (t < 1) {
          requestAnimationFrame(animate);
        } else {
          setHasInitialized(true);
        }
      };

      requestAnimationFrame(animate);
    }, 100); // 100ms delay

    return () => clearTimeout(timer);
  }, [entrance, baseScale, vw, vh, hasInitialized]);

  // Reset hasInitialized when entrance changes
  useEffect(() => {
    setHasInitialized(false);
  }, [entrance?.id]);

  // Zoom via mouse wheel
  const handleWheel = (e) => {
    e.evt.preventDefault();
    const stage = stageRef.current;
    if (!stage) return;
    const oldScale = stage.scaleX();
    const pointer = stage.getPointerPosition();
    const scaleBy = 0.03;
    const newScale =
      e.evt.deltaY > 0 ? oldScale / (1 + scaleBy) : oldScale * (1 + scaleBy);
    const clampedScale = Math.max(baseScale * 0.5, Math.min(baseScale * 4, newScale));
    const mousePointTo = {
      x: (pointer.x - stage.x()) / oldScale,
      y: (pointer.y - stage.y()) / oldScale,
    };
    const newPos = {
      x: pointer.x - mousePointTo.x * clampedScale,
      y: pointer.y - mousePointTo.y * clampedScale,
    };
    stage.scale({ x: clampedScale, y: clampedScale });
    stage.position(newPos);
    stage.batchDraw();
    setScale(clampedScale);
  };

  // Reset zoom/position - Back to entrance
  const handleResetView = () => {
    const stage = stageRef.current;
    if (!stage || !entrance) return;

    const { x: ex, y: ey } = entrance;
    const targetZoom = baseScale * 1.8;
    const targetPos = {
      x: vw / 2 - ex * targetZoom,
      y: vh / 2 - ey * targetZoom,
    };

    // Smooth animation back to entrance
    const duration = 600;
    const startTime = performance.now();
    const startZoom = stage.scaleX();
    const startPos = stage.position();

    const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);

    const animate = (now) => {
      const t = Math.min((now - startTime) / duration, 1);
      const ease = easeOutCubic(t);
      const newZoom = startZoom + (targetZoom - startZoom) * ease;
      const newX = startPos.x + (targetPos.x - startPos.x) * ease;
      const newY = startPos.y + (targetPos.y - startPos.y) * ease;

      stage.scale({ x: newZoom, y: newZoom });
      stage.position({ x: newX, y: newY });
      stage.batchDraw();
      setScale(newZoom);

      if (t < 1) requestAnimationFrame(animate);
    };

    requestAnimationFrame(animate);
  };

  // Zoom via buttons
  const zoomBy = (factor) => {
    const stage = stageRef.current;
    if (!stage) return;
    const newScale = Math.max(baseScale * 0.5, Math.min(baseScale * 4, scale * factor));
    stage.scale({ x: newScale, y: newScale });
    stage.batchDraw();
    setScale(newScale);
  };

  // Focus animation
  useEffect(() => {
    if (!focusPoint || !stageRef.current) return;
    const stage = stageRef.current;
    const rect = { width: vw, height: vh };
    const targetZoom = baseScale * 2;
    const startZoom = stage.scaleX();
    const startPos = stage.position();
    const targetPos = {
      x: rect.width / 2 - focusPoint.x * targetZoom,
      y: rect.height / 2 - focusPoint.y * targetZoom,
    };
const duration = 600;
const startTime = performance.now();

const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);

    const animate = (now) => {
      const t = Math.min((now - startTime) / duration, 1);
      const ease = easeOutCubic(t);
      const newZoom = startZoom + (targetZoom - startZoom) * ease;
      const newX = startPos.x + (targetPos.x - startPos.x) * ease;
      const newY = startPos.y + (targetPos.y - startPos.y) * ease;
      stage.scale({ x: newZoom, y: newZoom });
      stage.position({ x: newX, y: newY });
      stage.batchDraw();
      if (t < 1) requestAnimationFrame(animate);
    };
    requestAnimationFrame(animate);
  }, [focusPoint]);

  // visible street views based on filter
  const filteredStreetViews = useMemo(() => {
    if (svFilter === "none") return [];
    if (svFilter === "all" || !path || path.length < 2) return streetViews;

    const pts = path.map(p => ({ x: p.x, y: p.y }));
    const THRESH = 14; // ✅ mas strict: stalls/paths lang

    const out = [];
    for (const s of streetViews) {
      const n = nearestOnPath(s.x, s.y, pts);
      if (n.dist > THRESH) continue;

      // include _along (ordering), _side (which side of the path the pin is on),
      // and _segIndex (which segment of the path is nearest) so we can compute
      // local tangent directions later when deciding left/right connectivity.
      const item = { ...s, _along: n.along, _side: n.side, _segIndex: n.segIndex };
      if (svFilter === "route") out.push(item);
      else if (svFilter === "left" && n.side > 0) out.push(item);
      else if (svFilter === "right" && n.side < 0) out.push(item);
    }

    out.sort((a, b) => a._along - b._along);
    return out;
  }, [streetViews, path, svFilter]);

  const memoizedNextViews = useMemo(
    () => {
      const pts = (path || []).map(p => ({ x: p.x, y: p.y }));
      const out = filteredStreetViews.map((v) => {
        return {
          id: v.id,
          imagePath: resolveImageUrl(v.imagePath),
          title: v.title,
          x: v.x,
          y: v.y,
          _along: v._along,
          _side: v._side,
          _segIndex: v._segIndex,
        };
      });

      // Use path edges to determine left/right neighbors. For each street view,
      // find all other street views that are reachable via a single edge, then
      // classify them as left/right based on the edge direction relative to the
      // local path forward direction.
      const pathNodeMap = Object.fromEntries((pathNodes || []).map(n => [n.id, n]));
      const edgeMap = {};
      (pathEdges || []).forEach(e => {
        if (!edgeMap[e.from]) edgeMap[e.from] = [];
        if (!edgeMap[e.to]) edgeMap[e.to] = [];
        edgeMap[e.from].push({ to: e.to, node: pathNodeMap[e.to] });
        edgeMap[e.to].push({ to: e.from, node: pathNodeMap[e.from] });
      });

      for (let i = 0; i < out.length; i++) {
        const v = out[i];
        v.hasLeft = false;
        v.hasRight = false;
        v.leftNeighbor = null;
        v.rightNeighbor = null;

        // compute local forward/tangent using segment index if available
        let fx = 1, fy = 0; // default forward
        if (typeof v._segIndex === "number" && pts.length > 1) {
          const si = Math.max(0, Math.min(pts.length - 2, v._segIndex));
          const a = pts[si];
          const b = pts[si + 1];
          const dx = b.x - a.x;
          const dy = b.y - a.y;
          const len = Math.hypot(dx, dy) || 1;
          fx = dx / len;
          fy = dy / len;
        }
        // left vector is forward rotated +90deg
        const lx = -fy, ly = fx;
        // right vector is -left
        const rx = fy, ry = -fx;

        // For each other street view, check if there's a path-edge-based connection
        let leftNeighbors = [];
        let rightNeighbors = [];
        for (let j = 0; j < out.length; j++) {
          if (i === j) continue;
          const u = out[j];

          // Check if there is a path edge connecting any node near v to any node near u.
          // For simplicity, assume each street view is associated with a single nearest
          // path node; you can enhance this if the mapping is more complex.
          let isConnected = false;
          for (const node of pathNodes || []) {
            const edges = edgeMap[node.id] || [];
            for (const edge of edges) {
              // If this edge connects from a node in v's region to a node in u's region,
              // count them as connected. For now, just check if there's any edge.
              // (A more robust approach would map street views to path nodes explicitly.)
              isConnected = true;
              break;
            }
            if (isConnected) break;
          }

          // For now, use a simpler heuristic: if u is in filteredStreetViews and
          // both v and u are on the path, check their relative direction.
          // If there are explicit path-node mappings on the street view objects,
          // use those to check edge connectivity.
          const vx = u.x - v.x;
          const vy = u.y - v.y;
          const dist = Math.hypot(vx, vy) || 1;
          const nx = vx / dist;
          const ny = vy / dist;

          const cosLeft = nx * lx + ny * ly;
          const cosRight = nx * rx + ny * ry;

          const lateralLeft = Math.abs(cosLeft);
          const lateralRight = Math.abs(cosRight);

          // Classify as left/right only if u is significantly lateral (perpendicular)
          // to the forward direction, indicating a true side connection rather than
          // a forward/backward progression.
          const LATERAL_THRESHOLD = 0.7; // require |lateral_component| >= 0.7 (stricter: ~45deg cone)
          if (lateralLeft >= LATERAL_THRESHOLD && cosLeft > 0) {
            leftNeighbors.push({ id: u.id, dist, cos: cosLeft });
          }
          if (lateralRight >= LATERAL_THRESHOLD && cosRight > 0) {
            rightNeighbors.push({ id: u.id, dist, cos: cosRight });
          }
        }

        // Pick nearest neighbor on each side
        if (leftNeighbors.length) {
          leftNeighbors.sort((a, b) => a.dist - b.dist);
          v.hasLeft = true;
          v.leftNeighbor = leftNeighbors[0].id;
        }
        if (rightNeighbors.length) {
          rightNeighbors.sort((a, b) => a.dist - b.dist);
          v.hasRight = true;
          v.rightNeighbor = rightNeighbors[0].id;
        }
      }

      return out;
    },
    [filteredStreetViews, path]
  );

  useEffect(() => {
    if (!path || path.length < 2) return;
    if (filteredStreetViews.length === 0) return;

    // auto-open & pick first street view along route
    effectiveSetStreetViewOpen(true);
    setSelectedStreetView({
      ...filteredStreetViews[0],
      imagePath: resolveImageUrl(filteredStreetViews[0].imagePath),
    });
  }, [path, filteredStreetViews, effectiveSetStreetViewOpen]);


  // Reset on layout or entrance change
  useEffect(() => {
      if (path && path.length > 1) setSvFilter("route");
      else setSvFilter("none");
    }, [path]);

  // 🔹 Keep the HTML Location Pin synced to Konva stage transforms
useEffect(() => {
  const stage = stageRef.current;
  if (!destinationStall || !stage) {
    setPinPos(null);
    return;
  }

  const { x, y, width, height } = destinationStall;
  const cx = x + width / 2;
  const cy = y + height / 2;

  const updatePin = () => {
    const scale = stage.scaleX();
    const pos = stage.position();
    const screenX = cx * scale + pos.x;
    const screenY = cy * scale + pos.y;
    setPinPos({ x: screenX, y: screenY });
    requestAnimationFrame(updatePin);
  };

  const animId = requestAnimationFrame(updatePin);
  return () => cancelAnimationFrame(animId);
}, [destinationStall]);

  return (
    <Box sx={{ position: "relative", width: "100%", height: (effectiveStreetViewOpen && isMobile) ? "100vh" : vh, display: "flex", flexDirection: "column" }}>
      {/* 🔹 Split-view header with close button (mobile only) */}
      {effectiveStreetViewOpen && isMobile && (
        <Box
          sx={{
            position: "absolute",
            top: 12,
            right: 12,
            zIndex: 10,
            bgcolor: "rgba(0,0,0,0.5)",
            borderRadius: 1,
            padding: "4px 8px",
          }}
        >
          <IconButton
            size="small"
            onClick={() => effectiveSetStreetViewOpen(false)}
            sx={{ color: "white" }}
            title="Close split view"
          >
            <CloseIcon />
          </IconButton>
        </Box>
      )}

      <Stage
        ref={stageRef}
        width={vw}
        height={(effectiveStreetViewOpen && isMobile) ? window.innerHeight * 0.5 : vh}
        onWheel={handleWheel}
        draggable
        style={{
          backgroundColor: "#fafafa",
          borderTop: "1px solid #ddd",
          touchAction: "none",
          cursor: "grab",
          flex: (effectiveStreetViewOpen && isMobile) ? 0 : 1,
        }}
        onMouseDown={() => (document.body.style.cursor = "grabbing")}
        onMouseUp={() => (document.body.style.cursor = "grab")}
      >
        <Layer>
          {/* ✅ Background */}
          {bg && <Image image={bg} width={width} height={height} />}

          {/* ✅ Edges */}
          {/* ✅ Edges (background graph) */}
          {pathEdges.map((e) => {
            const from = pathNodes.find((n) => n.id === e.from);
            const to = pathNodes.find((n) => n.id === e.to);
            if (!from || !to) return null;
            return (
              <Line
                key={e.id}
                points={[from.x, from.y, to.x, to.y]}
                stroke="#aaa"          // ✅ gray ulit
                strokeWidth={1.5}
                opacity={0.9}
                listening={false}
              />
            );
          })}


          {/* ✅ Path Highlight */}
          {path.length > 1 && (() => {
            const points = [...path];
            const last = points[points.length - 1];
            const prev = points[points.length - 2];
            if (last.meta === "stall" && prev) points.pop();
            return (
              <Line
                points={points.flatMap((n) => [n.x, n.y])}
                stroke="#2196f3"
                strokeWidth={4}
                shadowColor="#1976d2"
                shadowBlur={mapEffect ? 12 : 6}
                opacity={mapEffect ? 1 : 0.9}
                lineCap="round"
                lineJoin="round"
              />
            );
          })()}

          {/* 📍 Pulse Halo */}
          {destinationStall && (
            <>
              <Circle
                x={destinationStall.x + destinationStall.width / 2}
                y={destinationStall.y + destinationStall.height / 2}
                radius={10}
                fill="#2196f3"
                shadowBlur={10}
                shadowColor="#2196f3"
              />
            </>
          )}

          {/* Map glow */}
          {mapEffect && (
            <Rect
              x={0}
              y={0}
              width={width}
              height={height}
              fill="rgba(33,150,243,0.12)"
              opacity={0.6}
              listening={false}
            />
          )}

          {/* ✅ Stalls */}
          {stalls.map((s) => (
            <Rect
              key={s.id}
              x={s.x}
              y={s.y}
              width={s.width}
              height={s.height}
              fill={s.fill || "#dadadaff"}
              stroke="#333"
              strokeWidth={0.5}
              cornerRadius={2}
              onClick={() => onSelectStall?.(s)}
              onTap={() => onSelectStall?.(s)}
            />
          ))}

          {/* ✅ Entrances */}
          {entrances.map((e) => (
            <Circle
              key={e.id}
              x={e.x}
              y={e.y}
              radius={e.radius || 10}
              fill={e.id === entrance?.id ? "#4caf50" : "#81c784"}
              stroke="#2e7d32"
              strokeWidth={1}
            />
          ))}

          {/* 🧭 YOU ARE HERE marker for current entrance */}
{entrance && (
  <Group x={entrance.x} y={entrance.y} listening={false}>
    {/* pulsing halo */}
    {(() => {
      const base = entrance.radius || 10;
      const r = base + 10 + herePulse * 18;
      const opacity = 0.35 * (1 - herePulse);
      return (
        <>
          <Circle radius={r} stroke="#2e7d32" strokeWidth={2} opacity={opacity} />
          <Circle radius={base} fill="#4caf50" shadowBlur={8} shadowColor="#2e7d32" />
        </>
      );
    })()}

    {/* label chip with pointer */}
    <Label x={0} y={-(entrance.radius || 10) - 5}>
      <Tag
        fill="#2e7d32"
        pointerDirection="down"
        pointerWidth={10}
        pointerHeight={6}
        cornerRadius={6}
        shadowBlur={4}
        shadowColor="rgba(0,0,0,0.25)"
      />
      <Text text="YOU ARE HERE" fill="#fff" fontStyle="bold" padding={6} fontSize={12}  />
    </Label>
  </Group>
)}

          {/* ✅ Street view pins */}
          {filteredStreetViews.map((s) => (
  <Circle
    key={s.id}
    x={s.x}
    y={s.y}
    radius={7}
    fill={selectedStreetView?.id === s.id ? "#4caf50" : "#1976d2"}
    shadowBlur={4}
    onClick={() => handleStreetViewSelect(s)}
    onTap={() => handleStreetViewSelect(s)}
    onMouseEnter={(e) => {
      e.target.scale({ x: 1.3, y: 1.3 });
      document.body.style.cursor = "pointer";
    }}
    onMouseLeave={(e) => {
      e.target.scale({ x: 1, y: 1 });
      document.body.style.cursor = "grab";
    }}
  />
))}

        </Layer>
      </Stage>

{/* 🧩 Floating Service Icons (HTML overlay) */}
<FloatingIcons icons={floatingIcons} />

{/* 📍 Overlay Location Pin (MUI icon) */}
<LocationPin pos={pinPos} />

{/* 🔘 Map Controls – clean vertical (all IconButtons) */}
  <Paper
  elevation={10}
  sx={(t) => ({
    position: "absolute",
    right: 16,
    top: 16,
    p: 0,
    borderRadius: 14,
    overflow: "hidden",
    bgcolor: alpha(t.palette.background.paper, 0.95),
    backdropFilter: "blur(10px)",
    border: `1px solid ${alpha(t.palette.divider, 0.6)}`,
    zIndex: 20,
      width: controlsCollapsed ? 40 : 56,
    boxShadow: "0 8px 18px rgba(0,0,0,.18)",
      // reduce footprint when mobile split-view is active
      transform: (effectiveStreetViewOpen && isMobile) ? 'scale(0.98)' : undefined,
  })}
>
  {controlsCollapsed ? [] : [
    { key: "zin",    title: "Zoom in",              onClick: () => zoomBy(1.2),      icon: <AddRoundedIcon /> },
    { key: "zout",   title: "Zoom out",             onClick: () => zoomBy(0.8),      icon: <RemoveRoundedIcon /> },
    { key: "reset",  title: "Reset view",           onClick: handleResetView,        icon: <RefreshRoundedIcon /> },
    { key: "sv",     title: effectiveStreetViewOpen ? "Close 360° viewer" : "Open 360° viewer",
                      onClick: () => effectiveSetStreetViewOpen(v => !v),
                      icon: <ThreeSixtyRoundedIcon /> },
    { key: "sep" },
    { key: "f-none",  title: "Hide street views", onClick: () => setSvFilter("none"),  label: "✖" },
    { key: "f-route", title: "Along route",       onClick: () => setSvFilter("route"), label: "≡",  value: "route" },
    { key: "f-all",   title: "Show all",          onClick: () => setSvFilter("all"),   label: "◎",  value: "all" },
  ].map((b, i, arr) => {
    if (b.key === "sep") {
      return <Divider key="sep" sx={{ my: 0 }} />;
    }

    const isFilter = !!b.label;
    const isActive = isFilter && svFilter === b.value;

    return (
      <Tooltip key={b.key} title={b.title} placement="left">
        <IconButton
          disableRipple
          onClick={b.onClick}
          sx={(t) => ({
            width: 56,
            height: 56,
            borderRadius: 0,
            justifyContent: "center",
            borderTop: i === 0 ? "none" : `1px solid ${alpha(t.palette.divider, .75)}`,
            color: isActive ? t.palette.primary.main : t.palette.text.primary,
            bgcolor: isActive ? alpha(t.palette.primary.main, 0.12) : "transparent",
            "&:hover": { bgcolor: alpha(t.palette.primary.main, 0.18) },
            "& .MuiSvgIcon-root": { fontSize: 22 },
            "&:focus": { outline: "none" },
            "& .MuiTouchRipple-root": { display: "none" },
          })}
          aria-label={b.title}
        >
          {isFilter ? (
            <span
              style={{
                fontSize: 18,
                fontWeight: 800,
                lineHeight: 1,
                fontFamily:
                  'system-ui, -apple-system, "Segoe UI", Roboto, Arial, "Noto Sans"',
                textDecoration: "none",
                userSelect: "none",
              }}
            >
              {b.label}
            </span>
          ) : (
            b.icon
          )}
        </IconButton>
      </Tooltip>
    );
  })}
</Paper>

{/* 🧭 Street View: Split-view (mobile) or Drawer (desktop) */}
{effectiveStreetViewOpen && isMobile ? (
  // Desktop Split-view (50/50)
  <Box
    sx={{
      flex: 1,
      height: "50%",
      display: "flex",
      flexDirection: "column",
      bgcolor: "#fafafa",
      borderTop: "1px solid #ddd",
      overflow: "hidden",
    }}
  >
    {selectedStreetView ? (
      <Street360Viewer
        src={selectedStreetView.imagePath}
        currentId={selectedStreetView.id}
        nextViews={memoizedNextViews}
        height="100%"
        onNavigate={(next) =>
          setSelectedStreetView({
            ...next,
            imagePath: resolveImageUrl(next.imagePath),
          })
        }
      />
    ) : (
      <Box
        sx={{
          flex: 1,
          display: "grid",
          placeItems: "center",
          color: "text.secondary",
        }}
      >
        Select a blue dot to view street 360°
      </Box>
    )}
  </Box>
) : (
  // Mobile Drawer
  <Drawer
    anchor={isMobile ? "bottom" : "right"}
    open={streetViewOpen}
    onClose={() => setStreetViewOpen(false)}
    PaperProps={{
      sx: {
        height: isMobile ? "60%" : "100%",
        width: isMobile ? "100%" : 480,
        borderTopLeftRadius: isMobile ? 16 : 0,
        borderTopRightRadius: isMobile ? 16 : 0,
        p: 1.5,
        display: "flex",
        flexDirection: "column",
        boxShadow: "0 -2px 12px rgba(0,0,0,0.25)",
      },
    }}
  >
    {selectedStreetView ? (
      <Street360Viewer
        src={selectedStreetView.imagePath}
        currentId={selectedStreetView.id}
        nextViews={memoizedNextViews}
        onNavigate={(next) =>
          setSelectedStreetView({
            ...next,
            imagePath: resolveImageUrl(next.imagePath),
          })
        }
      />
    ) : (
      <Box
        sx={{
          flexGrow: 1,
          display: "grid",
          placeItems: "center",
          color: "text.secondary",
        }}
      >
        Select a blue dot to view street 360°
      </Box>
    )}
  </Drawer>
)}

    </Box>

  );
}

export default React.memo(MapCanvas);