import axios from './axiosInstance';

const rentalApi = {
  // ✅ Ceemo Admin APIs
  create: (data) => axios.post('/rentals', data),
  previewCoverage: (data) => axios.post('/rentals/preview-coverage', data), // ✅ NEW

  getAll: (params) => axios.get('/rentals', { params }),
  getStallHistory: (stallId) => axios.get(`/rentals/stall/${stallId}`),
  getStatistics: (params) => axios.get('/rentals/statistics', { params }),
  update: (id, data) => axios.put(`/rentals/${id}`, data),
  delete: (id) => axios.delete(`/rentals/${id}`),

  // ✅ Vendor API
  getMyPayments: () => axios.get('/rentals/my-payments'),

  // 🧾 Ledger per stall
  getStallLedger: (stallId, params) =>
    axios.get(`/rentals/ledger/stall/${stallId}`, { params }),

  // 🚩 Vendors na walang kahit isang payment
  getVendorsWithoutPayments: () => axios.get('/rentals/no-payments'),

  // 🧾 Ledger per stall (Vendor – sarili lang)
  getMyStallLedger: (stallId) =>
    axios.get(`/rentals/my-ledger/stall/${stallId}`),
};

export default rentalApi;