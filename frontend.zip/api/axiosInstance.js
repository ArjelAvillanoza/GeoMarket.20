import axios from "axios";

/**
 * 🛠️ CONFIGURATION
 * * In Vite, import.meta.env variables are "baked in" during 'npm run build'.
 * We set the production URL as the final fallback so that if your .env 
 * fails to load, it defaults to your live Hostinger API.
 */
const API_ORIGIN = 
  import.meta.env.VITE_API_ORIGIN_API || "https://api.geomarket.space/api";

const axiosInstance = axios.create({
  baseURL: API_ORIGIN,
  timeout: 10000, // Optional: 10 second timeout
  headers: {
    "Content-Type": "application/json",
  }
});

/**
 * 🔓 REQUEST INTERCEPTOR
 * Attach the JWT token to every request automatically.
 */
axiosInstance.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

/**
 * 🛡️ RESPONSE INTERCEPTOR
 * Handle global errors, specifically 401 Unauthorized (Expired tokens).
 */
axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    // If the server returns 401, the user's session is likely expired
    if (error?.response?.status === 401) {
      console.warn("Unauthorized! Logging out...");
      
      localStorage.removeItem("token");
      localStorage.removeItem("user");

      // Redirect to login only if we are currently in a protected area (dashboard)
      if (typeof window !== "undefined") {
        const currentPath = window.location.pathname;
        if (currentPath.startsWith("/dashboard") || currentPath.startsWith("/admin")) {
          window.location.href = "/login";
        }
      }
    }
    
    // Pass the error along so the specific component can handle it too
    return Promise.reject(error);
  }
);

export default axiosInstance;