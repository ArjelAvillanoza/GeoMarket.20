// src/api/publicApi.js
import axios from "./axiosInstance";

const publicApi = {
  getEntrances: () => axios.get(`/public/entrances`),
  getEntrance: (entranceId) => axios.get(`/public/entrance/${entranceId}`),
  search: (layoutId, q) => axios.get(`/public/search`, { params: { layoutId, q } }),
  getDirections: (layoutId, fromId, toId) =>
    axios.get(`/map-layouts/${layoutId}/directions`, {
      params: { fromType: "entrance", fromId, toType: "stall", toId },
    }),
};


export default publicApi;
