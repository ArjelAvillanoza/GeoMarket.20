import axios from './axiosInstance';

const stallApi = {
  getAll: () => axios.get('/stalls'),
  getMyStalls: () => axios.get('/stalls/my'),
  create: (data) => axios.post('/stalls', data),
  update: (id, data) => axios.put(`/stalls/${id}`, data),
  assignVendor: (id, vendorId) =>
    axios.put(`/stalls/${id}/assign`, { vendorId }),
  updateBusiness: (stallId, data) =>
    axios.put(`/stalls/${stallId}/business`, data),
  delete: (id) => axios.delete(`/stalls/${id}`),

  // Masterlist
  getMasterlist: () => axios.get('/stalls/masterlist'),

  // update rent status (delinquent / promissory / etc.)
  updateRentStatus: (id, rentStatus) =>
    axios.put(`/stalls/${id}/rent-status`, { rentStatus }),
};

export default stallApi;
