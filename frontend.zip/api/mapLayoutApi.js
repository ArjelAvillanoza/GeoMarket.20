import axios from "./axiosInstance";

const mapLayoutApi = {
  create: (payload) => axios.post("/map-layouts", payload),
  list: () => axios.get("/map-layouts"),
  get: (id) => axios.get(`/map-layouts/${id}`),
  update: (id, data) => axios.put(`/map-layouts/${id}`, data),
  remove: (id) => axios.delete(`/map-layouts/${id}`),

  genEntranceQR: (id, entranceId) =>
    axios.post(`/map-layouts/${id}/entrances/${entranceId}/qrcode`),

  getDirections: (layoutId, { fromType, fromId, toType, toId }) =>
    axios.get(`/map-layouts/${layoutId}/directions`, {
      params: { fromType, fromId, toType, toId },
    }),

  uploadBackground: (id, file) => {
    const fd = new FormData();
    fd.append("bg", file);
    return axios.post(`/map-layouts/${id}/background`, fd, {
      headers: { "Content-Type": "multipart/form-data" },
    });
  },

  // Street views
  uploadStreetView: (id, streetId, file) => {
    const fd = new FormData();
    fd.append("image", file);
    return axios.post(`/map-layouts/${id}/street-views/${streetId}/image`, fd, {
      headers: { "Content-Type": "multipart/form-data" },
    });
  },
  streetStatus: (id, streetId) =>
    axios.get(`/map-layouts/${id}/street-views/${streetId}/status`),
  streetRegenerate: (id, streetId) =>
    axios.post(`/map-layouts/${id}/street-views/${streetId}/regenerate`),
  streetDelete: (id, streetId) =>
    axios.delete(`/map-layouts/${id}/street-views/${streetId}`),
  streetBulkGenerate: (id) =>
    axios.post(`/map-layouts/${id}/street-views/bulk-generate`),
};

export default mapLayoutApi;
