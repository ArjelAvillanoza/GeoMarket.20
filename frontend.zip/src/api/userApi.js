import axios from "./axiosInstance";

const userApi = {
  register: (data) => axios.post("/auth/register", data),
  login: (data) => axios.post("/auth/login", data),
  forgotPassword: (data) => axios.post("/users/forgot-password", data),
  verifyOtp: (data) => axios.post("/users/verify-otp", data),
  resetPassword: (data) => axios.post("/users/reset-password", data),
  getUsers: () => axios.get("/users"),
  getMe: () => axios.get("/users/me"),
updateProfile: (data) =>
  axios.put("/users/me/profile", data, {
    headers: { "Content-Type": "multipart/form-data" },
  }),
  updateBusiness: (data) => axios.put("/users/me/business", data),
  getUser: (id) => axios.get(`/users/${id}`),
  updateUser: (id, data) =>
  axios.put(`/users/${id}`, data, {
    headers: { "Content-Type": "multipart/form-data" },
  }),
  deleteUser: (id) => axios.delete(`/users/${id}`),
  generateInvite: () => axios.post("/invites/generate"),
};

export default userApi;
