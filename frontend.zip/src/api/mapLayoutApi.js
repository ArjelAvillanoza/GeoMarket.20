import axios from "./axiosInstance";

const round = (n, d = 2) =>
  typeof n === "number" && Number.isFinite(n) ? Number(n.toFixed(d)) : n;

const cleanDeep = (value) => {
  if (Array.isArray(value)) {
    return value.map(cleanDeep);
  }

  if (value && typeof value === "object") {
    const out = {};

    for (const [key, val] of Object.entries(value)) {
      // 🔥 ONLY remove safe junk
      if (
        key === "__v" ||
        key === "_id" ||
        key === "createdAt" ||
        key === "updatedAt" ||
        key === "selected" ||
        key === "isDragging" ||
        key === "isEditing" ||
        key === "temp" ||
        key === "hovered" ||
        key === "highlighted"
      ) {
        continue;
      }

      out[key] = cleanDeep(val);
    }

    return out;
  }

  if (typeof value === "number") {
    return round(value);
  }

  return value;
};

const optimizeLayoutPayload = (data) => {
  return cleanDeep({
    name: data.name,
    size: data.size,
    backgroundImage: data.backgroundImage,
    gpsBounds: data.gpsBounds,

    // ✅ KEEP FULL OBJECTS (DO NOT TRIM)
    stalls: data.stalls || [],
    entrances: data.entrances || [],
    pathNodes: data.pathNodes || [],
    pathEdges: data.pathEdges || [],
    streetViews: data.streetViews || [],
  });
};

const mapLayoutApi = {
  create: (payload) => axios.post("/map-layouts", optimizeLayoutPayload(payload)),

  list: () => axios.get("/map-layouts"),

  get: (id) => axios.get(`/map-layouts/${id}`),

  update: (id, data) => {
    const payload = optimizeLayoutPayload(data);

    console.log(
      "Payload size:",
      new Blob([JSON.stringify(payload)]).size
    );

    return axios.put(`/map-layouts/${id}`, payload);
  },

  remove: (id) => axios.delete(`/map-layouts/${id}`),

  genEntranceQR: (id, entranceId) =>
    axios.post(`/map-layouts/${id}/entrances/${entranceId}/qrcode`),

  getDirections: (layoutId, { fromType, fromId, toType, toId }) =>
    axios.get(`/map-layouts/${layoutId}/directions`, {
      params: { fromType, fromId, toType, toId },
    }),

  uploadBackground: (id, file) => {
    const fd = new FormData();
    fd.append("bg", file);
    return axios.post(`/map-layouts/${id}/background`, fd, {
      headers: { "Content-Type": "multipart/form-data" },
    });
  },

  uploadStreetView: (id, streetId, file) => {
    const fd = new FormData();
    fd.append("image", file);
    return axios.post(`/map-layouts/${id}/street-views/${streetId}/image`, fd, {
      headers: { "Content-Type": "multipart/form-data" },
    });
  },

  streetStatus: (id, streetId) =>
    axios.get(`/map-layouts/${id}/street-views/${streetId}/status`),

  streetRegenerate: (id, streetId) =>
    axios.post(`/map-layouts/${id}/street-views/${streetId}/regenerate`),

  streetDelete: (id, streetId) =>
    axios.delete(`/map-layouts/${id}/street-views/${streetId}`),

  streetBulkGenerate: (id) =>
    axios.post(`/map-layouts/${id}/street-views/bulk-generate`),
};

export default mapLayoutApi;