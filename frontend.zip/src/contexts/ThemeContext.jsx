// src/contexts/ThemeContext.jsx
import React, { createContext, useMemo, useState, useEffect } from "react";
import { ThemeProvider, CssBaseline } from "@mui/material";
import { createAppTheme } from "../theme/muiTheme";

export const ThemeModeContext = createContext({
  mode: "light",
  toggleMode: () => { },
});

export default function AppThemeProvider ({ children }) {
  const [mode, setMode] = useState(localStorage.getItem("themeMode") || "light");

  const toggleMode = () => {
    setMode((prev) => {
      const newMode = prev === "light" ? "dark" : "light";
      localStorage.setItem("themeMode", newMode);
      return newMode;
    });
  };

  const theme = useMemo(() => createAppTheme(mode), [mode]);

  useEffect(() => {
    document.body.style.backgroundColor =
      mode === "light" ? "#f9f9f9" : "#0f1117";
  }, [mode]);

  return (
    <ThemeModeContext.Provider value={{ mode, toggleMode }}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        {children}
      </ThemeProvider>
    </ThemeModeContext.Provider>
  );
}
