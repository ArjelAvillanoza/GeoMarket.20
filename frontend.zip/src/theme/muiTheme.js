// src/theme/muiTheme.js
import { createTheme } from "@mui/material/styles";

const getDesignTokens = (mode) => ({
  palette: {
    mode,
    primary: { main: "#4B56D2" },
    secondary: { main: "#f50057" },
    background: {
      default: mode === "light" ? "#f9f9f9" : "#1b1b1f",
      paper: mode === "light" ? "#ffffff" : "#25262b",
    },
    text: {
      primary: mode === "light" ? "#1C1C28" : "#f4f4f9",
      secondary: mode === "light" ? "#6f738a" : "#c2c3cc",
    },
    divider: mode === "light" ? "rgba(0,0,0,0.08)" : "rgba(255,255,255,0.1)",
  },
  shape: { borderRadius: 12 },
  typography: {
    fontFamily: `"Inter", "Poppins", sans-serif`,
  },
});

export const createAppTheme = (mode = "light") =>
  createTheme(getDesignTokens(mode));
