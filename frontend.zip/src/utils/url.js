const API_ORIGIN = import.meta.env.VITE_API_ORIGIN || "https://api.geomarket.space";

export function resolveImageUrl(path) {
  if (!path) return "";
  if (path.startsWith("blob:") || path.startsWith("data:")) return path;
  if (/^https?:\/\//i.test(path)) return path;

  if (path.startsWith("/")) return `${API_ORIGIN}${path}`;
  return `${API_ORIGIN}/${path}`;
}

export { API_ORIGIN };