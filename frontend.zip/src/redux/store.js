import { configureStore } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import stallReducer from "./slices/stallSlice";

const store = configureStore({
  reducer: {
    auth: authReducer,
    stalls: stallReducer
  },
});

export default store;
