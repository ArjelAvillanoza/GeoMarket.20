import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import stallApi from "../../api/stallApi";

export const fetchStalls = createAsyncThunk("stalls/fetch", async () => {
  const res = await stallApi.getAll();
  return res.data;
});

export const createStall = createAsyncThunk("stalls/create", async (data) => {
  const res = await stallApi.create(data);
  return res.data;
});

export const updateStall = createAsyncThunk(
  "stalls/update",
  async ({ id, data }) => {
    const res = await stallApi.update(id, data);
    return res.data;
  }
);

export const deleteStall = createAsyncThunk("stalls/delete", async (id) => {
  await stallApi.delete(id);
  return id;
});

const stallSlice = createSlice({
  name: "stalls",
  initialState: {
    list: [],
    loading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchStalls.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchStalls.fulfilled, (state, action) => {
        state.list = action.payload;
        state.loading = false;
      })
      .addCase(createStall.fulfilled, (state, action) => {
        state.list.push(action.payload);
      })
      .addCase(updateStall.fulfilled, (state, action) => {
        const idx = state.list.findIndex((s) => s.id === action.payload.id);
        if (idx >= 0) state.list[idx] = action.payload;
      })
      .addCase(deleteStall.fulfilled, (state, action) => {
        state.list = state.list.filter((s) => s.id !== action.payload);
      });
  },
});

export default stallSlice.reducer;
