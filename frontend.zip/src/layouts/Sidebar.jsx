import React, { useState } from "react";
import {
  Drawer,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Collapse,
  Box,
  Tooltip,
  BottomNavigation,
  BottomNavigationAction,
  Paper,
  useMediaQuery,
} from "@mui/material";
import DashboardRoundedIcon from "@mui/icons-material/DashboardRounded";
import StorefrontRoundedIcon from "@mui/icons-material/StorefrontRounded";
import MapRoundedIcon from "@mui/icons-material/MapRounded";
import BusinessCenterRoundedIcon from "@mui/icons-material/BusinessCenterRounded";
import AccountCircleRoundedIcon from "@mui/icons-material/AccountCircleRounded";
import LogoutRoundedIcon from "@mui/icons-material/LogoutRounded";
import ExpandLess from "@mui/icons-material/ExpandLess";
import ExpandMore from "@mui/icons-material/ExpandMore";
import PaymentRoundedIcon from "@mui/icons-material/PaymentRounded";
import { useTheme } from "@mui/material/styles";
import { useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";

export default function Sidebar ({ open, role, roleSegment }) {
  const navigate = useNavigate();
  const location = useLocation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const [submenuOpen, setSubmenuOpen] = useState(true);

  const drawerWidth = open ? 250 : 78;
  const base = `/dashboard/${roleSegment}`;
  const profilePath = `${base}/profile`;
  const isActive = (path) => location.pathname === path;

  const darkText = "#F2F3F9";
  const darkSecondary = "#B7B9C9";
  const darkHover = "#2E3244";
  const darkSelected = "#454B63";
  const darkSelectedGlow = "0 0 6px rgba(91,99,177,0.35)";

  const handleLogout = () => {
    localStorage.clear();
    navigate("/");
  };

  // ✅ --- MOBILE VERSION (Bottom Navigation) ---
  const mobileItems =
    role === "ceemo_admin"
      ? [
        { label: "Profile", icon: <AccountCircleRoundedIcon />, path: profilePath },
        { label: "User Manage", icon: <DashboardRoundedIcon />, path: base },
        { label: "Map Layouts", icon: <MapRoundedIcon />, path: "/dashboard/ceemo/map-layouts" },
        { label: "Stall Masterlist", icon: <BusinessCenterRoundedIcon />, path: "/dashboard/ceemo/stall-masterlist" },
        { label: "Rentals", icon: <PaymentRoundedIcon />, path: "/dashboard/ceemo/rentals" },
      ]
      : [
        { label: "Profile", icon: <AccountCircleRoundedIcon />, path: profilePath },
        { label: "My Stall", icon: <StorefrontRoundedIcon />, path: "/dashboard/vendor/stalls" },
        { label: "Business", icon: <BusinessCenterRoundedIcon />, path: "/dashboard/vendor/business" },
        { label: "Payments", icon: <PaymentRoundedIcon />, path: "/dashboard/vendor/payments" },
      ];

  if (isMobile) {
    const activeIndex = mobileItems.findIndex((item) => isActive(item.path));
    return (
      <Paper
        elevation={3}
        sx={{
          position: "fixed",
          bottom: 0,
          left: 0,
          right: 0,
          zIndex: 1201,
          borderTop: `1px solid ${theme.palette.divider}`,
          backdropFilter: "blur(10px)",
          background:
            theme.palette.mode === "light"
              ? "rgba(255,255,255,0.9)"
              : "rgba(30,30,40,0.85)",
        }}
      >
        <BottomNavigation
          showLabels
          value={activeIndex === -1 ? 0 : activeIndex}
          onChange={(e, newValue) => {
            // ✅ Check if logout button was clicked (last item)
            if (newValue === mobileItems.length) {
              handleLogout();
            } else {
              navigate(mobileItems[newValue].path);
            }
          }}
          sx={{
            "& .Mui-selected": { color: theme.palette.primary.main },
          }}
        >
          {mobileItems.map((item, index) => (
            <BottomNavigationAction
              key={index}
              label={item.label}
              icon={item.icon}
              sx={{
                color:
                  isActive(item.path) && theme.palette.mode === "dark"
                    ? theme.palette.primary.light
                    : theme.palette.text.secondary,
                "&.Mui-selected": { color: theme.palette.primary.main },
              }}
            />
          ))}

          {/* 🔴 Logout button on mobile */}
          <BottomNavigationAction
            label="Logout"
            icon={<LogoutRoundedIcon />}
            sx={{ color: theme.palette.error.main }}
          />
        </BottomNavigation>
      </Paper>
    );
  }

  // ✅ --- DESKTOP VERSION (Sidebar Drawer) ---
  const NavItem = ({ icon, label, path, nested = false, onClick }) => (
    <Tooltip title={!open ? label : ""} placement="right">
      <ListItemButton
        onClick={onClick || (() => navigate(path))}
        selected={path ? isActive(path) : false}
        sx={{
          mx: 1.3,
          mb: 0.4,
          py: 1.05,
          pl: nested && open ? 6 : 2.2,
          borderRadius: 2,
          transition: "all 0.25s ease",
          "&.Mui-selected": {
            backgroundColor:
              theme.palette.mode === "light" ? "#EEF0FF" : darkSelected,
            boxShadow:
              theme.palette.mode === "light"
                ? `inset 3px 0 0 ${theme.palette.primary.main}`
                : `inset 3px 0 0 ${theme.palette.primary.main}, ${darkSelectedGlow}`,
            "& .MuiListItemIcon-root, & .MuiListItemText-primary": {
              color:
                theme.palette.mode === "light"
                  ? theme.palette.primary.main
                  : "#AEB4FF",
              fontWeight: 600,
            },
          },
          "&:hover": {
            backgroundColor:
              theme.palette.mode === "light" ? "#F5F6FB" : darkHover,
          },
        }}
      >
        <ListItemIcon
          sx={{
            minWidth: open ? 42 : "auto",
            color:
              theme.palette.mode === "light"
                ? theme.palette.text.secondary
                : darkSecondary,
            justifyContent: "center",
          }}
        >
          {icon}
        </ListItemIcon>
        {open && (
          <ListItemText
            primary={label}
            primaryTypographyProps={{
              fontWeight: 500,
              fontSize: 15,
              color:
                theme.palette.mode === "light"
                  ? theme.palette.text.primary
                  : darkText,
            }}
          />
        )}
      </ListItemButton>
    </Tooltip>
  );

  return (
    <motion.div
      animate={{ width: drawerWidth }}
      transition={{ type: "spring", stiffness: 180, damping: 25 }}
    >
      <Drawer
        variant="permanent"
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          "& .MuiDrawer-paper": {
            width: drawerWidth,
            background:
              theme.palette.mode === "light"
                ? "linear-gradient(180deg,#FFFFFF 0%,#F9FAFC 100%)"
                : "linear-gradient(180deg,#171821 0%,#1E1F29 100%)",
            borderRight:
              theme.palette.mode === "light"
                ? "1px solid #E5E6F0"
                : "1px solid rgba(255,255,255,0.08)",
          },
        }}
      >
        {/* Header Logo */}
        <Box
          sx={{
            height: 70,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            borderBottom:
              theme.palette.mode === "light"
                ? "1px solid #EEE"
                : "1px solid rgba(255,255,255,0.1)",
          }}
        >
          <motion.img
            src={open ? "/favicon-96x96.png" : "/favicon.svg"}
            alt="GeoMarket Logo"
            style={{
              height: open ? 42 : 30,
              opacity: 0.9,
              transition: "all 0.3s ease",
              filter:
                theme.palette.mode === "light"
                  ? "none"
                  : "invert(1) brightness(0.9)",
            }}
          />
        </Box>

        {/* Drawer Menu */}
        <List sx={{ mt: 1.5 }}>
          {role === "ceemo_admin" ? (
            <>
              <NavItem
                icon={<AccountCircleRoundedIcon />}
                label="Profile"
                path={profilePath}
              />
              <NavItem
                icon={<DashboardRoundedIcon />}
                label="User Manage"
                path={base}
              />

              <ListItemButton
                onClick={() => setSubmenuOpen(!submenuOpen)}
                sx={{
                  mx: 1.3,
                  mb: 0.5,
                  py: 1.1,
                  borderRadius: 2,
                  "&:hover": {
                    backgroundColor:
                      theme.palette.mode === "light"
                        ? "#f7fbf5ff"
                        : darkHover,
                  },
                }}
              >
                <ListItemIcon
                  sx={{
                    minWidth: open ? 40 : "auto",
                    color:
                      theme.palette.mode === "light"
                        ? theme.palette.text.secondary
                        : darkSecondary,
                    justifyContent: "center",
                  }}
                >
                  <StorefrontRoundedIcon />
                </ListItemIcon>
                {open && (
                  <>
                    <ListItemText
                      primary="Vendors"
                      primaryTypographyProps={{
                        fontWeight: 500,
                        fontSize: 15,
                        color:
                          theme.palette.mode === "light"
                            ? theme.palette.text.primary
                            : darkText,
                      }}
                    />
                    {submenuOpen ? <ExpandLess /> : <ExpandMore />}
                  </>
                )}
              </ListItemButton>

              <Collapse in={submenuOpen} timeout="auto" unmountOnExit>
                <NavItem
                  icon={<MapRoundedIcon fontSize="small" />}
                  label="Map Layouts"
                  path="/dashboard/ceemo/map-layouts"
                  nested
                />
                <NavItem
                  icon={<BusinessCenterRoundedIcon fontSize="small" />}
                  label="Stall Masterlist"
                  path="/dashboard/ceemo/stall-masterlist"
                  nested
                />
              </Collapse>

              {/* ✅ NEW: Rental Management */}
              <NavItem
                icon={<PaymentRoundedIcon />}
                label="Rental Manage"
                path="/dashboard/ceemo/rentals"
              />
            </>
          ) : (
            <>
              <NavItem
                icon={<AccountCircleRoundedIcon />}
                label="Profile"
                path={profilePath}
              />
              <NavItem
                icon={<StorefrontRoundedIcon />}
                label="My Stall"
                path="/dashboard/vendor/stalls"
              />
              <NavItem
                icon={<BusinessCenterRoundedIcon />}
                label="Business"
                path="/dashboard/vendor/business"
              />
              {/* ✅ NEW: Payment History */}
              <NavItem
                icon={<PaymentRoundedIcon />}
                label="Payments"
                path="/dashboard/vendor/payments"
              />
            </>
          )}

          {/* 🔴 Logout button at bottom */}
          <Box sx={{ mt: 2 }}>
            <NavItem
              icon={<LogoutRoundedIcon color="error" />}
              label="Logout"
              onClick={handleLogout}
            />
          </Box>
        </List>

        {/* Footer */}
        <Box
          sx={{
            position: "absolute",
            bottom: 0,
            width: "100%",
            py: 2,
            textAlign: "center",
            fontSize: 12,
            color:
              theme.palette.mode === "light"
                ? theme.palette.text.secondary
                : "#A0A1B3",
            borderTop:
              theme.palette.mode === "light"
                ? "1px solid #eee"
                : "1px solid rgba(255,255,255,0.08)",
          }}
        >
          {open ? "© GeoMarket 2025" : "©"}
        </Box>
      </Drawer>
    </motion.div>
  );
}