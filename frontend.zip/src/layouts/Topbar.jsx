import React from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Box,
  Fade,
  useMediaQuery,
} from "@mui/material";
import MenuRoundedIcon from "@mui/icons-material/MenuRounded";
import { useTheme } from "@mui/material/styles";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

export default function Topbar ({ toggleSidebar, role, roleSegment }) {
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const isTablet = useMediaQuery(theme.breakpoints.between("sm", "md"));

  return (
    <Fade in timeout={600}>
      <AppBar
        position="fixed"
        elevation={0}
        sx={{
          backdropFilter: "blur(14px)",
          background:
            theme.palette.mode === "light"
              ? "linear-gradient(135deg, #AFBDF2 100%)"
              : "linear-gradient(90deg, rgba(25,25,32,0.9) 0%, rgba(45, 42, 35, 0.9) 100%)",
          borderBottom:
            theme.palette.mode === "light"
              ? "1px solid rgba(230,230,240,0.6)"
              : "1px solid rgba(80,80,90,0.5)",
          boxShadow:
            theme.palette.mode === "light"
              ? "0 2px 8px rgba(0,0,0,0.04)"
              : "0 2px 8px rgba(0,0,0,0.6)",
          zIndex: (t) => t.zIndex.drawer + 2,
          transition: "background 0.4s ease",
        }}
      >
        <Toolbar
          sx={{
            display: "flex",
            justifyContent: "space-between",
            minHeight: 70,
            px: { xs: 2, sm: 3, md: 4 },
          }}
        >
          {/* ✅ LEFT SECTION */}
          <Box sx={{ display: "flex", alignItems: "center", gap: 1.8 }}>
            {/* Sidebar toggle */}
            {!isMobile && (
              <motion.div whileTap={{ scale: 0.9 }}>
                <IconButton onClick={toggleSidebar} color="#ffffff">
                  <MenuRoundedIcon sx={{ fontSize: 26 , color: "#ffff"}} />
                </IconButton>
              </motion.div>
            )}

            {/* ✅ Logo */}
            <Box
              sx={{
                width: 60,
                height: 60,
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                
              }}
              
            >
              <Box
                component="img"
                src="/favicon.svg"
                alt="GeoMarket Logo"
                sx={{
                  width: isMobile ? 45 : isTablet ? 44 : 65,
                  height: isMobile ? 45 : isTablet ? 44 : 65,
                  
                }}
              />
            </Box>

            {/* ✅ Responsive Title */}
            <Typography
              sx={{
                fontWeight: 700,
                letterSpacing: 0.3,
                cursor: "pointer",
                color: theme.palette.text.primary,
                display: "flex",
                alignItems: "center",
                lineHeight: 1,
                position: "relative",
                top: "3px",
                fontSize: {
                  xs: "1.30rem", // ~20px (mobile)
                  sm: "1.5rem",  // ~24px (tablet)
                  md: "1.75rem", // ~28px (desktop)
                },
              }}
            >
              GeoMarket&nbsp;
              <Typography
                component="span"
                sx={{
                  color: "#ffffff",
                  fontWeight: 700,
                  fontSize: {
                    xs: "1.25rem",
                    sm: "1.5rem",
                    md: "1.75rem",
                  },
                }}
              >
                {role === "ceemo_admin" ? "Admin" : "Vendor"}
              </Typography>
            </Typography>
          </Box>
        </Toolbar>
      </AppBar>
    </Fade>
  );
}
