// src/layouts/DashboardLayout.jsx
import React, { useState, useMemo } from "react";
import { Box, Toolbar } from "@mui/material";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import { Outlet } from "react-router-dom";
import { useSelector } from "react-redux";

export default function DashboardLayout ({ toggleMode }) {
  const [open, setOpen] = useState(true);
  const toggleSidebar = () => setOpen(!open);

  // ✅ 1. Try Redux first
  const reduxUser = useSelector((s) => s.auth.user);

  // ✅ 2. Then fallback to localStorage (important for refresh/navigation)
  const localUser =
    typeof window !== "undefined"
      ? JSON.parse(localStorage.getItem("user") || "null")
      : null;

  const user = reduxUser || localUser;

  // ✅ 3. Role resolution logic stays stable
  const role = user?.role;
  const roleSegment =
    role === "ceemo_admin" ? "ceemo" : role === "vendor" ? "vendor" : "vendor";

  return (
    <Box sx={{ display: "flex", minHeight: "100vh" }}>
      <Topbar
        toggleSidebar={toggleSidebar}
        role={role}
        roleSegment={roleSegment}
        user={user}
        toggleMode={toggleMode}
      />
      <Sidebar open={open} role={role} roleSegment={roleSegment} />
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          minHeight: "100vh",
          borderTopLeftRadius: 20,
          borderTopRightRadius: 20,
          transition: "all 0.4s ease",
        }}
      >
        <Toolbar />
        <Outlet />
      </Box>
    </Box>
  );
}
