// src/App.jsx
import React, { useMemo, useState, useEffect } from "react";
import { ThemeProvider, CssBaseline, IconButton, Box, useMediaQuery } from "@mui/material";
import { Brightness4, Brightness7 } from "@mui/icons-material";
import { createAppTheme } from "./theme/muiTheme";
import AppRoutes from "./routes/AppRoutes";
import { BrowserRouter, useLocation } from "react-router-dom";

function InnerApp () {
  const storedMode = localStorage.getItem("themeMode") || "light";
  const [mode, setMode] = useState(storedMode);
  const theme = useMemo(() => createAppTheme(mode), [mode]);
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const location = useLocation();

  const toggleMode = () => {
    const newMode = mode === "light" ? "dark" : "light";
    setMode(newMode);
    localStorage.setItem("themeMode", newMode);
  };

  useEffect(() => {
    document.body.style.backgroundColor = theme.palette.background.default;
  }, [theme]);

  // ✅ Hide toggle button on Rental Management page (and other routes if needed)
  const hideGlobalToggle = [
    
    "/public/entrance/",
  ].some((path) => location.pathname.startsWith(path));

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />

      {/* ✅ Only show toggle button if not hidden */}
      {!hideGlobalToggle && (
        <Box
          sx={{
            position: "fixed",
            bottom: isMobile ? 80 : 20,
            right: 20,
            bgcolor: theme.palette.background.paper,
            boxShadow: "0 2px 10px rgba(0,0,0,0.15)",
            borderRadius: "50%",
            zIndex: 1600,
          }}
        >
          <IconButton onClick={toggleMode} color="inherit" size="large">
            {mode === "light" ? <Brightness4 /> : <Brightness7 />}
          </IconButton>
        </Box>
      )}

      <AppRoutes toggleMode={toggleMode} />
    </ThemeProvider>
  );
}


// ✅ Wrap everything in one BrowserRouter
export default function App () {
  return (
    <BrowserRouter>
      <InnerApp />
    </BrowserRouter>
  );
}
