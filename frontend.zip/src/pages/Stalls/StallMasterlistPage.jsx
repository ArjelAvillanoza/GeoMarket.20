import React, { useEffect, useState, useMemo } from "react";
import {
  Box,
  Typography,
  Paper,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  CircularProgress,
  Chip,
  useTheme,
  Fade,
  TablePagination,
  TextField,
  InputAdornment,
  Breadcrumbs,
  Link,
  Button,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
} from "@mui/material";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import DownloadRoundedIcon from "@mui/icons-material/DownloadRounded";
import HomeRoundedIcon from "@mui/icons-material/HomeRounded";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import stallApi from "../../api/stallApi";

export default function StallMasterlistPage() {
  const [loading, setLoading] = useState(true);
  const [stalls, setStalls] = useState([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const theme = useTheme();

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await stallApi.getMasterlist();
        setStalls(res.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, []);

  const statusOptions = [
    { label: "All", value: "all" },
    { label: "Vacant", value: "vacant" },
    { label: "Occupied", value: "occupied" },
    { label: "Delinquent", value: "delinquent" },
    { label: "Promissory", value: "promissory" },
    { label: "No Permit", value: "no_permit" },
  ];

  const getStatusChip = (status) => {
    const map = {
      vacant: { color: "success", label: "Vacant" },
      occupied: { color: "primary", label: "Occupied" },
      delinquent: { color: "warning", label: "Delinquent" },
      promissory: { color: "info", label: "Promissory" },
      no_permit: { color: "error", label: "No Permit" },
    };
    const cfg = map[status] || { color: "default", label: status };
    return <Chip label={cfg.label} color={cfg.color} size="small" />;
  };

  const handleChangePage = (event, newPage) => setPage(newPage);
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // ✅ Apply filters
  const filteredStalls = useMemo(() => {
    return stalls.filter((s) => {
      const matchesSearch = [s.layoutName, s.stallName, s.vendorName, s.vendorEmail]
        .join(" ")
        .toLowerCase()
        .includes(search.toLowerCase());
      const matchesStatus = statusFilter === "all" || s.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [stalls, search, statusFilter]);

  const paginatedStalls = filteredStalls.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  // ✅ Export filtered rows to CSV
  const handleExportCSV = () => {
    const header = [
      "Stall Name",
      "Status",
      "Rate",
      "Vendor Name",
      "Vendor Email",
    ];
    const csvRows = [
      header.join(","),
      ...filteredStalls.map((s) =>
        [
          s.layoutName,
          s.stallName,
          s.status,
          s.rate,
          s.vendorName,
          s.vendorEmail,
        ]
          .map((v) => `"${v ?? ""}"`)
          .join(",")
      ),
    ];

    const blob = new Blob([csvRows.join("\n")], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "stall_masterlist_filtered.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

    const handleStatusChange = async (stallId, newStatus) => {
    try {
      // send to backend
      await stallApi.updateRentStatus(stallId, newStatus);
      // update local state
      setStalls((prev) =>
        prev.map((s) =>
          s.stallId === stallId ? { ...s, status: newStatus } : s
        )
      );
    } catch (err) {
      console.error("Update rent status failed:", err);
      alert("Failed to update stall rent status.");
    }
  };


  if (loading)
    return (
      <Box sx={{ display: "flex", justifyContent: "center", mt: 8 }}>
        <CircularProgress />
      </Box>
    );

  return (
    <Fade in timeout={600}>
      <Box sx={{ p: { xs: 2, sm: 3 }, color: theme.palette.text.primary }}>


        {/* ✅ Title + Export */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            mb: 2,
          }}
        >
          <Typography variant="h5" fontWeight={700} fontSize={35}>
            Stall Masterlist
          </Typography>
          <Button
            variant="contained"
            startIcon={<DownloadRoundedIcon />}
            onClick={handleExportCSV}
            sx={{ borderRadius: 2, textTransform: "none", fontWeight: 600 }}
          >
            Export CSV
          </Button>
        </Box>

        {/* ✅ Search + Status Filter */}
        <Box
          sx={{
            display: "flex",
            gap: 2,
            flexWrap: "wrap",
            mb: 2,
          }}
        >
          <TextField
            placeholder="Search layout, stall, or vendor..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(0);
            }}
            variant="outlined"
            size="small"
            fullWidth
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchRoundedIcon
                    sx={{ color: theme.palette.text.secondary }}
                  />
                </InputAdornment>
              ),
            }}
            sx={{
              flex: 1,
              "& .MuiOutlinedInput-root": {
                backgroundColor:
                  theme.palette.mode === "light"
                    ? "#fff"
                    : "rgba(255,255,255,0.05)",
              },
            }}
          />

          <FormControl size="small" sx={{ minWidth: 160 }}>
            <InputLabel>Status</InputLabel>
            <Select
              label="Status"
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setPage(0);
              }}
              sx={{
                backgroundColor:
                  theme.palette.mode === "light"
                    ? "#fff"
                    : "rgba(255,255,255,0.05)",
              }}
            >
              {statusOptions.map((opt) => (
                <MenuItem key={opt.value} value={opt.value}>
                  {opt.label}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Box>

        {/* ✅ Table with filter row in header */}
        <Box
          sx={{
            overflowX: "auto",
            borderRadius: 1,
          }}
        >
          <Table size="small">
            <TableHead>
              <TableRow
                sx={{
                  background:
                    theme.palette.mode === "light"
                      ? "#f4f5fb"
                      : "rgba(255,255,255,0.06)",
                }}
              >
                {[
                  "Stall Name",
                  "Status",
                  "Rate",
                  "Vendor Name",
                  "Vendor Email",
                ].map((h, i) => (
                  <TableCell
                    key={i}
                    sx={{
                      fontWeight: 600,
                      color: theme.palette.text.primary,
                      fontSize: 14,
                    }}
                  >
                    {h}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>

            <TableBody>
              {paginatedStalls.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} align="center" sx={{ py: 3 }}>
                    No matching records found.
                  </TableCell>
                </TableRow>
              ) : (
                paginatedStalls.map((s, i) => (
                  <TableRow
                    key={i}
                    hover
                    sx={{
                      "&:hover": {
                        backgroundColor:
                          theme.palette.mode === "light"
                            ? "rgba(75,86,210,0.06)"
                            : "rgba(75,86,210,0.15)",
                      },
                    }}
                  >
                    <TableCell>{s.stallName}</TableCell>
                    <TableCell>
                      <FormControl size="small" sx={{ minWidth: 140 }}>
                        <Select
                          value={s.status || "vacant"}
                          onChange={(e) => handleStatusChange(s.stallId, e.target.value)}
                          sx={{
                            backgroundColor:
                              theme.palette.mode === "light"
                                ? "#fff"
                                : "rgba(255,255,255,0.05)",
                          }}
                        >
                          {statusOptions
                            .filter((opt) => opt.value !== "all")
                            .map((opt) => (
                              <MenuItem key={opt.value} value={opt.value}>
                                {opt.label}
                              </MenuItem>
                            ))}
                        </Select>
                      </FormControl>
                    </TableCell>

                    <TableCell>₱ {s.rate?.toLocaleString()}</TableCell>
                    <TableCell>{s.vendorName}</TableCell>
                    <TableCell sx={{ color: theme.palette.text.secondary }}>
                      {s.vendorEmail}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>

          {/* Pagination */}
          <TablePagination
            component="div"
            count={filteredStalls.length}
            page={page}
            onPageChange={handleChangePage}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={handleChangeRowsPerPage}
            rowsPerPageOptions={[5, 10, 25, 50]}
            sx={{
              "& .MuiTablePagination-toolbar": {
                background:
                  theme.palette.mode === "light"
                    ? "#fafafa"
                    : "rgba(255,255,255,0.04)",
                justifyContent: "flex-start", // ✅ Aligns to left
              },
              "& .MuiTablePagination-spacer": {
                flex: "none",
              },
            }}
          />

        </Box>
      </Box>
    </Fade>
  );
}
