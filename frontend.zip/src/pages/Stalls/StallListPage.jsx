import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  fetchStalls,
  createStall,
  deleteStall,
} from "../../redux/slices/stallSlice";
import mapLayoutApi from "../../api/mapLayoutApi";
import stallApi from "../../api/stallApi";
import {
  Box,
  Typography,
  CircularProgress,
  Chip,
  Button,
  Stack,
  MenuItem,
  TextField,
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import StallFormDialog from "./StallFormDialog";
import AssignVendorDialog from "./AssignVendorDialog";

export default function StallListPage () {
  const dispatch = useDispatch();
  const { list, loading } = useSelector((state) => state.stalls);

  const [layouts, setLayouts] = useState([]);
  const [selectedLayout, setSelectedLayout] = useState("");
  const [openAdd, setOpenAdd] = useState(false);
  const [openAssign, setOpenAssign] = useState(false);
  const [selectedStall, setSelectedStall] = useState(null);

  // Load layouts & stalls
  useEffect(() => {
    const loadLayouts = async () => {
      try {
        const res = await mapLayoutApi.list();
        setLayouts(res.data);
        if (res.data.length && !selectedLayout) {
          setSelectedLayout(res.data[0]._id);
        }
      } catch (err) {
        console.error(err);
      }
    };
    loadLayouts();
    dispatch(fetchStalls());
  }, [dispatch]);

  const handleLayoutChange = (e) => {
    setSelectedLayout(e.target.value);
  };

  const handleAdd = async (data) => {
    if (!selectedLayout) {
      alert("Please select a layout first.");
      return;
    }
    await dispatch(createStall({ ...data, layoutId: selectedLayout }));
    setOpenAdd(false);
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this stall?")) {
      await dispatch(deleteStall(id));
    }
  };

  const handleAssign = async (vendorId) => {
    if (!selectedStall) return;
    try {
      await stallApi.assignVendor(selectedStall.id, vendorId);
      dispatch(fetchStalls());
      setOpenAssign(false);
    } catch (err) {
      console.error("Assign failed:", err);
    }
  };

  // -------------------------------
  // Table Columns
  // -------------------------------
  const columns = [
    { field: "label", headerName: "Label", flex: 1 },
    { field: "name", headerName: "Name", flex: 1 },
    {
      field: "status",
      headerName: "Status",
      flex: 1,
      renderCell: (params) => {
        const color =
          params.value === "vacant"
            ? "success"
            : params.value === "occupied"
              ? "error"
              : "warning";
        return <Chip label={params.value} color={color} />;
      },
    },
    {
      field: "vendor",
      headerName: "Vendor",
      flex: 1.5,
      valueGetter: (params) => {
        // Defensive checks against undefined
        if (!params || !params.row) return "—";
        const vendorId = params.row.meta?.vendorId;
        const vendorName = params.row.meta?.vendorName;
        if (vendorName) return vendorName;
        if (vendorId) return vendorId;
        return "Vacant";
      },
    },
    {
      field: "layoutName",
      headerName: "Layout",
      flex: 1,
      valueGetter: (params) => {
        if (!params || !params.row) return "—";
        return params.row.layoutName || "—";
      },
    },
    {
      field: "actions",
      headerName: "Actions",
      flex: 1.5,
      renderCell: (params) => {
        if (!params || !params.row) return null;
        return (
          <Stack direction="row" spacing={1}>
            <Button
              size="small"
              variant="outlined"
              onClick={() => {
                setSelectedStall(params.row);
                setOpenAssign(true);
              }}
            >
              Assign
            </Button>
            <Button
              size="small"
              color="error"
              variant="outlined"
              onClick={() => handleDelete(params.row.id)}
            >
              Delete
            </Button>
          </Stack>
        );
      },
    },
  ];

  // -------------------------------
  // Render
  // -------------------------------
  return (
    <Box sx={{ height: "80vh", p: 2 }}>
      {/* Header */}
      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        mb={2}
      >
        <Typography variant="h5">Stall Management</Typography>
        <Stack direction="row" spacing={2} alignItems="center">
          <TextField
            select
            size="small"
            label="Layout"
            value={selectedLayout}
            onChange={handleLayoutChange}
            sx={{ minWidth: 200 }}
          >
            {layouts.map((l) => (
              <MenuItem key={l._id} value={l._id}>
                {l.name}
              </MenuItem>
            ))}
          </TextField>
          <Button variant="contained" onClick={() => setOpenAdd(true)}>
            Add Stall
          </Button>
        </Stack>
      </Stack>

      {/* Table */}
      {loading ? (
        <CircularProgress />
      ) : (
        <DataGrid
          rows={Array.isArray(list) ? list : []}
          getRowId={(r) => r.id || r._id}
          columns={columns}
          pageSize={10}
          autoHeight
          disableRowSelectionOnClick
        />
      )}

      {/* Dialogs */}
      <StallFormDialog
        open={openAdd}
        onClose={() => setOpenAdd(false)}
        onSave={handleAdd}
      />
      <AssignVendorDialog
        open={openAssign}
        onClose={() => setOpenAssign(false)}
        onAssign={handleAssign}
      />
    </Box>
  );
}
