import React, { useEffect, useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  MenuItem,
  CircularProgress,
  Stack,
  Typography,
} from "@mui/material";
import userApi from "../../api/userApi";

/**
 * Props:
 *  - open (bool)
 *  - onClose (fn)
 *  - onAssign (fn) => called with vendorId or null
 */
export default function AssignVendorDialog ({ open, onClose, onAssign }) {
  const [vendors, setVendors] = useState([]);
  const [selectedVendor, setSelectedVendor] = useState("");
  const [loading, setLoading] = useState(false);

  // Load all vendor accounts when dialog opens
  useEffect(() => {
    if (!open) return;
    const load = async () => {
      setLoading(true);
      try {
        const res = await userApi.getUsers();
        const vendorUsers = res.data.filter((u) => u.role === "vendor");
        setVendors(vendorUsers);
      } catch (err) {
        console.error("Failed to load vendors:", err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [open]);

  const handleAssign = () => {
    if (!selectedVendor) {
      alert("Please select a vendor.");
      return;
    }
    onAssign(selectedVendor);
  };

  const handleUnassign = () => {
    if (window.confirm("Remove vendor from this stall?")) {
      onAssign(null);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="xs">
      <DialogTitle>Assign Vendor</DialogTitle>
      <DialogContent>
        {loading ? (
          <Stack alignItems="center" py={3}>
            <CircularProgress size={32} />
            <Typography variant="body2" mt={1}>
              Loading vendor list...
            </Typography>
          </Stack>
        ) : (
          <TextField
            select
            fullWidth
            label="Select Vendor"
            value={selectedVendor}
            onChange={(e) => setSelectedVendor(e.target.value)}
            sx={{ mt: 1 }}
          >
            {vendors.map((v) => (
              <MenuItem key={v._id} value={v._id}>
                {v.name || v.email} ({v.email})
              </MenuItem>
            ))}
            {vendors.length === 0 && (
              <MenuItem disabled>No vendors found</MenuItem>
            )}
          </TextField>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button color="error" onClick={handleUnassign}>
          Unassign
        </Button>
        <Button variant="contained" onClick={handleAssign}>
          Assign
        </Button>
      </DialogActions>
    </Dialog>
  );
}
