  import React, { useState, useEffect, useMemo } from "react";
  import {
    Box,
    Typography,
    Paper,
    Table,
    TableHead,
    TableRow,
    TableCell,
    TableBody,
    CircularProgress,
    Chip,
    useTheme,
    Fade,
    TablePagination,
    TextField,
    InputAdornment,
    Breadcrumbs,
    Link,
    Button,
    MenuItem,
    FormControl,
    InputLabel,
    Select,
    IconButton,
    Stack,
    Tooltip,
    Alert,
    Drawer,
    Divider,
    Autocomplete,
  } from "@mui/material";
  import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
  import DownloadRoundedIcon from "@mui/icons-material/DownloadRounded";
  import HomeRoundedIcon from "@mui/icons-material/HomeRounded";
  import NavigateNextIcon from "@mui/icons-material/NavigateNext";
  import AddRoundedIcon from "@mui/icons-material/AddRounded";
  import EditRoundedIcon from "@mui/icons-material/EditRounded";
  import DeleteRoundedIcon from "@mui/icons-material/DeleteRounded";
  import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
  import ReceiptLongRoundedIcon from "@mui/icons-material/ReceiptLongRounded";
  import ChevronLeftRoundedIcon from "@mui/icons-material/ChevronLeftRounded";
  import ChevronRightRoundedIcon from "@mui/icons-material/ChevronRightRounded";
  import rentalApi from "../../api/rentalApi";
  import stallApi from "../../api/stallApi";
  import userApi from "../../api/userApi";
  import mapLayoutApi from "../../api/mapLayoutApi";
  import { format, addMonths } from "date-fns";

  export default function RentalManagementPage () {
    const theme = useTheme();
    const [loading, setLoading] = useState(true);
    const [payments, setPayments] = useState([]);
    const [search, setSearch] = useState("");
    const [statusFilter, setStatusFilter] = useState("all");
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);

    // Ledger drawer state
    const [ledgerOpen, setLedgerOpen] = useState(false);
    const [ledgerLoading, setLedgerLoading] = useState(false);
    const [ledgerData, setLedgerData] = useState(null);
    const [ledgerError, setLedgerError] = useState("");
    const [ledgerPayment, setLedgerPayment] = useState(null); // selected row

    const [previewLoading, setPreviewLoading] = useState(false);
    const [previewData, setPreviewData] = useState(null);
    const [previewError, setPreviewError] = useState("");

    const [paymentLedgerLoading, setPaymentLedgerLoading] = useState(false);
    const [paymentLedgerData, setPaymentLedgerData] = useState(null);
    const [paymentLedgerError, setPaymentLedgerError] = useState("");
    const [paymentCalendarMonth, setPaymentCalendarMonth] = useState(new Date());
      // No-payment vendors panel
    const [noPayVendors, setNoPayVendors] = useState([]);
    const [noPayLoading, setNoPayLoading] = useState(false);

      // Calendar state (for ledger)
    const [calendarMonth, setCalendarMonth] = useState(null); // Date

    // Form dialog
    const [openDialog, setOpenDialog] = useState(false);
    const [editingPayment, setEditingPayment] = useState(null);
    const [vendors, setVendors] = useState([]);
    const [layouts, setLayouts] = useState([]);
    const [stalls, setStalls] = useState([]);
    const [error, setError] = useState("");

    const [formData, setFormData] = useState({
    stallId: "",
    layoutId: "",
    vendorId: "",

    computeMode: "AUTO_RANGE", 
    amount: "",                

    paymentMode: "cash",
    periodStart: "",
    periodEnd: "",

    status: "pending",
    paidAt: "",
    notes: "",
  });
    useEffect(() => {
      fetchPayments();
      fetchVendors();
      fetchLayouts();
      fetchStalls();
      fetchNoPaymentVendors(); // ADD
    }, []);


    // 🔍 Find selected stall object (from stalls list)
    const selectedStall = useMemo(() => {
      if (!formData.stallId) return null;
      return stalls.find((s) => s.id === formData.stallId) || null;
    }, [stalls, formData.stallId]);

    // 🔢 Compute payable days (Mon–Sat only)
   const computePayableDays = (startStr, endStr) => {
      if (!startStr || !endStr) return 0;
      
      // Use the string directly to create a local date
      const start = new Date(startStr);
      start.setHours(0, 0, 0, 0);
      
      const end = new Date(endStr);
      end.setHours(0, 0, 0, 0);
      
      if (isNaN(start) || isNaN(end) || end < start) return 0;

      let count = 0;
      const d = new Date(start);

      while (d <= end) {
        if (d.getDay() !== 0) count++; // Skip Sunday (0)
        d.setDate(d.getDate() + 1);
      }
      return count;
    };

    const toLocalIso = (dateLike) => {
      if (!dateLike) return "";
      const d = new Date(dateLike);
      d.setHours(0, 0, 0, 0);
      if (Number.isNaN(d.getTime())) return "";
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, "0");
      const day = String(d.getDate()).padStart(2, "0");
      return `${year}-${month}-${day}`;
    };

    const getPayableIsoDates = (startStr, endStr) => {
      if (!startStr || !endStr) return [];
      const start = new Date(startStr);
      const end = new Date(endStr);
      start.setHours(0, 0, 0, 0);
      end.setHours(0, 0, 0, 0);
      if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end < start) return [];

      const dates = [];
      const cursor = new Date(start);
      while (cursor <= end) {
        if (cursor.getDay() !== 0) {
          dates.push(toLocalIso(cursor));
        }
        cursor.setDate(cursor.getDate() + 1);
      }
      return dates;
    };

    const payableDays = useMemo(
      () => computePayableDays(formData.periodStart, formData.periodEnd),
      [formData.periodStart, formData.periodEnd]
    );

    const dailyRate = selectedStall?.rate ?? 0;
    const computedAmount = dailyRate && payableDays ? dailyRate * payableDays : 0;

    const selectedPayableDates = useMemo(
      () => getPayableIsoDates(formData.periodStart, formData.periodEnd),
      [formData.periodStart, formData.periodEnd]
    );

    const overlappingPaidDates = useMemo(() => {
      const paidSet = new Set(paymentLedgerData?.paidDates || []);
      return selectedPayableDates.filter((iso) => paidSet.has(iso));
    }, [paymentLedgerData, selectedPayableDates]);

    const hasPaidOverlap = overlappingPaidDates.length > 0;

      useEffect(() => {
    if (formData.computeMode !== "AUTO_RANGE") return;

    setFormData((prev) => {
      const nextAmount = computedAmount || "";
      if (String(prev.amount) === String(nextAmount)) return prev;
      return { ...prev, amount: nextAmount };
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [computedAmount, formData.computeMode]);

    const fetchPayments = async () => {
      setLoading(true);
      try {
        const res = await rentalApi.getAll();
        setPayments(res.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    const fetchVendors = async () => {
      const res = await userApi.getUsers();
      setVendors(res.data.filter((u) => u.role === "vendor"));
    };

    const fetchLayouts = async () => {
      const res = await mapLayoutApi.list();
      setLayouts(res.data);
    };

    const fetchStalls = async () => {
      const res = await stallApi.getAll();
      setStalls(res.data);
    };
    const runPreview = async () => {
    try {
      setPreviewError("");
      setPreviewData(null);

      if (formData.computeMode !== "CUSTOM_AMOUNT") return;
      if (!formData.stallId || !formData.layoutId || !formData.vendorId) return;

      const amount = Number(formData.amount);
      if (!Number.isFinite(amount) || amount <= 0) return;

      setPreviewLoading(true);

      const res = await rentalApi.previewCoverage({
        stallId: formData.stallId,
        layoutId: formData.layoutId,
        vendorId: formData.vendorId,
        amount,
      });

      setPreviewData(res.data);
    } catch (err) {
      setPreviewError(err?.response?.data?.message || "Preview failed");
    } finally {
      setPreviewLoading(false);
    }
  };
  useEffect(() => {
    runPreview();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    formData.computeMode,
    formData.amount,
    formData.stallId,
    formData.layoutId,
    formData.vendorId,
  ]);

  useEffect(() => {
    const fetchPaymentLedger = async () => {
      if (!openDialog || !formData.stallId || !formData.vendorId) {
        setPaymentLedgerData(null);
        setPaymentLedgerError("");
        return;
      }

      try {
        setPaymentLedgerLoading(true);
        setPaymentLedgerError("");
        const res = await rentalApi.getStallLedger(formData.stallId, {
          vendorId: formData.vendorId,
        });
        const data = res.data;
        setPaymentLedgerData(data);

        const baseStr =
          formData.periodStart ||
          data.coveredUntil ||
          (data.paidDates && data.paidDates[0]) ||
          (data.unpaidDates && data.unpaidDates[0]);

        setPaymentCalendarMonth(baseStr ? new Date(baseStr) : new Date());
      } catch (err) {
        setPaymentLedgerData(null);
        setPaymentLedgerError(
          err?.response?.data?.message || "Failed to load existing coverage"
        );
      } finally {
        setPaymentLedgerLoading(false);
      }
    };

    fetchPaymentLedger();
    }, [openDialog, formData.stallId, formData.vendorId, formData.periodStart]);

          useEffect(() => {
            if (
              openDialog &&
              formData.computeMode === "CUSTOM_AMOUNT" &&
              previewData?.startDate
            ) {
              setPaymentCalendarMonth(new Date(previewData.startDate));
            }
          }, [openDialog, formData.computeMode, previewData]);



    const handleChangePage = (e, newPage) => setPage(newPage);
    const handleChangeRowsPerPage = (e) => {
      setRowsPerPage(parseInt(e.target.value, 10));
      setPage(0);
    };

    const handleOpenDialog = (payment = null) => {
      setEditingPayment(payment);
      if (payment) {
        setFormData({
          stallId: payment.stallId,
          layoutId: payment.layoutId?._id || payment.layoutId,
          vendorId: payment.vendorId?._id || payment.vendorId,
          computeMode: payment.computeMode || "AUTO_RANGE",
          amount: (payment.computeMode === "CUSTOM_AMOUNT"
              ? (payment.inputAmount || payment.amount)
              : payment.amount) ?? "",
          paymentMode: payment.paymentMode,
          // Use slice(0, 10) to get YYYY-MM-DD safely
          periodStart: payment.periodStart ? payment.periodStart.slice(0, 10) : "",
          periodEnd: payment.periodEnd ? payment.periodEnd.slice(0, 10) : "",
          status: payment.status,
          paidAt: payment.paidAt ? payment.paidAt.slice(0, 10) : "",
          notes: payment.notes || "",
        });
      } else {
        setFormData({
          stallId: "",
          layoutId: "",
          vendorId: "",
          computeMode: "AUTO_RANGE",
          amount: "",
          paymentMode: "cash",
          periodStart: "",
          periodEnd: "",
          status: "pending",
          paidAt: "",
          notes: "",
        });
      }
      setPaymentLedgerData(null);
      setPaymentLedgerError("");
      setPaymentCalendarMonth(new Date());
      setOpenDialog(true);
      setError("");
    };

    const handleCloseDialog = () => {
      setOpenDialog(false);
      setPaymentLedgerData(null);
      setPaymentLedgerError("");
    };

    const handleSubmit = async () => {
      try {
        setError("");

        if (formData.computeMode === "AUTO_RANGE" && hasPaidOverlap) {
          setError(
            `Selected period overlaps already-paid day(s): ${overlappingPaidDates
              .slice(0, 6)
              .join(", ")}${overlappingPaidDates.length > 6 ? "..." : ""}`
          );
          return;
        }

        if (editingPayment) await rentalApi.update(editingPayment._id, formData);
        else await rentalApi.create(formData);
        fetchPayments();
        handleCloseDialog();
      } catch (err) {
        setError(err.response?.data?.message || "Failed to save payment");
      }
    };

    const handleDelete = async (id) => {
      if (!confirm("Delete this payment record?")) return;
      await rentalApi.delete(id);
      fetchPayments();
    };

    const handleExportCSV = () => {
      const header = [
        "Layout",
        "Stall",
        "Vendor",
        "Amount",
        "Mode",
        "Status",
        "Days Paid",
      ];

      const csvRows = [
        header.join(","),
        ...filteredPayments.map((p) =>
          [
            p.layoutId?.name,
            p.stallLabel || p.stallId,
            p.vendorId?.name,
            p.amount,
            p.paymentMode,
            p.status,
            p.daysPaid ?? "",
          ]
            .map((v) => `"${v ?? ""}"`)
            .join(",")
        ),
      ];

      const blob = new Blob([csvRows.join("\n")], {
        type: "text/csv;charset=utf-8;",
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", "rental_records.csv");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };

  const getStatusChip = (status) => {
    // Map to associate status with color and label
    const statusMap = {
      paid: { color: "success", label: "Paid" },
      pending: { color: "warning", label: "Pending" },
      overdue: { color: "error", label: "Overdue" },
    };

    // Get the config for the given status, default to 'default' if status not found
    const statusConfig = statusMap[status] || { color: "default", label: "Unknown" };

    // Return the Chip component with dynamic label and color based on status
    return (
      <Chip 
        label={statusConfig.label} 
        color={statusConfig.color} 
        size="small" 
      />
    );
  };

    const filteredPayments = useMemo(() => {
      return payments.filter((p) => {
        const matchSearch = [
          p.layoutId?.name,
          p.vendorId?.name,
          p.paymentMode,
          p.status,
        ]
          .join(" ")
          .toLowerCase()
          .includes(search.toLowerCase());
        const matchStatus = statusFilter === "all" || p.status === statusFilter;
        return matchSearch && matchStatus;
      });
    }, [payments, search, statusFilter]);

    const paginated = filteredPayments.slice(
      page * rowsPerPage,
      page * rowsPerPage + rowsPerPage
    );

    const handleInputChange = (e) => {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    // Filter stalls by selected layout
    const filteredStalls = formData.layoutId
      ? stalls.filter((s) => s.layoutId === formData.layoutId)
      : stalls;


    const handleViewLedger = async (payment) => {
      try {
        setLedgerPayment(payment);
        setLedgerOpen(true);
        setLedgerLoading(true);
        setLedgerError("");
        setLedgerData(null);
        setCalendarMonth(null);

        const params = payment.vendorId?._id ? { vendorId: payment.vendorId._id } : {};
        const res = await rentalApi.getStallLedger(payment.stallId, params);
        const data = res.data;

      console.log("📥 Ledger API response:", data);
      console.log("✅ Paid Dates:", data.paidDates);
      console.log("❌ Unpaid Dates:", data.unpaidDates);

setLedgerData(data);
        // 🗓 base date for calendar:
        // 1) coveredUntil, 2) first paid date, 3) first unpaid date, 4) today
        const baseStr =
          data.coveredUntil ||
          (data.paidDates && data.paidDates[0]) ||
          (data.unpaidDates && data.unpaidDates[0]);

        if (baseStr) {
          setCalendarMonth(new Date(baseStr));
        } else {
          setCalendarMonth(new Date());
        }
 } catch (err) {
  console.error("Ledger load error:", {
    message: err?.message,
    status: err?.response?.status,
    data: err?.response?.data,
    url: err?.config?.url,
    params: err?.config?.params,
  });
  setLedgerError(err?.response?.data?.message || "Failed to load ledger");
} finally {


        setLedgerLoading(false);
      }
    };


    const fetchNoPaymentVendors = async () => {
      try {
        setNoPayLoading(true);
        const res = await rentalApi.getVendorsWithoutPayments();
        setNoPayVendors(res.data || []);
      } catch (err) {
        console.error("Error fetching vendors without payments:", err);
      } finally {
        setNoPayLoading(false);
      }
    };


    const renderCoverageCalendar = ({
      monthDate,
      ledger,
      onPrev,
      onNext,
      selectedDates = [],
      mode = "ledger",
    }) => {
      if (!monthDate || !ledger) return null;

      const year = monthDate.getFullYear();
      const month = monthDate.getMonth();
      const firstDay = new Date(year, month, 1);
      const lastDay = new Date(year, month + 1, 0);
      const days = [];

      for (let d = new Date(firstDay); d <= lastDay; d.setDate(d.getDate() + 1)) {
        days.push(new Date(d));
      }

      const blankCells = Array.from({ length: firstDay.getDay() });
      const paidSet = new Set((ledger.paidDates || []).map((d) => d));
      const unpaidSet = new Set(ledger.unpaidDates || []);
      const selectedSet = new Set(selectedDates);

      return (
        <Box sx={{ mb: 2 }}>
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
            sx={{ mb: 1 }}
          >
            <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
              {mode === "form" ? "Existing Coverage" : "Calendar Coverage"}
            </Typography>
            <Stack direction="row" spacing={1} alignItems="center">
              <IconButton size="small" onClick={onPrev}>
                <ChevronLeftRoundedIcon fontSize="small" />
              </IconButton>
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {format(monthDate, "MMMM yyyy")}
              </Typography>
              <IconButton size="small" onClick={onNext}>
                <ChevronRightRoundedIcon fontSize="small" />
              </IconButton>
            </Stack>
          </Stack>

          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: "repeat(7, 1fr)",
              gap: 0.5,
              mb: 0.5,
            }}
          >
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
              <Box
                key={d}
                sx={{
                  textAlign: "center",
                  fontSize: 11,
                  fontWeight: 600,
                  color: "text.secondary",
                }}
              >
                {d}
              </Box>
            ))}
          </Box>

          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: "repeat(7, 1fr)",
              gap: 0.5,
            }}
          >
            {blankCells.map((_, idx) => (
              <Box key={`blank-${idx}`} />
            ))}

            {days.map((dateObj) => {
              const iso = toLocalIso(dateObj);
              const isSunday = dateObj.getDay() === 0;
              const isPaid = paidSet.has(iso);
              const isUnpaid = unpaidSet.has(iso);
              const isSelected = selectedSet.has(iso);
              const isConflict = isSelected && isPaid;

              let sx = {
                borderRadius: 2,
                py: 0.9,
                px: 0.25,
                textAlign: "center",
                fontSize: 13,
                border: `1px solid ${theme.palette.divider}`,
                color: "text.primary",
                backgroundColor: theme.palette.background.paper,
              };

              if (isSunday) {
                sx = {
                  ...sx,
                  color: "text.disabled",
                  backgroundColor:
                    theme.palette.mode === "light"
                      ? "rgba(0,0,0,0.04)"
                      : "rgba(255,255,255,0.05)",
                };
              }
              if (isUnpaid) {
                sx = {
                  ...sx,
                  color: theme.palette.error.main,
                  borderColor: theme.palette.error.main,
                  backgroundColor: "rgba(244,67,54,0.08)",
                };
              }
              if (isPaid) {
                sx = {
                  ...sx,
                  color: theme.palette.success.dark,
                  borderColor: theme.palette.success.main,
                  backgroundColor: "rgba(76,175,80,0.12)",
                };
              }
              if (isSelected) {
                sx = {
                  ...sx,
                  borderColor: theme.palette.info.main,
                  boxShadow: `inset 0 0 0 1px ${theme.palette.info.main}`,
                };
              }
              if (isConflict) {
                sx = {
                  ...sx,
                  color: theme.palette.error.dark,
                  borderColor: theme.palette.error.main,
                  backgroundColor: "rgba(244,67,54,0.16)",
                  boxShadow: `inset 0 0 0 1px ${theme.palette.error.main}`,
                };
              }

              return (
                <Box key={iso} sx={sx}>
                  {dateObj.getDate()}
                </Box>
              );
            })}
          </Box>

          <Stack direction="row" spacing={2} flexWrap="wrap" sx={{ mt: 1.25 }}>
            <Stack direction="row" spacing={0.75} alignItems="center">
              <Box sx={{ width: 12, height: 12, borderRadius: "50%", backgroundColor: theme.palette.success.main }} />
              <Typography variant="caption" color="text.secondary">Paid</Typography>
            </Stack>
            <Stack direction="row" spacing={0.75} alignItems="center">
              <Box sx={{ width: 12, height: 12, borderRadius: "50%", backgroundColor: theme.palette.error.main }} />
              <Typography variant="caption" color="text.secondary">Unpaid</Typography>
            </Stack>
            {mode === "form" && (
              <Stack direction="row" spacing={0.75} alignItems="center">
                <Box sx={{ width: 12, height: 12, borderRadius: 0.75, border: `2px solid ${theme.palette.info.main}` }} />
                <Typography variant="caption" color="text.secondary">
                  {formData.computeMode === "CUSTOM_AMOUNT" ? "Preview coverage" : "Selected range"}
                </Typography>
              </Stack>
            )}
            <Stack direction="row" spacing={0.75} alignItems="center">
              <Box sx={{ width: 12, height: 12, borderRadius: "50%", backgroundColor: theme.palette.action.disabledBackground }} />
              <Typography variant="caption" color="text.secondary">Sunday excluded</Typography>
            </Stack>
          </Stack>
        </Box>
      );
    };

    if (loading)
      return (
        <Box sx={{ display: "flex", justifyContent: "center", mt: 8 }}>
          <CircularProgress />
        </Box>
      );

    return (
      <Fade in timeout={600}>
        <Box sx={{ p: { xs: 2, sm: 3 } }}>
          {/* Breadcrumbs */}
          <Breadcrumbs
            separator={<NavigateNextIcon fontSize="small" />}
            sx={{ mb: 2 }}
          >
            <Link
              underline="hover"
              color="inherit"
              sx={{
                display: "flex",
                alignItems: "center",
                cursor: "pointer",
                "&:hover": { color: theme.palette.primary.main },
              }}
              onClick={() => (window.location.href = "/dashboard/ceemo")}
            >
              <HomeRoundedIcon sx={{ mr: 0.5 }} fontSize="inherit" />
              Home
            </Link>
            <Typography color="text.primary">Rental Management</Typography>
          </Breadcrumbs>

          {/* Header */}
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              mb: 2,
            }}
          >
            <Typography variant="h5" fontWeight={700}>
              Rental Management
            </Typography>
            <Box sx={{ display: "flex", gap: 1 }}>
              <Button
                variant="outlined"
                startIcon={<DownloadRoundedIcon />}
                onClick={handleExportCSV}
                sx={{ borderRadius: 2, textTransform: "none" }}
              >
                Export CSV
              </Button>
              <Button
                variant="contained"
                startIcon={<AddRoundedIcon />}
                onClick={() => handleOpenDialog()}
                sx={{ borderRadius: 2, textTransform: "none" }}
              >
                Add Payment
              </Button>
            </Box>
          </Box>

          {/* Search + Filter */}
          <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap", mb: 2 }}>
            <TextField
              placeholder="Search layout, vendor, or mode..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(0);
              }}
              size="small"
              fullWidth
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchRoundedIcon />
                  </InputAdornment>
                ),
              }}
              sx={{
                flex: 1,
                "& .MuiOutlinedInput-root": {
                  backgroundColor:
                    theme.palette.mode === "light" ? "#fff" : "rgba(255,255,255,0.05)",
                },
              }}
            />
            <FormControl size="small" sx={{ minWidth: 160 }}>
              <InputLabel>Status</InputLabel>
              <Select
                label="Status"
                value={statusFilter}
                onChange={(e) => {
                  setStatusFilter(e.target.value);
                  setPage(0);
                }}
              >
                <MenuItem value="all">All</MenuItem>
                <MenuItem value="paid">Paid</MenuItem>
                <MenuItem value="pending">Pending</MenuItem>
                <MenuItem value="overdue">Overdue</MenuItem>
              </Select>
            </FormControl>
          </Box>

          {/* Table */}
          <Paper sx={{ overflowX: "auto" }}>
            <Table size="small">
              <TableHead>
                <TableRow
                  sx={{
                    background:'transparent',
                  }}
                >
                  {[
                    "Layout",
                    "Stall",
                    "Vendor",
                    "Amount",
                    "Days",
                    "Period",
                    "Status",
                    "Paid At",
                    "Actions",
                  ].map((h, i) => (
                    <TableCell key={i} sx={{ fontWeight: 600 }}>
                      {h}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {paginated.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} align="center">
                      No matching records.
                    </TableCell>
                  </TableRow>
                ) : (
                  paginated.map((p) => (
                    <TableRow key={p._id} hover>
                      <TableCell>{p.layoutId?.name || "—"}</TableCell>
                      <TableCell>{p.stallLabel}</TableCell>
                      <TableCell>{p.vendorId?.name || "—"}</TableCell>
                      <TableCell>₱{p.amount.toLocaleString()}</TableCell>
                      <TableCell>{p.daysPaid ?? "—"}</TableCell>
                      <TableCell>
                        {format(new Date(p.periodStart), "MMM dd")} -{" "}
                        {format(new Date(p.periodEnd), "MMM dd, yyyy")}
                      </TableCell>
                      <TableCell>{getStatusChip(p.status)}</TableCell>
                      <TableCell>
                        {p.paidAt ? format(new Date(p.paidAt), "MMM dd, yyyy") : "—"}
                      </TableCell>
                      <TableCell align="center">
                        <Stack direction="row" spacing={0.5} justifyContent="center">
                          <Tooltip title="View Ledger">
                            <IconButton size="small" onClick={() => handleViewLedger(p)}>
                              <ReceiptLongRoundedIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Edit">
                            <IconButton size="small" onClick={() => handleOpenDialog(p)}>
                              <EditRoundedIcon fontSize="small" color="primary" />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Delete">
                            <IconButton size="small" onClick={() => handleDelete(p._id)}>
                              <DeleteRoundedIcon fontSize="small" color="error" />
                            </IconButton>
                          </Tooltip>
                        </Stack>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
            <TablePagination
              component="div"
              count={filteredPayments.length}
              page={page}
              onPageChange={handleChangePage}
              rowsPerPage={rowsPerPage}
              onRowsPerPageChange={handleChangeRowsPerPage}
              rowsPerPageOptions={[5, 10, 25, 50]}
            />
          </Paper>

                  {/* 🚩 Vendors with no payments yet */}
          {noPayVendors.length > 0 && (
            <Paper
              sx={{
                mb: 2.5,
                p: 2,
                borderLeft: `4px solid ${theme.palette.warning.main}`,
                backgroundColor:
                  theme.palette.mode === "light"
                    ? "rgba(255, 193, 7, 0.08)"
                    : "rgba(255, 193, 7, 0.15)",
              }}
            >
              <Stack
                direction="row"
                justifyContent="space-between"
                alignItems="center"
                spacing={1.5}
              >
                <Box>
                  <Typography
                    variant="subtitle1"
                    sx={{ fontWeight: 700, mb: 0.5 }}
                  >
                    Vendors with no payment records
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    These vendors have assigned stalls but no rental payments yet.
                  </Typography>
                </Box>
                {noPayLoading && <CircularProgress size={20} />}
              </Stack>

              <Box sx={{ mt: 1.5 }}>
                {noPayVendors.map((v) => (
                  <Box
                    key={v.vendorId}
                    sx={{
                      py: 1,
                      borderTop: `1px dashed ${theme.palette.divider}`,
                    }}
                  >
                    <Typography variant="body2" sx={{ fontWeight: 600 }}>
                      {v.name || "Unnamed Vendor"}
                    </Typography>
                    <Typography
                      variant="body2"
                      color="text.secondary"
                      sx={{ mb: 0.5 }}
                    >
                      {v.email} {v.phone ? `• ${v.phone}` : ""}
                    </Typography>
                    <Stack direction="row" spacing={1} flexWrap="wrap">
                      {v.stalls.map((s) => (
                        <Chip
                          key={`${v.vendorId}-${s.stallId}`}
                          size="small"
                          label={`${s.layoutName} • ${s.stallLabel}`}
                          sx={{ mb: 0.5 }}
                        />
                      ))}
                    </Stack>
                  </Box>
                ))}
              </Box>
            </Paper>
          )}


          {/* Drawer for Add/Edit Payment */}
          {/* Drawer for Add/Edit Payment */}
          <Drawer
            anchor="right"
            open={openDialog}
            onClose={handleCloseDialog}
            PaperProps={{
              sx: {
                width: { xs: "100%", sm: 500 },
                display: "flex",
                flexDirection: "column",
                backgroundColor: theme.palette.background.paper,
                borderLeft: `1px solid ${theme.palette.divider}`,
                boxShadow: "-4px 0 20px rgba(0,0,0,0.25)",
                borderTopLeftRadius: { xs: 0, sm: 8 },
                borderBottomLeftRadius: { xs: 0, sm: 8 },
                zIndex: (theme) => theme.zIndex.drawer + 3, // 👈 ensure above AppBar
              },
            }}
            ModalProps={{
              keepMounted: true, // improves open performance on mobile
              sx: {
                zIndex: (theme) => theme.zIndex.drawer + 3, // 👈 fix for overlay & backdrop
              },
            }}
          >

            {/* Header */}
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                p: 2.5,
                borderBottom: `1px solid ${theme.palette.divider}`,
                backgroundColor:
                  theme.palette.mode === "dark"
                    ? "rgba(255,255,255,0.03)"
                    : "rgba(0,0,0,0.02)",
              }}
            >
              <Typography variant="h6" fontWeight={700}>
                {editingPayment ? "Edit Payment" : "Add Payment"}
              </Typography>
              <IconButton onClick={handleCloseDialog}>
                <CloseRoundedIcon />
              </IconButton>
            </Box>

            {/* Scrollable Content */}
            <Box sx={{ flex: 1, overflowY: "auto", p: 3 }}>
              {error && (
                <Alert severity="error" sx={{ mb: 2 }}>
                  {error}
                </Alert>
              )}

              {/* Section: Details */}
              <Typography
                variant="subtitle2"
                sx={{
                  mb: 1,
                  color: "text.secondary",
                  fontWeight: 600,
                  letterSpacing: 0.3,
                }}
              >
                Details
              </Typography>

              <Stack spacing={2.5} sx={{ mb: 3 }}>
                {/* Layout Autocomplete */}
                {/* Layout Autocomplete */}
                <Autocomplete
                  size="small"
                  options={layouts}
                  getOptionLabel={(option) => option.name || ""}
                  value={layouts.find((l) => l._id === formData.layoutId) || null}
                  onChange={(e, newValue) =>
                    setFormData((prev) => ({
                      ...prev,
                      layoutId: newValue ? newValue._id : "",
                      stallId: "",   // reset stall when layout changes
                      vendorId: "",  // 🔹 reset vendor too
                    }))
                  }
                  renderInput={(params) => (
                    <TextField {...params} label="Layout" required fullWidth />
                  )}
                />


                {/* Stall Autocomplete */}
                <Autocomplete
                  size="small"
                  options={filteredStalls}
                  getOptionLabel={(option) => {
                      const base = option.name || option.label || option.id || "";

                      const rawVendor =
                        option.vendorId ||
                        option.meta?.vendorId ||
                        null;

                      let vendorName = "";

                      if (rawVendor && typeof rawVendor === "object") {
                        vendorName = rawVendor.name || rawVendor.email || "";
                      } else if (typeof rawVendor === "string") {
                        const matchedVendor = vendors.find((v) => v._id === rawVendor);
                        vendorName = matchedVendor
                          ? matchedVendor.name || matchedVendor.email || ""
                          : "";
                      }

                      return vendorName ? `${base} — ${vendorName}` : base;
                    }}
                  value={filteredStalls.find((s) => s.id === formData.stallId) || null}
                  onChange={(e, newValue) =>
                      setFormData((prev) => {
                        let vendorId = "";

                        const rawVendor =
                          newValue?.vendorId ||
                          newValue?.meta?.vendorId ||
                          "";

                        if (typeof rawVendor === "string") {
                          vendorId = rawVendor;
                        } else if (typeof rawVendor === "object" && rawVendor) {
                          vendorId = rawVendor._id || rawVendor.id || "";
                        }

                        return {
                          ...prev,
                          stallId: newValue ? newValue.id : "",
                          vendorId,
                        };
                      })
                    }
                  disabled={!formData.layoutId}
                  renderInput={(params) => (
                    <TextField {...params} label="Stall" required fullWidth />
                  )}
                />


                {/* Vendor Autocomplete */}
                <Autocomplete
                      size="small"
                      options={vendors}
                      disabled={!!formData.stallId && !!formData.vendorId}
                      getOptionLabel={(option) =>
                        option.name ? `${option.name} (${option.email})` : ""
                      }
                      value={vendors.find((v) => v._id === formData.vendorId) || null}
                      onChange={(e, newValue) =>
                        setFormData((prev) => ({
                          ...prev,
                          vendorId: newValue ? newValue._id : "",
                        }))
                      }
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label="Vendor"
                          required
                          fullWidth
                          helperText={
                            formData.stallId
                              ? "Vendor is auto-selected from the chosen stall"
                              : ""
                          }
                        />
                      )}
                    />
                <TextField
                    select
                    size="small"
                    fullWidth
                    label="Compute Mode"
                    name="computeMode"
                    value={formData.computeMode}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        computeMode: e.target.value,
                        amount: "", // reset when switching modes
                      }))
                    }
                  >
                    <MenuItem value="AUTO_RANGE">Auto (by date range)</MenuItem>
                    <MenuItem value="CUSTOM_AMOUNT">Custom Amount (preview coverage)</MenuItem>
                  </TextField>


                {/* Amount Field */}
                <TextField
                  type="number"
                  label={formData.computeMode === "CUSTOM_AMOUNT" ? "Amount (custom)" : "Amount (auto-computed)"}
                  name="amount"
                  value={formData.amount}
                  onChange={handleInputChange}
                  fullWidth
                  size="small"
                  inputProps={{
                    min: 0,
                    step: 0.01,
                    readOnly: formData.computeMode !== "CUSTOM_AMOUNT",
                  }}
                  helperText={
                    formData.computeMode === "CUSTOM_AMOUNT"
                      ? "Enter amount to preview how far it covers (Mon–Sat only, Sunday excluded)"
                      : "System computes: daily rate × payable days (Mon–Sat only)"
                  }
                />
  {selectedStall && formData.computeMode === "AUTO_RANGE" && (
    <Paper
      variant="outlined"
      sx={{
        mt: 1.5,
        p: 1.5,
        backgroundColor:
          theme.palette.mode === "light"
            ? "rgba(76,175,80,0.03)"
            : "rgba(76,175,80,0.12)",
      }}
    >
      <Typography variant="caption" color="text.secondary">
        Computed Rent Summary
      </Typography>
      <Stack
        direction="row"
        spacing={2}
        sx={{ mt: 0.5, flexWrap: "wrap" }}
      >
        <Typography variant="body2">
          Daily rate:{" "}
          <strong>
            ₱{Number(dailyRate || 0).toLocaleString("en-PH")}
          </strong>
        </Typography>
        <Typography variant="body2">
          Payable days (Mon–Sat):{" "}
          <strong>{payableDays}</strong>
        </Typography>
        <Typography variant="body2">
          Amount:{" "}
          <strong>
            ₱{Number(computedAmount || 0).toLocaleString("en-PH")}
          </strong>
        </Typography>
      </Stack>
    </Paper>
  )}


              </Stack>


              <Divider sx={{ my: 2 }} />

              {/* Section: Period */}
              <Typography
                variant="subtitle2"
                sx={{
                  mb: 1,
                  color: "text.secondary",
                  fontWeight: 600,
                  letterSpacing: 0.3,
                }}
              >
                Payment Period
              </Typography>
              {formData.computeMode === "AUTO_RANGE" && (
                  <Stack direction={{ xs: "column", sm: "row" }} spacing={2.5} sx={{ mb: 2 }}>
                    <TextField
                      type="date"
                      label="Start"
                      name="periodStart"
                      value={formData.periodStart}
                      onChange={handleInputChange}
                      InputLabelProps={{ shrink: true }}
                      size="small"
                      fullWidth
                      required
                    />
                    <TextField
                      type="date"
                      label="End"
                      name="periodEnd"
                      value={formData.periodEnd}
                      onChange={handleInputChange}
                      InputLabelProps={{ shrink: true }}
                      size="small"
                      fullWidth
                      required
                    />
                  </Stack>
                )}

              {paymentLedgerLoading && (
                <Box sx={{ display: "flex", justifyContent: "center", py: 2 }}>
                  <CircularProgress size={22} />
                </Box>
              )}

              {!paymentLedgerLoading && paymentLedgerError && (
                <Alert severity="warning" sx={{ mb: 2 }}>
                  {paymentLedgerError}
                </Alert>
              )}
              {previewLoading && formData.computeMode === "CUSTOM_AMOUNT" && (
                <Box sx={{ display: "flex", justifyContent: "center", py: 2 }}>
                  <CircularProgress size={22} />
                </Box>
              )}

              {!!previewError && formData.computeMode === "CUSTOM_AMOUNT" && (
                <Alert severity="warning" sx={{ mb: 2 }}>
                  {previewError}
                </Alert>
              )}
             {!paymentLedgerLoading && paymentLedgerData && ["AUTO_RANGE", "CUSTOM_AMOUNT"].includes(formData.computeMode) && (
  <>
    {formData.computeMode === "AUTO_RANGE" && (
      hasPaidOverlap ? (
        <Alert severity="error" sx={{ mb: 2 }}>
          This selected range already contains paid day(s), so it cannot be saved again.
        </Alert>
      ) : (
        <Alert severity="info" sx={{ mb: 2 }}>
          Green = already paid. Red = unpaid. Blue outline = your current selection.
        </Alert>
      )
    )}

          {formData.computeMode === "CUSTOM_AMOUNT" && previewData && (
            <Alert severity="info" sx={{ mb: 2 }}>
              Preview: This amount covers from{" "}
              <strong>{previewData.startDate}</strong> to{" "}
              <strong>{previewData.endDate}</strong>
            </Alert>
          )}

          {renderCoverageCalendar({
            monthDate: paymentCalendarMonth,
            ledger: paymentLedgerData,
            selectedDates:
              formData.computeMode === "AUTO_RANGE"
                ? selectedPayableDates
                : previewData?.coveredDates || [],
            mode: "form",
            onPrev: () => setPaymentCalendarMonth((prev) => addMonths(prev, -1)),
            onNext: () => setPaymentCalendarMonth((prev) => addMonths(prev, 1)),
          })}
        </>
      )}

              <TextField
                type="date"
                label="Paid At (Optional)"
                name="paidAt"
                value={formData.paidAt}
                onChange={handleInputChange}
                InputLabelProps={{ shrink: true }}
                size="small"
                fullWidth
                sx={{ mb: 3 }}
              />

              <Divider sx={{ my: 2 }} />

              {/* Section: Status */}
              <Typography
                variant="subtitle2"
                sx={{
                  mb: 1,
                  color: "text.secondary",
                  fontWeight: 600,
                  letterSpacing: 0.3,
                }}
              >
                Status & Notes
              </Typography>
              <Stack direction={{ xs: "column", sm: "row" }} spacing={2.5} sx={{ mb: 3 }}>
                <TextField
                  select
                  label="Status"
                  name="status"
                  value={formData.status}
                  onChange={handleInputChange}
                  fullWidth
                  size="small"
                  required
                  SelectProps={{ MenuProps: { disablePortal: true } }}
                >
                  <MenuItem value="pending">Pending</MenuItem>
                  <MenuItem value="paid">Paid</MenuItem>
                  <MenuItem value="overdue">Overdue</MenuItem>
                </TextField>
              </Stack>

              <TextField
                multiline
                rows={3}
                label="Notes (Optional)"
                name="notes"
                value={formData.notes}
                onChange={handleInputChange}
                fullWidth
                size="small"
              />
            </Box>

            {/* Footer */}
            <Box
              sx={{
                p: 2.5,
                borderTop: `1px solid ${theme.palette.divider}`,
                backgroundColor: theme.palette.background.paper,
                display: "flex",
                justifyContent: "space-between",
                position: "sticky",
                bottom: 0,
                boxShadow: "0 -2px 10px rgba(0,0,0,0.15)",
              }}
            >
              <Button variant="outlined" color="inherit" onClick={handleCloseDialog}>
                Cancel
              </Button>
              <Button variant="contained" onClick={handleSubmit}>
                {editingPayment ? "Update" : "Create"}
              </Button>
            </Box>
          </Drawer>
          {/* 🧾 Ledger Drawer */}
          <Drawer
            anchor="right"
            open={ledgerOpen}
            onClose={() => setLedgerOpen(false)}
            PaperProps={{
              sx: {
                width: { xs: "100%", sm: 420 },
                display: "flex",
                flexDirection: "column",
                backgroundColor: theme.palette.background.paper,
                borderLeft: `1px solid ${theme.palette.divider}`,
              zIndex: (theme) => theme.zIndex.drawer + 3, // 👈 ensure above AppBar
              },
            }}
            ModalProps={{
              keepMounted: true, // improves open performance on mobile
              sx: {
                zIndex: (theme) => theme.zIndex.drawer + 3, // 👈 fix for overlay & backdrop
              },
            }}
          >
            {/* Header */}
            <Box
              sx={{
                p: 2.5,
                borderBottom: `1px solid ${theme.palette.divider}`,
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <Box>
                <Typography variant="h6" fontWeight={700}>
                  Stall Ledger
                </Typography>
                {ledgerPayment && (
                  <Typography variant="body2" color="text.secondary">
                    {ledgerPayment.layoutId?.name} • {ledgerPayment.stallLabel} <br />
                    Vendor: {ledgerPayment.vendorId?.name || "—"}
                  </Typography>
                )}
              </Box>
              <IconButton onClick={() => setLedgerOpen(false)}>
                <CloseRoundedIcon />
              </IconButton>
            </Box>

            {/* Body */}
            <Box sx={{ flex: 1, overflowY: "auto", p: 2.5 }}>
              {ledgerLoading && (
                <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
                  <CircularProgress size={28} />
                </Box>
              )}

              {!ledgerLoading && ledgerError && (
                <Alert severity="error">{ledgerError}</Alert>
              )}

              {!ledgerLoading && ledgerData && (
                <>
                  {/* Summary */}
                  <Stack direction="row" spacing={2} sx={{ mb: 2 }}>
                    <Paper
                      variant="outlined"
                      sx={{ flex: 1, p: 1.5, textAlign: "center" }}
                    >
                      <Typography variant="caption" color="text.secondary">
                        Total Paid Days
                      </Typography>
                      <Typography variant="h6" fontWeight={700}>
                        {ledgerData.totalPaidDays}
                      </Typography>
                    </Paper>
                    <Paper
                      variant="outlined"
                      sx={{ flex: 1, p: 1.5, textAlign: "center" }}
                    >
                      <Typography variant="caption" color="text.secondary">
                        Total Unpaid Days
                      </Typography>
                      <Typography variant="h6" fontWeight={700}>
                        {ledgerData.totalUnpaidDays}
                      </Typography>
                    </Paper>
                  </Stack>

                  <Paper
                    variant="outlined"
                    sx={{ p: 1.5, mb: 2, backgroundColor: "rgba(76,175,80,0.04)" }}
                  >
                    <Typography variant="caption" color="text.secondary">
                      Rent Covered Until
                    </Typography>
                    <Typography variant="body1" fontWeight={600}>
                      {ledgerData.coveredUntil
                        ? format(new Date(ledgerData.coveredUntil), "MMM dd, yyyy")
                        : "No coverage yet"}
                    </Typography>
                  </Paper>

                  <Divider sx={{ my: 1.5 }} />

                  {/* 🗓 Calendar View */}
      {calendarMonth && ledgerData && (() => {
        // compute calendar data here
        const year = calendarMonth.getFullYear();
        const month = calendarMonth.getMonth();
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);

        const days = [];
        for (let d = new Date(firstDay); d <= lastDay; d.setDate(d.getDate() + 1)) {
          days.push(new Date(d));
        }

        const startDow = firstDay.getDay(); // 0 = Sun
        const blankCells = Array.from({ length: startDow });

        const paidSet = new Set((ledgerData.paidDates || []).map((d) => d));
      
        const unpaidSet = new Set(ledgerData.unpaidDates || []); // This line ensures unpaid dates are set correctly.

        const isSameDayIso = (date) => date.toISOString().slice(0, 10);

        const goPrevMonth = () =>
          setCalendarMonth((prev) => addMonths(prev, -1));
        const goNextMonth = () =>
          setCalendarMonth((prev) => addMonths(prev, 1));

        return (
          <Box sx={{ mb: 2 }}>
            {/* Header with month nav */}
            <Stack
              direction="row"
              alignItems="center"
              justifyContent="space-between"
              sx={{ mb: 1 }}
            >
              <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                Calendar Coverage
              </Typography>
              <Stack direction="row" spacing={1} alignItems="center">
                <IconButton size="small" onClick={goPrevMonth}>
                  <ChevronLeftRoundedIcon fontSize="small" />
                </IconButton>
                <Typography variant="body2" sx={{ fontWeight: 600 }}>
                  {format(calendarMonth, "MMMM yyyy")}
                </Typography>
                <IconButton size="small" onClick={goNextMonth}>
                  <ChevronRightRoundedIcon fontSize="small" />
                </IconButton>
              </Stack>
            </Stack>

            {/* Weekday headers */}
            <Box
              sx={{
                display: "grid",
                gridTemplateColumns: "repeat(7, 1fr)",
                gap: 0.5,
                mb: 0.5,
              }}
            >
              {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
                <Box
                  key={d}
                  sx={{
                    textAlign: "center",
                    fontSize: 11,
                    fontWeight: 600,
                    color: "text.secondary",
                  }}
                >
                  {d}
                </Box>
              ))}
            </Box>

            {/* Days grid */}
            <Box
              sx={{
                display: "grid",
                gridTemplateColumns: "repeat(7, 1fr)",
                gap: 0.5,
              }}
            >
              {/* leading blanks */}
              {blankCells.map((_, idx) => (
                <Box key={`blank-${idx}`} />
              ))}
               {days.map((d) => {
                    // ✅ Use LOCAL date (not UTC)
                    const iso = format(d, "yyyy-MM-dd");

                    const dow = d.getDay();
                    const isSunday = dow === 0;

                    const isPaid = paidSet.has(iso);
                    const isUnpaid = unpaidSet.has(iso);

                    console.log({
                      date: iso,
                      isPaid,
                      isUnpaid,
                    });

                    let bg = "transparent";
                    let borderColor = "divider";
                    let textColor = "text.primary";

                    if (isSunday) {
                      bg = "rgba(0,0,0,0.05)";
                      textColor = "text.disabled";
                    } else if (isPaid) {
                      bg = "rgba(76,175,80,0.18)";
                      borderColor = "success.main";
                    } else {
                      // everything else unpaid
                      bg = "rgba(244,67,54,0.18)";
                      borderColor = "error.main";
                    }

                    return (
                      <Box
                        key={iso}
                        sx={{
                          borderRadius: 1,
                          minHeight: 34,
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          fontSize: 13,
                          border: `1px solid`,
                          borderColor,
                          backgroundColor: bg,
                        }}
                      >
                        <Typography
                          variant="body2"
                          sx={{
                            fontWeight: isPaid || isUnpaid ? 700 : 400,
                            color: textColor,
                          }}
                        >
                          {d.getDate()}
                        </Typography>
                      </Box>
                    );
                  })}
            </Box>

            {/* Legend */}
<Stack direction="row" spacing={2} sx={{ mt: 1 }}>
  <Stack direction="row" spacing={0.5} alignItems="center">
    <Box
      sx={{
        width: 12,
        height: 12,
        borderRadius: 0.5,
        backgroundColor: "rgba(67, 187, 71, 0.7)", // Green for paid
      }}
    />
    <Typography variant="caption" color="text.secondary">
      Paid (Mon–Sat)
    </Typography>
  </Stack>
  <Stack direction="row" spacing={0.5} alignItems="center">
    <Box
      sx={{
        width: 12,
        height: 12,
        borderRadius: 0.5,
        backgroundColor: "rgba(244,67,54,0.7)", // Red for unpaid
      }}
    />
    <Typography variant="caption" color="text.secondary">
      Unpaid (Mon–Sat)
    </Typography>
  </Stack>
  <Stack direction="row" spacing={0.5} alignItems="center">
    <Box
      sx={{
        width: 12,
        height: 12,
        borderRadius: 0.5,
        backgroundColor: "rgba(0,0,0,0.12)", // Light gray for Sunday
      }}
    />
    <Typography variant="caption" color="text.secondary">
      Sunday (excluded)
    </Typography>
  </Stack>
</Stack>
          </Box>
        );
      })()}

      <Divider sx={{ my: 1.5 }} />

                  {/* Paid ranges */}
                  <Typography
                    variant="subtitle2"
                    sx={{ mb: 0.5, fontWeight: 600 }}
                  >
                    Paid Ranges
                  </Typography>
                  {(!ledgerData.paidRanges || ledgerData.paidRanges.length === 0) && (
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                      No paid periods yet.
                    </Typography>
                  )}
                  <Stack spacing={0.5} sx={{ mb: 2 }}>
                    {ledgerData.paidRanges?.map((r, idx) => (
                      <Typography key={idx} variant="body2">
                        {format(new Date(r.start), "MMM dd, yyyy")} –{" "}
                        {format(new Date(r.end), "MMM dd, yyyy")}{" "}
                        <Typography
                          component="span"
                          variant="caption"
                          color="text.secondary"
                        >
                          ({r.days} days)
                        </Typography>
                      </Typography>
                    ))}
                  </Stack>

                  {/* Unpaid ranges */}
                  <Typography
                    variant="subtitle2"
                    sx={{ mb: 0.5, fontWeight: 600 }}
                  >
                    Unpaid Ranges
                  </Typography>
                  {(!ledgerData.unpaidRanges || ledgerData.unpaidRanges.length === 0) && (
                    <Typography variant="body2" color="text.secondary">
                      No unpaid periods in the computed range.
                    </Typography>
                  )}
                  <Stack spacing={0.5}>
                    {ledgerData.unpaidRanges?.map((r, idx) => (
                      <Typography key={idx} variant="body2">
                        {format(new Date(r.start), "MMM dd, yyyy")} –{" "}
                        {format(new Date(r.end), "MMM dd, yyyy")}{" "}
                        <Typography
                          component="span"
                          variant="caption"
                          color="text.secondary"
                        >
                          ({r.days} days)
                        </Typography>
                      </Typography>
                    ))}
                  </Stack>
                </>
              )}
            </Box>
          </Drawer>



        </Box>
      </Fade>
    );
  }
