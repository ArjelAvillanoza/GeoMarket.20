import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  TextField,
  InputAdornment,
  MenuItem,
  Button,
  Grid,
  CircularProgress,
  useTheme,
  Stack,
  useMediaQuery,
  Breadcrumbs,
  Link,
  Drawer,
  IconButton,
  Tooltip,
  Divider,
  Alert,
} from "@mui/material";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import DownloadRoundedIcon from "@mui/icons-material/DownloadRounded";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import HomeRoundedIcon from "@mui/icons-material/HomeRounded";
import ReceiptLongRoundedIcon from "@mui/icons-material/ReceiptLongRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import ChevronLeftRoundedIcon from "@mui/icons-material/ChevronLeftRounded";
import ChevronRightRoundedIcon from "@mui/icons-material/ChevronRightRounded";
import { format, addMonths } from "date-fns";
import rentalApi from "../../api/rentalApi";

export default function VendorPaymentHistoryPage () {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm")); // 👈 detect phones
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    search: "",
    status: "all",
    mode: "all",
  });

  const [ledgerOpen, setLedgerOpen] = useState(false);
  const [ledgerPayment, setLedgerPayment] = useState(null);
  const [ledgerLoading, setLedgerLoading] = useState(false);
  const [ledgerData, setLedgerData] = useState(null);
  const [ledgerError, setLedgerError] = useState("");
  const [calendarMonth, setCalendarMonth] = useState(null);


  useEffect(() => {
    fetchPayments();
  }, []);

  const fetchPayments = async () => {
    setLoading(true);
    try {
      const res = await rentalApi.getMyPayments();
      setPayments(res.data);
    } catch (err) {
      console.error("Error fetching payment history:", err);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "paid":
        return "success";
      case "pending":
        return "warning";
      case "overdue":
        return "error";
      default:
        return "default";
    }
  };

  const filteredPayments = payments.filter((p) => {
    const q = filters.search.toLowerCase();
    const matchSearch =
      (p.layoutName || "").toLowerCase().includes(q) ||
      (p.stallName || "").toLowerCase().includes(q) ||
      (p.paymentMode || "").toLowerCase().includes(q) ||
      (p.status || "").toLowerCase().includes(q);
    const matchStatus = filters.status === "all" || p.status === filters.status;
    const matchMode = filters.mode === "all" || p.paymentMode === filters.mode;
    return matchSearch && matchStatus && matchMode;
  });

  // ---------------- CSV Export (Excel-friendly) ----------------
  const handleExportCSV = () => {
    const safeCSV = (v) => {
      if (v === null || v === undefined) return "";
      let s = String(v);
      s = s.replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\n/g, " ");
      s = s.replace(/"/g, '""');
      return `"${s}"`;
    };

      const header = [
        "Date",
        "Layout",
        "Stall",
        "Amount (PHP) - Numeric",
        "Amount (Display)",
        "Days Paid",
        "Period",
        "Status",
        "Paid At",
        "Notes",
      ];


    const rows = (filteredPayments.length ? filteredPayments : payments).map((p) => {
      const date = format(new Date(p.createdAt), "MMM dd, yyyy");
      const period = `${format(new Date(p.periodStart), "MMM dd")} - ${format(
        new Date(p.periodEnd),
        "MMM dd, yyyy"
      )}`;
      const paidAt = p.paidAt ? format(new Date(p.paidAt), "MMM dd, yyyy") : "";
      const amountNumeric = Number(p.amount ?? 0);
      const amountDisplay = `₱${Number(p.amount ?? 0).toLocaleString("en-PH")}`;

      return [
        safeCSV(date),
        safeCSV(p.layoutName),
        safeCSV(p.stallName + (p.stallLabel ? ` (${p.stallLabel})` : "")),
        String(amountNumeric),
        safeCSV(amountDisplay),
        String(p.daysPaid ?? ""),
        safeCSV(period),
        safeCSV((p.status || "").toUpperCase()),
        safeCSV(paidAt),
        safeCSV(p.notes || ""),
      ].join(",");

    });

    const bom = "\uFEFF";
    const csv = [header.join(","), ...rows].join("\n");
    const blob = new Blob([bom + csv], { type: "text/csv;charset=utf-8;" });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "vendor_payment_history.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleViewLedger = async (payment) => {
  try {
    setLedgerPayment(payment);
    setLedgerOpen(true);
    setLedgerLoading(true);
    setLedgerError("");
    setLedgerData(null);
    setCalendarMonth(null);

    // 🔐 vendor-specific endpoint – hindi na kelangan vendorId param
    const res = await rentalApi.getMyStallLedger(payment.stallId);
    const data = res.data;

    setLedgerData(data);

    const baseStr =
      data.coveredUntil ||
      (data.paidDates && data.paidDates[0]) ||
      (data.unpaidDates && data.unpaidDates[0]);

    setCalendarMonth(baseStr ? new Date(baseStr) : new Date());
  } catch (err) {
    console.error("Vendor ledger load error:", err);
    setLedgerError(err?.response?.data?.message || "Failed to load ledger");
  } finally {
    setLedgerLoading(false);
  }
};

  // -------------------------------------------------------------

  if (loading) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "60vh",
        }}
      >
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ xs: 1.5, sm: 3, md: 4, p: 5 }}>
      {/* Breadcrumbs */}
      {/* Header (responsive) */}
      <Stack
        direction={{ xs: "column", sm: "row" }}
        justifyContent="space-between"
        alignItems={{ xs: "stretch", sm: "center" }}
        sx={{ mb: 3, gap: 1.5, mt: 3 }}
      >
        <Typography variant={isMobile ? "h6" : "h5"} fontWeight={700}>
          Payment History
        </Typography>

        <Box sx={{ alignSelf: { xs: "flex-end", sm: "auto" } }}>
          <Button
            variant="contained"
            startIcon={<DownloadRoundedIcon />}
            onClick={handleExportCSV}
            sx={{ borderRadius: 2, textTransform: "none", px: 2.5 }}
            size={isMobile ? "small" : "medium"}
          >
            Export CSV
          </Button>
        </Box>
      </Stack>

      {/* Filters */}
      {/* Filters */}
      <Paper
        variant="outlined"
        sx={{
          p: { xs: 1.5, sm: 2.5 },
          borderRadius: 1,
          mb: 3,
          backgroundColor:
            theme.palette.mode === "dark"
              ? "rgba(255,255,255,0.04)"
              : theme.palette.background.paper,
        }}
      >
        {/* Row 1: Search (full width, all breakpoints) */}
        <Box sx={{ mb: 1.5 }}>
          <TextField
            placeholder="Search layout, stall, mode or status..."
            size="small"
            fullWidth
            value={filters.search}
            onChange={(e) => setFilters({ ...filters, search: e.target.value })}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchRoundedIcon fontSize="small" />
                </InputAdornment>
              ),
            }}
            sx={{
              "& .MuiOutlinedInput-root": {
                borderRadius: 999, // pill look (optional)
              },
            }}
          />
        </Box>

        {/* Row 2: Two dropdowns (split 50/50 on all sizes; stack nicely on very small screens) */}
        <Grid container spacing={1.5}>
          <Grid item xs={12} sm={6}>
            <TextField
              select
              label="Status"
              size="small"
              fullWidth
              value={filters.status}
              onChange={(e) => setFilters({ ...filters, status: e.target.value })}
              sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
            >
              <MenuItem value="all">All</MenuItem>
              <MenuItem value="paid">Paid</MenuItem>
              <MenuItem value="pending">Pending</MenuItem>
              <MenuItem value="overdue">Overdue</MenuItem>
            </TextField>
          </Grid>
        </Grid>
      </Paper>


      {/* DATA VIEW */}
      {isMobile ? (
        // ---------- MOBILE: CARD LIST ----------
        <Stack spacing={1.5}>
          {filteredPayments.length === 0 ? (
            <Paper variant="outlined" sx={{ p: 2, textAlign: "center" }}>
              No payment records found
            </Paper>
          ) : (
            filteredPayments.map((p) => (
              <Paper
                key={p._id}
                variant="outlined"
                sx={{
                  p: 1.5,
                  borderRadius: 1,
                  display: "grid",
                  gridTemplateColumns: "1fr auto",
                  gap: 1,
                }}
              >
                {/* Left column */}
                <Box>
                  <Typography variant="subtitle2" color="text.secondary">
                    {format(new Date(p.createdAt), "MMM dd, yyyy")}
                  </Typography>

                  <Typography fontWeight={700} sx={{ mt: 0.5 }}>
                    {p.layoutName} • {p.stallName}
                  </Typography>
                  {p.stallLabel && (
                    <Typography variant="caption" color="text.secondary">
                      {p.stallLabel}
                    </Typography>
                  )}

                  <Typography variant="body2" sx={{ mt: 0.5 }}>
                    {format(new Date(p.periodStart), "MMM dd")} –{" "}
                    {format(new Date(p.periodEnd), "MMM dd, yyyy")}
                  </Typography>

                  <Typography variant="caption" color="text.secondary">
                    Days paid: <strong>{p.daysPaid ?? "—"}</strong>
                  </Typography>

                  {p.paidAt && (
                    <Typography variant="caption" color="text.secondary">
                      Paid at: {format(new Date(p.paidAt), "MMM dd, yyyy")}
                    </Typography>
                  )}

                  <Typography
                    variant="body2"
                    color="text.secondary"
                    sx={{
                      mt: 0.5,
                      maxWidth: 260,
                      overflow: "hidden",
                      whiteSpace: "nowrap",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {p.notes || "—"}
                  </Typography>
                </Box>

                {/* Right column */}
                <Stack alignItems="flex-end" spacing={1}>
                  <Typography fontWeight={800}>
                    ₱{Number(p.amount ?? 0).toLocaleString("en-PH")}
                  </Typography>
                  <Chip
                    label={(p.status || "").toUpperCase()}
                    size="small"
                    color={getStatusColor(p.status)}
                    sx={{ fontWeight: 600 }}
                  />
                  <Tooltip title="View Stall Ledger">
                    <IconButton
                      size="small"
                      onClick={() => handleViewLedger(p)}
                    >
                      <ReceiptLongRoundedIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </Stack>

              </Paper>
            ))
          )}
        </Stack>
      ) : (
        // ---------- DESKTOP/TABLET: TABLE ----------
        <TableContainer
          component={Paper}
          sx={{
            borderRadius: 2,
            boxShadow:
              theme.palette.mode === "dark"
                ? "0 3px 15px rgba(0,0,0,0.5)"
                : "0 3px 12px rgba(0,0,0,0.08)",
            overflow: "hidden",
          }}
        >
          <Table size="small" stickyHeader>
            <TableHead>
              <TableRow
                sx={{
                  backgroundColor:
                    theme.palette.mode === "dark"
                      ? "rgba(255,255,255,0.05)"
                      : "rgba(0,0,0,0.04)",
                }}
              >
                <TableCell sx={{ fontWeight: 700, textTransform: "uppercase" }}>
                  Date
                </TableCell>
                <TableCell sx={{ fontWeight: 700, textTransform: "uppercase" }}>
                  Layout
                </TableCell>
                <TableCell sx={{ fontWeight: 700, textTransform: "uppercase" }}>
                  Stall
                </TableCell>
                <TableCell sx={{ fontWeight: 700, textTransform: "uppercase" }}>
                  Amount
                </TableCell>
                <TableCell sx={{ fontWeight: 700, textTransform: "uppercase" }}>
                  Days
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: 700,
                    textTransform: "uppercase",
                    display: { xs: "none", md: "table-cell" },
                  }}
                >
                  Period
                </TableCell>
                <TableCell sx={{ fontWeight: 700, textTransform: "uppercase" }}>
                  Status
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: 700,
                    textTransform: "uppercase",
                    display: { xs: "none", lg: "table-cell" },
                  }}
                >
                  Paid At
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: 700,
                    textTransform: "uppercase",
                    display: { xs: "none", lg: "table-cell" },
                  }}
                >
                  Notes
                  </TableCell>
                <TableCell
                  sx={{
                    fontWeight: 700,
                    textTransform: "uppercase",
                    display: { xs: "none", lg: "table-cell" },
                  }}
                >
                  Ledger
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredPayments.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} align="center" sx={{ py: 4 }}>
                    No payment records found
                  </TableCell>
                </TableRow>
              ) : (
                filteredPayments.map((p) => (
                  <TableRow key={p._id} hover>
                    <TableCell>
                      {format(new Date(p.createdAt), "MMM dd, yyyy")}
                    </TableCell>
                    <TableCell>{p.layoutName}</TableCell>
                    <TableCell>
                      <Typography fontWeight={600}>{p.stallName}</Typography>
                      {p.stallLabel && (
                        <Typography
                          variant="caption"
                          color="text.secondary"
                          display="block"
                        >
                          {p.stallLabel}
                        </Typography>
                      )}
                    </TableCell>
                    <TableCell>
                      <Typography fontWeight={700}>
                        ₱{Number(p.amount ?? 0).toLocaleString("en-PH")}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      {p.daysPaid ?? "—"}
                    </TableCell>
                    <TableCell sx={{ display: { xs: "none", md: "table-cell" } }}>
                      {format(new Date(p.periodStart), "MMM dd")} –{" "}
                      {format(new Date(p.periodEnd), "MMM dd, yyyy")}
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={(p.status || "").toUpperCase()}
                        size="small"
                        color={getStatusColor(p.status)}
                        sx={{ fontWeight: 600 }}
                      />
                    </TableCell>
                    <TableCell sx={{ display: { xs: "none", lg: "table-cell" } }}>
                      {p.paidAt ? format(new Date(p.paidAt), "MMM dd, yyyy") : "—"}
                    </TableCell>
                    <TableCell
                      sx={{ display: { xs: "none", lg: "table-cell" }, maxWidth: 220 }}
                    >
                      <Typography variant="body2" color="text.secondary" noWrap>
                        {p.notes || "—"}
                      </Typography>
                    </TableCell>
                    <TableCell align="center">
                      <Tooltip title="View Stall Ledger">
                        <IconButton size="small" onClick={() => handleViewLedger(p)}>
                          <ReceiptLongRoundedIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>

                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* 🧾 Vendor Stall Ledger Drawer */}
      <Drawer
        anchor="right"
        open={ledgerOpen}
        onClose={() => setLedgerOpen(false)}
        PaperProps={{
          sx: {
            width: { xs: "100%", sm: 420 },
            display: "flex",
            flexDirection: "column",
            backgroundColor: theme.palette.background.paper,
            borderLeft: `1px solid ${theme.palette.divider}`,
            zIndex: (theme) => theme.zIndex.drawer + 3,
          },
        }}
        ModalProps={{
          keepMounted: true,
          sx: {
            zIndex: (theme) => theme.zIndex.drawer + 3,
          },
        }}
      >
        {/* Header */}
        <Box
          sx={{
            p: 2.5,
            borderBottom: `1px solid ${theme.palette.divider}`,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Box>
            <Typography variant="h6" fontWeight={700}>
              Stall Ledger
            </Typography>
            {ledgerPayment && (
              <Typography variant="body2" color="text.secondary">
                {ledgerPayment.layoutName} • {ledgerPayment.stallName}
                {ledgerPayment.stallLabel ? ` (${ledgerPayment.stallLabel})` : ""}
              </Typography>
            )}
          </Box>
          <IconButton onClick={() => setLedgerOpen(false)}>
            <CloseRoundedIcon />
          </IconButton>
        </Box>

        {/* Body */}
        <Box sx={{ flex: 1, overflowY: "auto", p: 2.5 }}>
          {ledgerLoading && (
            <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
              <CircularProgress size={28} />
            </Box>
          )}

          {!ledgerLoading && ledgerError && (
            <Alert severity="error">{ledgerError}</Alert>
          )}

          {!ledgerLoading && ledgerData && (
            <>
              {/* Summary */}
              <Stack direction="row" spacing={2} sx={{ mb: 2 }}>
                <Paper variant="outlined" sx={{ flex: 1, p: 1.5, textAlign: "center" }}>
                  <Typography variant="caption" color="text.secondary">
                    Total Paid Days
                  </Typography>
                  <Typography variant="h6" fontWeight={700}>
                    {ledgerData.totalPaidDays}
                  </Typography>
                </Paper>
                <Paper variant="outlined" sx={{ flex: 1, p: 1.5, textAlign: "center" }}>
                  <Typography variant="caption" color="text.secondary">
                    Total Unpaid Days
                  </Typography>
                  <Typography variant="h6" fontWeight={700}>
                    {ledgerData.totalUnpaidDays}
                  </Typography>
                </Paper>
              </Stack>

              <Paper
                variant="outlined"
                sx={{ p: 1.5, mb: 2, backgroundColor: "rgba(76,175,80,0.04)" }}
              >
                <Typography variant="caption" color="text.secondary">
                  Rent Covered Until
                </Typography>
                <Typography variant="body1" fontWeight={600}>
                  {ledgerData.coveredUntil
                    ? format(new Date(ledgerData.coveredUntil), "MMM dd, yyyy")
                    : "No coverage yet"}
                </Typography>
              </Paper>

              <Divider sx={{ my: 1.5 }} />

              {/* Calendar View */}
              {calendarMonth && (() => {
                const year = calendarMonth.getFullYear();
                const month = calendarMonth.getMonth();
                const firstDay = new Date(year, month, 1);
                const lastDay = new Date(year, month + 1, 0);

                const days = [];
                for (let d = new Date(firstDay); d <= lastDay; d.setDate(d.getDate() + 1)) {
                  days.push(new Date(d));
                }

                const startDow = firstDay.getDay();
                const blankCells = Array.from({ length: startDow });

                const paidSet = new Set((ledgerData.paidDates || []).map((d) => d));
                const unpaidSet = new Set((ledgerData.unpaidDates || []).map((d) => d));

                const isSameDayIso = (date) => date.toISOString().slice(0, 10);

                const goPrevMonth = () =>
                  setCalendarMonth((prev) => addMonths(prev, -1));
                const goNextMonth = () =>
                  setCalendarMonth((prev) => addMonths(prev, 1));

                return (
                  <Box sx={{ mb: 2 }}>
                    <Stack
                      direction="row"
                      alignItems="center"
                      justifyContent="space-between"
                      sx={{ mb: 1 }}
                    >
                      <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                        Calendar Coverage
                      </Typography>
                      <Stack direction="row" spacing={1} alignItems="center">
                        <IconButton size="small" onClick={goPrevMonth}>
                          <ChevronLeftRoundedIcon fontSize="small" />
                        </IconButton>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {format(calendarMonth, "MMMM yyyy")}
                        </Typography>
                        <IconButton size="small" onClick={goNextMonth}>
                          <ChevronRightRoundedIcon fontSize="small" />
                        </IconButton>
                      </Stack>
                    </Stack>

                    {/* Weekday header */}
                    <Box
                      sx={{
                        display: "grid",
                        gridTemplateColumns: "repeat(7, 1fr)",
                        gap: 0.5,
                        mb: 0.5,
                      }}
                    >
                      {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
                        <Box
                          key={d}
                          sx={{
                            textAlign: "center",
                            fontSize: 11,
                            fontWeight: 600,
                            color: "text.secondary",
                          }}
                        >
                          {d}
                        </Box>
                      ))}
                    </Box>

                    {/* Days */}
                    <Box
                      sx={{
                        display: "grid",
                        gridTemplateColumns: "repeat(7, 1fr)",
                        gap: 0.5,
                      }}
                    >
                      {blankCells.map((_, idx) => (
                        <Box key={`blank-${idx}`} />
                      ))}

                      {days.map((d) => {
                        const iso = isSameDayIso(d);
                        const dow = d.getDay();
                        const isSunday = dow === 0;
                        const isPaid = paidSet.has(iso);
                        const isUnpaid = unpaidSet.has(iso);

                        let bg = "transparent";
                        let borderColor = "divider";
                        let textColor = "text.primary";

                        if (isSunday) {
                          bg = "rgba(0,0,0,0.05)";
                          textColor = "text.disabled";
                        } else if (isPaid) {
                          bg = "rgba(76,175,80,0.18)";
                          borderColor = "success.main";
                        } else if (isUnpaid) {
                          bg = "rgba(244,67,54,0.18)";
                          borderColor = "error.main";
                        }

                        return (
                          <Box
                            key={iso}
                            sx={{
                              borderRadius: 1,
                              minHeight: 34,
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              fontSize: 13,
                              border: `1px solid`,
                              borderColor,
                            }}
                            style={{ backgroundColor: bg }}
                          >
                            <Typography
                              variant="body2"
                              sx={{
                                fontWeight: isPaid || isUnpaid ? 700 : 400,
                                color: textColor,
                              }}
                            >
                              {d.getDate()}
                            </Typography>
                          </Box>
                        );
                      })}
                    </Box>

                    {/* Legend */}
                    <Stack direction="row" spacing={2} sx={{ mt: 1 }}>
                      <Stack direction="row" spacing={0.5} alignItems="center">
                        <Box
                          sx={{
                            width: 12,
                            height: 12,
                            borderRadius: 0.5,
                            backgroundColor: "rgba(76,175,80,0.7)",
                          }}
                        />
                        <Typography variant="caption" color="text.secondary">
                          Paid (Mon–Sat)
                        </Typography>
                      </Stack>
                      <Stack direction="row" spacing={0.5} alignItems="center">
                        <Box
                          sx={{
                            width: 12,
                            height: 12,
                            borderRadius: 0.5,
                            backgroundColor: "rgba(244,67,54,0.7)",
                          }}
                        />
                        <Typography variant="caption" color="text.secondary">
                          Unpaid (Mon–Sat)
                        </Typography>
                      </Stack>
                      <Stack direction="row" spacing={0.5} alignItems="center">
                        <Box
                          sx={{
                            width: 12,
                            height: 12,
                            borderRadius: 0.5,
                            backgroundColor: "rgba(0,0,0,0.12)",
                          }}
                        />
                        <Typography variant="caption" color="text.secondary">
                          Sunday (excluded)
                        </Typography>
                      </Stack>
                    </Stack>
                  </Box>
                );
              })()}

              <Divider sx={{ my: 1.5 }} />

              {/* Paid ranges */}
              <Typography
                variant="subtitle2"
                sx={{ mb: 0.5, fontWeight: 600 }}
              >
                Paid Ranges
              </Typography>
              {(!ledgerData.paidRanges || ledgerData.paidRanges.length === 0) && (
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  No paid periods yet.
                </Typography>
              )}
              <Stack spacing={0.5} sx={{ mb: 2 }}>
                {ledgerData.paidRanges?.map((r, idx) => (
                  <Typography key={idx} variant="body2">
                    {format(new Date(r.start), "MMM dd, yyyy")} –{" "}
                    {format(new Date(r.end), "MMM dd, yyyy")}{" "}
                    <Typography
                      component="span"
                      variant="caption"
                      color="text.secondary"
                    >
                      ({r.days} days)
                    </Typography>
                  </Typography>
                ))}
              </Stack>

              {/* Unpaid ranges */}
              <Typography
                variant="subtitle2"
                sx={{ mb: 0.5, fontWeight: 600 }}
              >
                Unpaid Ranges
              </Typography>
              {(!ledgerData.unpaidRanges || ledgerData.unpaidRanges.length === 0) && (
                <Typography variant="body2" color="text.secondary">
                  No unpaid periods in the computed range.
                </Typography>
              )}
              <Stack spacing={0.5}>
                {ledgerData.unpaidRanges?.map((r, idx) => (
                  <Typography key={idx} variant="body2">
                    {format(new Date(r.start), "MMM dd, yyyy")} –{" "}
                    {format(new Date(r.end), "MMM dd, yyyy")}{" "}
                    <Typography
                      component="span"
                      variant="caption"
                      color="text.secondary"
                    >
                      ({r.days} days)
                    </Typography>
                  </Typography>
                ))}
              </Stack>
            </>
          )}
        </Box>
      </Drawer>

    </Box>
  );
}
