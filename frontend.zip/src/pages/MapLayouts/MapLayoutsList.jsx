// src/pages/MapLayoutsList.jsx
import React, { useEffect, useState, useMemo } from "react";
import {
  Container,
  Typography,
  Box,
  Button,
  Table,
  TableHead,
  TableBody,
  TableCell,
  TableRow,
  TablePagination,
  Paper,
  IconButton,
  Tooltip,
  Breadcrumbs,
  Link,
  InputAdornment,
  TextField,
  alpha,
  useTheme,
} from "@mui/material";
import AddLocationAltRoundedIcon from "@mui/icons-material/AddLocationAltRounded";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import EditIcon from "@mui/icons-material/Edit";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import mapLayoutApi from "../../api/mapLayoutApi";
import { useNavigate } from "react-router-dom";

export default function MapLayoutsList () {
  const theme = useTheme();
  const nav = useNavigate();
  const [rows, setRows] = useState([]);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  // Load layouts
  const load = async () => {
    const res = await mapLayoutApi.list();
    setRows(res.data);
  };
  useEffect(() => {
    load();
  }, []);

  const handleCreate = async () => {
    const res = await mapLayoutApi.create({ name: "New Layout" });
    nav(`/dashboard/ceemo/map-layouts/${res.data._id}`);
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this layout?")) return;
    await mapLayoutApi.remove(id);
    load();
  };

  const filteredRows = useMemo(() => {
    const q = search.toLowerCase();
    return rows.filter((r) => r.name.toLowerCase().includes(q));
  }, [rows, search]);

  const paginated = useMemo(() => {
    const start = page * rowsPerPage;
    return filteredRows.slice(start, start + rowsPerPage);
  }, [filteredRows, page, rowsPerPage]);

  return (
    <Box
      sx={{
        minHeight: "100vh",
        bgcolor: "background.default",
        pt: { xs: 5, md: 5 },
        p: 6,
      }}
    >


        {/* Header Section */}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            flexWrap: "wrap",
            gap: 3,
            mb: 4,
          }}
        >
          <Box>
            <Typography
              variant="h4"
              sx={{
                fontWeight: 700,
                background:
                  theme.palette.mode === "light"
                    ? "#000000"
                    : "#ffff",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              Map Layouts
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Manage and organize your market layout maps
            </Typography>
          </Box>

          <Button
            variant="contained"
            size="large"
            startIcon={<AddLocationAltRoundedIcon />}
            onClick={handleCreate}
            sx={{
              px: 3,
              py: 1.4,
              textTransform: "none",
              fontWeight: 600,
              boxShadow:
                theme.palette.mode === "light"
                  ? "0 4px 14px rgba(75, 86, 210, 0.25)"
                  : "0 4px 20px rgba(75, 86, 210, 0.4)",
              "&:hover": {
                transform: "translateY(-2px)",
                boxShadow:
                  theme.palette.mode === "light"
                    ? "0 6px 20px rgba(75, 86, 210, 0.35)"
                    : "0 6px 24px rgba(75, 86, 210, 0.5)",
              },
              transition: "all 0.3s ease",
            }}
          >
            Create Layout
          </Button>
        </Box>

        {/* Search Bar */}
        <TextField
          placeholder="Search by layout name..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchRoundedIcon sx={{ color: "text.secondary" }} />
              </InputAdornment>
            ),
          }}
          sx={{
            width: "100%",
            mb: 3,
            "& .MuiOutlinedInput-root": {
              bgcolor:
                theme.palette.mode === "light"
                  ? "#fff"
                  : alpha(theme.palette.background.paper, 0.6),
              transition: "all 0.3s ease",
              "&:hover": {
                bgcolor:
                  theme.palette.mode === "light"
                    ? "#fff"
                    : alpha(theme.palette.background.paper, 0.8),
              },
              "&.Mui-focused": {
                bgcolor:
                  theme.palette.mode === "light"
                    ? "#fff"
                    : theme.palette.background.paper,
                boxShadow: `0 0 0 2px ${alpha(
                  theme.palette.primary.main,
                  0.2
                )}`,
              },
            },
          }}
        />

        {/* Table Section */}
        <Paper
          elevation={0}
          sx={{
            overflow: "hidden",
            border: `1px solid ${theme.palette.divider}`,
            boxShadow:
              theme.palette.mode === "light"
                ? "0 4px 20px rgba(0,0,0,0.06)"
                : "0 4px 20px rgba(0,0,0,0.4)",
          }}
        >
          <Table>
            <TableHead>
              <TableRow
                sx={{
                  bgcolor:
                    theme.palette.mode === "light"
                      ? alpha(theme.palette.primary.main, 0.05)
                      : alpha(theme.palette.primary.main, 0.15),
                }}
              >
                <TableCell sx={{ fontWeight: 700, fontSize: "0.875rem" }}>
                  Name
                </TableCell>
                <TableCell sx={{ fontWeight: 700, fontSize: "0.875rem" }}>
                  Last Updated
                </TableCell>
                <TableCell
                  align="right"
                  sx={{ fontWeight: 700, fontSize: "0.875rem" }}
                >
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {paginated.map((r) => (
                <TableRow
                  key={r._id}
                  hover
                  sx={{
                    "&:hover": {
                      bgcolor:
                        theme.palette.mode === "light"
                          ? alpha(theme.palette.primary.main, 0.02)
                          : alpha(theme.palette.primary.main, 0.05),
                    },
                    transition: "background-color 0.2s ease",
                  }}
                >
                  <TableCell>{r.name}</TableCell>
                  <TableCell>
                    {new Date(r.updatedAt).toLocaleString()}
                  </TableCell>
                  <TableCell align="right">
                    <Tooltip title="Edit layout">
                      <IconButton
                        color="primary"
                        onClick={() =>
                          nav(`/dashboard/ceemo/map-layouts/${r._id}`)
                        }
                        sx={{
                          "&:hover": {
                            bgcolor: alpha(theme.palette.primary.main, 0.1),
                          },
                        }}
                      >
                        <EditIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Delete layout">
                      <IconButton
                        color="error"
                        onClick={() => handleDelete(r._id)}
                        sx={{
                          "&:hover": {
                            bgcolor: alpha(theme.palette.error.main, 0.1),
                          },
                        }}
                      >
                        <DeleteOutlineIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}

              {paginated.length === 0 && (
                <TableRow>
                  <TableCell colSpan={3} align="center" sx={{ py: 8 }}>
                    <Typography
                      variant="body1"
                      color="text.secondary"
                      sx={{ mb: 1 }}
                    >
                      No map layouts found
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {search
                        ? "Try adjusting your search query"
                        : "Start by creating a new layout"}
                    </Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>

          <TablePagination
            component="div"
            count={filteredRows.length}
            page={page}
            onPageChange={(e, newPage) => setPage(newPage)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={(e) => {
              setRowsPerPage(parseInt(e.target.value, 10));
              setPage(0);
            }}
            rowsPerPageOptions={[5, 10, 25, 50]}
            sx={{
              borderTop: `1px solid ${theme.palette.divider}`,
              bgcolor:
                theme.palette.mode === "light"
                  ? alpha(theme.palette.primary.main, 0.02)
                  : alpha(theme.palette.primary.main, 0.05),
            }}
          />
        </Paper>
    </Box>
  );
}
