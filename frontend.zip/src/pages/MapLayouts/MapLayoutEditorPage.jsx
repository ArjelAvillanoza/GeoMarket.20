import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import {
  Box,
  Button,
  Container,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import mapLayoutApi from "../../api/mapLayoutApi";
import MapEditor from "../../components/map/MapEditor";

export default function MapLayoutEditorPage () {
  const { id } = useParams();
  const [layout, setLayout] = useState(null);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    const res = await mapLayoutApi.get(id);
    setLayout(res.data);
  };

  const save = async (next) => {
    setSaving(true);
    try {
      const res = await mapLayoutApi.update(id, next);
      setLayout(res.data);
    } finally {
      setSaving(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!layout) return null;

  return (
    <Container sx={{ mt: 2 }}>
      <Stack direction="row" spacing={2} alignItems="center" sx={{ mb: 2 }}>
        <TextField
          size="small"
          label="Layout Name"
          value={layout.name}
          onChange={(e) => setLayout({ ...layout, name: e.target.value })}
        />

        <Button variant="outlined" component="label">
          Upload Background
          <input
            type="file"
            hidden
            accept="image/*"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              const res = await mapLayoutApi.uploadBackground(id, f);
              setLayout(res.data);
            }}
          />
        </Button>

        <Box sx={{ flexGrow: 1 }} />

        <Typography variant="caption">
          Last updated: {new Date(layout.updatedAt).toLocaleString()}
        </Typography>
      </Stack>

      <MapEditor
        layout={layout}
        onChange={setLayout}
        onSave={() => save(layout)}
      />
    </Container>
  );
}
