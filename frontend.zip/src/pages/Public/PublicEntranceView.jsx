import { useEffect, useState, useRef } from "react";
import { useParams } from "react-router-dom";
import {
  Box,
  Typography,
  TextField,
  Button,
  Stack,
  Paper,
  CircularProgress,
  InputAdornment,
  IconButton,
  Drawer,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  Fab,
  Chip,
  alpha,
  useTheme,
  Slide,
  SwipeableDrawer,
  Divider,
} from "@mui/material";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import DirectionsRoundedIcon from "@mui/icons-material/DirectionsRounded";
import MyLocationRoundedIcon from "@mui/icons-material/MyLocationRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import NavigationRoundedIcon from "@mui/icons-material/NavigationRounded";
import StoreRoundedIcon from "@mui/icons-material/StoreRounded";
import ThreeSixtyRoundedIcon from "@mui/icons-material/ThreeSixtyRounded";
import MenuRoundedIcon from "@mui/icons-material/MenuRounded";
import Brightness4 from "@mui/icons-material/Brightness4";     // 🌗 ADD THIS
import Brightness7 from "@mui/icons-material/Brightness7";
import publicApi from "../../api/publicApi";
import MapViewer from "../../components/map/MapViewer";
import Street360Viewer from "../../components/map/Street360Viewer";
import { resolveImageUrl } from "../../utils/url";
import Konva from "konva";

export default function PublicEntranceView ({ toggleMode }) {
  const theme = useTheme();
  const { entranceId } = useParams();
  const [loading, setLoading] = useState(true);
  const [layout, setLayout] = useState(null);
  const [entrance, setEntrance] = useState(null);
  const [stalls, setStalls] = useState([]);
  const [results, setResults] = useState([]);
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(null);
  const [route, setRoute] = useState(null);
  const [trackingEnabled, setTrackingEnabled] = useState(false);
  const [activeStreetView, setActiveStreetView] = useState(null);

  // UI States
  const [searchOpen, setSearchOpen] = useState(false);
  const [resultsOpen, setResultsOpen] = useState(false);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [streetViewOpen, setStreetViewOpen] = useState(false);
  const [infoOpen, setInfoOpen] = useState(false);

  const stageRef = useRef(null);

  // Load entrance/layout
  useEffect(() => {
    const load = async () => {
      try {
        const res = await publicApi.getEntrance(entranceId);
        const data = res.data;
        const newLayout = {
          _id: data.layoutId,
          name: data.layoutName,
          entrances: data.entrances || [],
          streetViews: data.streetViews || [],
          size: { width: 1200, height: 800, grid: 10 },
          backgroundImage: "",
          gpsBounds: data.gpsBounds,
        };
        setLayout(newLayout);
        setEntrance(data.entrance);
        setStalls(data.stalls);
      } catch (err) {
        console.error("Failed to load entrance:", err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [entranceId]);
 
useEffect(() => {
  console.log("Active Street View changed:");
  console.log(activeStreetView);
}, [activeStreetView]);

  // Search
  const handleSearch = () => {
    const q = query.trim().toLowerCase();
    if (!q) {
      setResults([]);
      setResultsOpen(false);
      return;
    }
    const matches = stalls.filter((s) => {
      const biz = s.meta?.business;
      return (
        s.name?.toLowerCase().includes(q) ||
        biz?.description?.toLowerCase().includes(q) ||
        (biz?.services || []).some((svc) => svc.toLowerCase().includes(q))
      );
    });
    setResults(matches);
    setResultsOpen(true);
    setSearchOpen(false);
  };

  // Directions
  // Directions
  const handleGetDirections = async (stall) => {
    try {
      setRoute(null);
      setSelected(null);
      setResultsOpen(false);
      setDetailsOpen(false);

      await new Promise((r) => setTimeout(r, 40));

      const res = await publicApi.getDirections(layout._id, entrance.id, stall.id);
      const data = res.data;

      if (!data?.points?.length) return;

      // Flatten points into [x1, y1, x2, y2, ...]
      const flatPoints = data.points.flatMap((p) => [p.x, p.y]);

      // Add exact destination center (for smoother visual)
      const destX = stall.x + stall.width / 2;
      const destY = stall.y + stall.height / 2;
      flatPoints.push(destX, destY);

      setRoute({ points: flatPoints });
      setSelected(stall);
      setTrackingEnabled(false);
      
        // ✅ START POSITION (CRITICAL FIX)
        setActiveStreetView({
          x: flatPoints[0],
          y: flatPoints[1],
        });
      // ✅ Immediately zoom to fit entire route
      if (stageRef.current) {
        const stage = stageRef.current.getStage();


        // Compute route bounds
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        for (let i = 0; i < flatPoints.length; i += 2) {
          const x = flatPoints[i];
          const y = flatPoints[i + 1];
          minX = Math.min(minX, x);
          minY = Math.min(minY, y);
          maxX = Math.max(maxX, x);
          maxY = Math.max(maxY, y);
        }

        // Dynamic margin based on route size (so both entrance + stall are visible)
        const routeW = maxX - minX;
        const routeH = maxY - minY;
        const margin = Math.max(routeW, routeH) * 0.20; // 20% padding

        // Compute adaptive scale
        const targetScale = Math.min(
          stage.width() / (routeW + margin * 2),
          stage.height() / (routeH + margin * 2)
        );
        const currentScale = stage.scaleX();
        const scale = Math.min(Math.max(targetScale, currentScale * 0.8), 2.8);


        // Center route
        const cx = (minX + maxX) / 2;
        const cy = (minY + maxY) / 2;

        // Animate zoom and center
        stage.to({
          scaleX: scale,
          scaleY: scale,
          x: stage.width() / 2 - cx * scale,
          y: stage.height() / 2 - cy * scale,
          duration: 0.8,
          easing: Konva.Easings.EaseInOut,
        });
      }
    } catch (err) {
      console.error("Direction error:", err);
    }
  };


  // Determine which side the entrance is on (left, right, top, bottom)
  const entranceSide = (() => {
    if (!layout || !entrance) return "center";

    const { x, y } = entrance;
    const { width, height } = layout.size;
    const margin = 80; // tolerance to detect near edges

    if (x < margin) return "left";
    if (x > width - margin) return "right";
    if (y < margin) return "top";
    if (y > height - margin) return "bottom";
    return "center";
  })();

  console.log("Entrance side:", entranceSide);

  // Select stall
  const handleSelectStall = (stall) => {
    setSelected(stall);
    setDetailsOpen(true);
    setResultsOpen(false);
  };

  const centerToGps = (lat, lng) => {
    if (!layout?.gpsBounds || !stageRef.current) return;
    const { minLat, maxLat, minLng, maxLng } = layout.gpsBounds;
    const { width, height } = layout.size;
    const x = ((lng - minLng) / (maxLng - minLng)) * width;
    const y = ((maxLat - lat) / (maxLat - minLat)) * height;

    const stage = stageRef.current.getStage();
    const s = stage.scaleX();
    stage.to({
      x: stage.width() / 2 - x * s,
      y: stage.height() / 2 - y * s,
      duration: 0.45,
      easing: Konva.Easings.EaseInOut,
    });
  };

  // START press → enable tracking + snap to current position
  const handleStart = () => {
    setTrackingEnabled(true);
    if (!("geolocation" in navigator)) return;
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => centerToGps(coords.latitude, coords.longitude),
      () => { }, // ignore; watchPosition in MapViewer will still kick in
      { enableHighAccuracy: true, timeout: 8000, maximumAge: 2000 }
    );
  };

  // Smooth zoom to 360 point then open viewer
  const handleStreetViewClick = (sv) => {
    if (!sv?.imagePath) {
      alert("No 360° image for this location yet.");
      return;
    }
    const stage = stageRef.current?.getStage?.();
    if (stage && sv.x != null && sv.y != null) {
      const nextScale = stage.scaleX() * 1.3;
      stage.to({
        scaleX: nextScale,
        scaleY: nextScale,
        x: stage.width() / 2 - sv.x * nextScale,
        y: stage.height() / 2 - sv.y * nextScale,
        duration: 0.4,
        easing: Konva.Easings.EaseInOut,
        onFinish: () => {
          setSelected({ meta: { streetImage: resolveImageUrl(sv.imagePath) } });
          setActiveStreetView(sv);
          setStreetViewOpen(true);
        },
      });
    } else {
      setSelected({ meta: { streetImage: resolveImageUrl(sv.imagePath) } });
      setActiveStreetView(sv);
      setStreetViewOpen(true);
    }
  };

 const handleNavigate = (direction) => {
  if (!route?.points || !activeStreetView) return;

  const pts = route.points;

  let closestIndex = 0;
  let minDist = Infinity;

  for (let i = 0; i < pts.length; i += 2) {
    const dx = pts[i] - activeStreetView.x;
    const dy = pts[i + 1] - activeStreetView.y;
    const dist = dx * dx + dy * dy;

    if (dist < minDist) {
      minDist = dist;
      closestIndex = i;
    }
  }

  const step = direction === "forward" ? 2 : -2;
  let nextIndex = closestIndex + step;

  nextIndex = Math.max(0, Math.min(nextIndex, pts.length - 2));

  setActiveStreetView({
    x: pts[nextIndex],
    y: pts[nextIndex + 1],
  });
};

  if (loading) {
    return (
      <Box
        sx={{
          height: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          bgcolor: "background.default",
        }}
      >
        <Stack alignItems="center" spacing={2}>
          <CircularProgress size={60} thickness={4} />
          <Typography variant="h6" color="text.secondary">
            Loading map...
          </Typography>
        </Stack>
      </Box>
    );
  }

  return (
    <Box sx={{ height: "100vh", position: "relative", overflow: "hidden" }}>
      {/* Full Screen Map */}
      <Box sx={{ height: "100%", width: "100%" }}>
        <MapViewer
          ref={stageRef}
          layout={layout}
          stalls={stalls}
          route={route}
          selected={selected}
          trackingEnabled={trackingEnabled} // <- follow screen to GPS
          onSelect={handleSelectStall}
          onStreetViewClick={handleStreetViewClick}
          activeStreetView={activeStreetView}
          entranceSide={entranceSide}
        />
      </Box>

      {/* Top Info Bar */}
      <Paper
        elevation={3}
        sx={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          background:
            theme.palette.mode === "light"
              ? "linear-gradient(180deg, rgba(255,255,255,0.98) 0%, rgba(255,255,255,0.95) 100%)"
              : "linear-gradient(180deg, rgba(26,26,26,0.98) 0%, rgba(26,26,26,0.95) 100%)",
          backdropFilter: "blur(20px)",
          borderRadius: 0,
          borderBottom: `1px solid ${theme.palette.divider}`,
        }}
      >
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          sx={{ p: 2 }}
        >
          <Stack direction="row" alignItems="center" spacing={1.5}>
            <IconButton
              onClick={() => setInfoOpen(true)}
              sx={{
                bgcolor: alpha(theme.palette.primary.main, 0.1),
                "&:hover": { bgcolor: alpha(theme.palette.primary.main, 0.2) },
              }}
            >
              <MenuRoundedIcon />
            </IconButton>
            <Box>
              <Typography variant="subtitle2" sx={{ fontWeight: 700, lineHeight: 1.2 }}>
                {layout?.name}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {entrance?.name || "Main Entrance"}
              </Typography>
            </Box>
          </Stack>

          {/* 🌗 Theme Toggle moved here */}
          <IconButton onClick={toggleMode}>
            {theme.palette.mode === "light" ? <Brightness4 /> : <Brightness7 />}
          </IconButton>
        </Stack>

      </Paper>

      {/* Floating Buttons */}
      <Stack
        spacing={2}
        sx={{
          position: "absolute",
          bottom: 24,
          right: 16,
          zIndex: 1200,
          mb: 3,
        }}
      >
        {/* Search */}
        <Fab color="primary" onClick={() => setSearchOpen(true)} aria-label="Search">
          <SearchRoundedIcon />
        </Fab>

        {/* My Location */}
        <Fab
          size="medium"
          onClick={() => {
            if (!("geolocation" in navigator) || !layout?.gpsBounds || !stageRef.current) {
              alert("Location not available.");
              return;
            }
            navigator.geolocation.getCurrentPosition(
              (pos) => {
                const { latitude, longitude } = pos.coords;
                const { minLat, maxLat, minLng, maxLng } = layout.gpsBounds;
                const { width, height } = layout.size;
                const x = ((longitude - minLng) / (maxLng - minLng)) * width;
                const y = ((maxLat - latitude) / (maxLat - minLat)) * height;

                const stage = stageRef.current.getStage();
                const scale = stage.scaleX();
                stage.to({
                  x: stage.width() / 2 - x * scale,
                  y: stage.height() / 2 - y * scale,
                  duration: 0.5,
                  easing: Konva.Easings.EaseInOut,
                });
              },
              (err) => {
                console.warn("GPS error:", err);
                alert("Could not fetch your location.");
              },
              { enableHighAccuracy: true, maximumAge: 5000, timeout: 10000 }
            );
          }}
          aria-label="My Location"
          sx={{
            bgcolor: theme.palette.mode === "light" ? "#fff" : "#2a2a2a",
            boxShadow: "0 6px 18px rgba(0,0,0,0.25)",
            "&:hover": {
              transform: "scale(1.1)",
              bgcolor: theme.palette.mode === "light" ? "#fff" : "#2a2a2a",
            },
            transition: "all 0.3s ease",
          }}
        >
          <MyLocationRoundedIcon color="primary" />
        </Fab>
      </Stack>

      {/* Navigation START Button (left side) */}
      {route && !trackingEnabled && (
        <Slide direction="up" in timeout={400}>
          <Fab
            variant="extended"
            color="success"
            onClick={handleStart}
            sx={{
              position: "absolute",
              bottom: 24,
              left: 16,
              px: 3,
              py: 1.25,
              mb: 3,
              fontWeight: 800,
              fontSize: "1rem",
              borderRadius: "50px",
              zIndex: 1300,
              boxShadow: "0 6px 24px rgba(0,0,0,0.35)",
              "&:hover": { transform: "scale(1.05)" },
              transition: "all 0.3s ease",
            }}
          >
            <NavigationRoundedIcon sx={{ mr: 1 }} />
            START
          </Fab>
        </Slide>
      )}

      {/* Search Drawer */}
      <SwipeableDrawer
        anchor="bottom"
        open={searchOpen}
        onClose={() => setSearchOpen(false)}
        onOpen={() => setSearchOpen(true)}
        disableSwipeToOpen
        transitionDuration={{ enter: 400, exit: 300 }}
        PaperProps={{
          sx: {
            borderRadius: "24px 24px 0 0",
            boxShadow: "0 -8px 32px rgba(0,0,0,0.25)",
            backdropFilter: "blur(20px)",
          },
        }}
      >
        <Box sx={{ p: 3 }}>
          <Stack direction="row" alignItems="center" spacing={2} mb={2}>
            <TextField
              placeholder="Search stores, services..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSearch()}
              fullWidth
              autoFocus
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchRoundedIcon />
                  </InputAdornment>
                ),
              }}
              sx={{ "& .MuiOutlinedInput-root": { borderRadius: 3, fontSize: "1.1rem" } }}
            />
            <IconButton onClick={() => setSearchOpen(false)}>
              <CloseRoundedIcon />
            </IconButton>
          </Stack>
          <Button
            variant="contained"
            fullWidth
            size="large"
            onClick={handleSearch}
            sx={{ borderRadius: 3, py: 1.5, fontWeight: 700 }}
          >
            Search
          </Button>
        </Box>
      </SwipeableDrawer>

      {/* Search Results Drawer */}
      <SwipeableDrawer
        anchor="bottom"
        open={resultsOpen}
        onClose={() => setResultsOpen(false)}
        onOpen={() => setResultsOpen(true)}
        transitionDuration={{ enter: 400, exit: 300 }}
        PaperProps={{
          sx: {
            borderRadius: "24px 24px 0 0",
            boxShadow: "0 -8px 32px rgba(0,0,0,0.25)",
          },
        }}
      >
        <Box sx={{ p: 2 }}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" mb={2}>
            <Typography variant="h6" sx={{ fontWeight: 700 }}>
              {results.length} Results
            </Typography>
            <IconButton onClick={() => setResultsOpen(false)}>
              <CloseRoundedIcon />
            </IconButton>
          </Stack>
          <List sx={{ maxHeight: "60vh", overflow: "auto" }}>
            {results.map((stall) => (
              <Paper
                key={stall.id}
                elevation={0}
                sx={{
                  mb: 1.5,
                  borderRadius: 3,
                  border: `1px solid ${theme.palette.divider}`,
                }}
              >
                <ListItem button onClick={() => handleSelectStall(stall)} sx={{ p: 2 }}>
                  <ListItemAvatar>
                    <Avatar sx={{ bgcolor: "primary.main", width: 48, height: 48 }}>
                      <StoreRoundedIcon />
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    primary={
                      <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
                        {stall.name}
                      </Typography>
                    }
                    secondary={
                      <Typography variant="body2" color="text.secondary" noWrap>
                        {stall.meta?.business?.description || "No description"}
                      </Typography>
                    }
                  />
                </ListItem>
              </Paper>
            ))}
          </List>
        </Box>
      </SwipeableDrawer>

      {/* Stall Details Drawer */}
      <SwipeableDrawer
        anchor="bottom"
        open={detailsOpen}
        onClose={() => setDetailsOpen(false)}
        onOpen={() => setDetailsOpen(true)}
        transitionDuration={{ enter: 400, exit: 300 }}
        PaperProps={{
          sx: {
            borderRadius: "24px 24px 0 0",
            boxShadow: "0 -8px 32px rgba(0,0,0,0.25)",
          },
        }}
      >
        {selected && (
          <Box sx={{ p: 3 }}>
            <Stack direction="row" justifyContent="space-between" alignItems="flex-start" mb={3}>
              <Box>
                <Typography variant="h5" sx={{ fontWeight: 800, mb: 1 }}>
                  {selected.name}
                </Typography>
                <Typography variant="body1" color="text.secondary" paragraph>
                  {selected.meta?.business?.description || "No description available"}
                </Typography>
                {selected.meta?.business?.services?.length > 0 && (
                  <Stack direction="row" spacing={1} flexWrap="wrap" gap={1}>
                    {selected.meta.business.services.map((s, i) => (
                      <Chip key={i} label={s} size="small" sx={{ borderRadius: 2 }} />
                    ))}
                  </Stack>
                )}
              </Box>
              <IconButton onClick={() => setDetailsOpen(false)}>
                <CloseRoundedIcon />
              </IconButton>
            </Stack>
            <Divider sx={{ my: 2 }} />
            <Stack spacing={2}>
              <Button
                variant="contained"
                fullWidth
                size="large"
                startIcon={<DirectionsRoundedIcon />}
                onClick={() => handleGetDirections(selected)}
                sx={{ borderRadius: 3, py: 1.75, fontWeight: 700 }}
              >
                Get Directions
              </Button>
              <Button
                variant="outlined"
                fullWidth
                size="large"
                startIcon={<ThreeSixtyRoundedIcon />}
                onClick={() => {
                  setStreetViewOpen(true);
                  setDetailsOpen(false);
                }}
                sx={{ borderRadius: 3, py: 1.75, fontWeight: 700 }}
              >
                Street View
              </Button>
            </Stack>
          </Box>
        )}

        
      </SwipeableDrawer>

      {/* Street View Drawer */}
      
      <Drawer
        anchor="bottom"
        open={streetViewOpen}
        onClose={() => setStreetViewOpen(false)}
        PaperProps={{
          sx: {
            height: "100vh",
            borderRadius: 0,
          },
        }}
      >
        <Box sx={{ height: "100%", position: "relative" }}>
          <IconButton
            onClick={() => setStreetViewOpen(false)}
            sx={{
              position: "absolute",
              top: 16,
              right: 16,
              zIndex: 1000,
              bgcolor: "rgba(0,0,0,0.5)",
              color: "#fff",
              "&:hover": { bgcolor: "rgba(0,0,0,0.7)" },
            }}
          >
            <CloseRoundedIcon />
          </IconButton>

          <Street360Viewer
              src={selected ? selected.meta?.streetImage : ""}
              onNavigate={handleNavigate}
            />

          {/* Mini-Map Overlay */}
          <Paper
            elevation={6}
            sx={{
              position: "absolute",
              top: 80,
              right: 16,
              width: 160,
              height: 120,
              borderRadius: 3,
              overflow: "hidden",
              zIndex: 1500,
              border: "2px solid rgba(255,255,255,0.6)",
              boxShadow: "0 4px 16px rgba(0,0,0,0.3)",
            }}
          >
            <MapViewer
              layout={layout}
              stalls={stalls}
              route={route}
              selected={selected}
              trackingEnabled={false}
              activeStreetView={activeStreetView}
              onSelect={() => { }}
              onStreetViewClick={() => { }}
            />
          </Paper>
        </Box>
      </Drawer>
    </Box>
  );
}
