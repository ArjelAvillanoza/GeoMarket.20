// 🧭 SEARCH BAR + DRAWER RESULTS
import React, { useEffect, useState } from "react";
import {
  Box,
  Paper,
  TextField,
  IconButton,
  Drawer,
  List,
  ListItemButton,
  ListItemText,
  CircularProgress,
  Typography,
} from "@mui/material";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";

function SearchDrawer ({ layout, onPick }) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSearch = async () => {
    if (!query.trim()) return;
    setLoading(true);
    setError("");
    try {
      const res = await fetch(
        `https://api.geomarket.space/api/public/search?layoutId=${layout.layoutId}&q=${encodeURIComponent(
          query.trim()
        )}`
      );
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        setResults(data);
        setOpen(true);
      } else {
        setResults([]);
        setError("No results found.");
        setOpen(true);
      }
    } catch (err) {
      setError("Search failed. Please check your connection.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* 🔍 Search Bar */}
      <Paper
        elevation={6}
        sx={{
          position: "fixed",
          top: 16,
          left: "50%",
          transform: "translateX(-50%)",
          width: "min(92%, 520px)",
          borderRadius: 4,
          px: 1.5,
          py: 0.5,
          display: "flex",
          alignItems: "center",
          gap: 1,
          zIndex: 40,
          backdropFilter: "blur(8px)",
        }}
      >
        <TextField
          fullWidth
          variant="standard"
          placeholder="Search stalls or services…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          InputProps={{
            disableUnderline: true,
          }}
        />
        {query && (
          <IconButton onClick={() => setQuery("")} size="small">
            <CloseRoundedIcon />
          </IconButton>
        )}
        <IconButton onClick={handleSearch} color="primary">
          <SearchRoundedIcon />
        </IconButton>
      </Paper>

      {/* 📜 Drawer with results */}
      <Drawer
        anchor="right"
        open={open}
        onClose={() => setOpen(false)}
        PaperProps={{
          sx: {
            width: { xs: "100%", sm: 360 },
            borderTopLeftRadius: { xs: 16, sm: 0 },
            borderTopRightRadius: { xs: 16, sm: 0 },
            p: 2,
          },
        }}
      >
        <Box>
          <Typography variant="h6" gutterBottom>
            Search Results
          </Typography>
          {loading && (
            <Box sx={{ textAlign: "center", my: 3 }}>
              <CircularProgress />
            </Box>
          )}
          {!loading && error && (
            <Typography color="text.secondary" sx={{ mt: 2 }}>
              {error}
            </Typography>
          )}
          <List>
            {results.map((stall) => (
              <ListItemButton
                key={stall.id}
                onClick={() => {
                  setOpen(false);
                  onPick(stall);
                }}
              >
                <ListItemText
                  primary={stall.name || "Unnamed Stall"}
                  secondary={
                    stall.meta?.business?.services?.join(", ") ||
                    stall.services ||
                    ""
                  }
                />
              </ListItemButton>
            ))}
          </List>
        </Box>
      </Drawer>
    </>
  );
}

export default SearchDrawer;
