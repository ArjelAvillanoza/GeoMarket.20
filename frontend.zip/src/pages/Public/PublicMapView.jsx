import React, { useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import publicApi from "../../api/publicApi";
import {
  Box,
  Paper,
  Typography,
  IconButton,
  Fade,
  Backdrop,
  Card,
  CardContent,
  Button,
  CircularProgress,
  Snackbar,
  Alert,
  Divider,
  Chip,
  useTheme,
  useMediaQuery,
  Drawer,
  TextField,
  List,
  ListItemButton,
  ListItemText,
} from "@mui/material";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import MapCanvas from "../../components/MapCanvas";

/* ──────────────────────────────────────────────── */
/* 🔍 Search Drawer Component                      */
/* ──────────────────────────────────────────────── */
function SearchDrawer ({ layout, onPick, streetViewOpen = false }) {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSearch = async () => {
    if (!query.trim()) return;
    setLoading(true);
    setError("");
    try {
      const res = await fetch(
        `https://api.geomarket.space/api/public/search?layoutId=${layout.layoutId}&q=${encodeURIComponent(
          query.trim()
        )}`
      );
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        setResults(data);
        setOpen(true);
      } else {
        setResults([]);
        setError("No results found.");
        setOpen(true);
      }
    } catch (err) {
      console.error(err);
      setError("Search failed. Please check your connection.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* 🔍 Floating Search Bar */}
      <Paper
        elevation={6}
        sx={{
          position: "fixed",
          top: 16,
          left: "50%",
          transform: "translateX(-50%)",
          width: "min(92%, 520px)",
          borderRadius: 4,
          px: 1.5,
          py: 0.5,
          display: "flex",
          alignItems: "center",
          gap: 1,
          zIndex: 40,
          backdropFilter: "blur(8px)",
          bgcolor: theme.palette.mode === "light"
            ? "rgba(255,255,255,0.9)"
            : "rgba(32,33,36,0.85)",
          // hide the floating search when mobile split-view is active
          display: (isMobile && streetViewOpen) ? 'none' : 'flex',
        }}
      >
        <TextField
          fullWidth
          variant="standard"
          placeholder="Search stalls or services…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          InputProps={{
            disableUnderline: true,
          }}
        />
        {query && (
          <IconButton onClick={() => setQuery("")} size="small">
            <CloseRoundedIcon />
          </IconButton>
        )}
        <IconButton onClick={handleSearch} color="primary">
          <SearchRoundedIcon />
        </IconButton>
      </Paper>

      {/* 📜 Drawer with results */}
      <Drawer
        anchor={isMobile ? "bottom" : "right"}
        open={open}
        onClose={() => setOpen(false)}
        PaperProps={{
          sx: {
            width: { xs: "100%", sm: 360 },
            height: isMobile ? "60%" : "100%",
            borderTopLeftRadius: isMobile ? 16 : 0,
            borderTopRightRadius: isMobile ? 16 : 0,
            p: 2,
          },
        }}
      >
        <Box>
          <Typography variant="h6" gutterBottom>
            Search Results
          </Typography>

          {loading && (
            <Box sx={{ textAlign: "center", my: 3 }}>
              <CircularProgress />
            </Box>
          )}

          {!loading && error && (
            <Typography color="text.secondary" sx={{ mt: 2 }}>
              {error}
            </Typography>
          )}

          <List>
            {results.map((stall) => (
              <ListItemButton
                key={stall.id}
                onClick={() => {
                  setOpen(false);
                  onPick(stall);
                }}
              >
                <ListItemText
                  primary={stall.name || "Unnamed Stall"}
                  secondary={
                    stall.meta?.business?.services?.join(", ") ||
                    stall.services ||
                    ""
                  }
                />
              </ListItemButton>
            ))}
          </List>
        </Box>
      </Drawer>
    </>
  );
}

/* ──────────────────────────────────────────────── */
/* 🗺️  Main Public Map View Page                   */
/* ──────────────────────────────────────────────── */
export default function PublicMapView () {
  const { entranceId } = useParams();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  const [layout, setLayout] = useState(null);
  const [selected, setSelected] = useState(null);
  const [path, setPath] = useState([]);
  const [loadingPath, setLoadingPath] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [showInfoCard, setShowInfoCard] = useState(false);
  const [mapEffect, setMapEffect] = useState(false);
  const [focusPoint, setFocusPoint] = useState(null);
  const [destinationStall, setDestinationStall] = useState(null);
  const [streetViewOpen, setStreetViewOpen] = useState(false);
  const [activeStreetView, setActiveStreetView] = useState(null);
  /* ── Load layout on mount ── */
  useEffect(() => {
    (async () => {
      try {
        const res = await publicApi.getEntrance(entranceId);
        setLayout(res.data);
      } catch {
        setErrorMsg("Unable to load map layout. Please try again later.");
      }
    })();
  }, [entranceId]);

  const clearSelection = () => {
    setSelected(null);
    setPath([]);
    setShowInfoCard(false);
    setDestinationStall(null);
  };

  const handleDirection = async () => {
    if (!selected || !layout) return;
    setShowInfoCard(false);
    setLoadingPath(true);
    try {
      const res = await publicApi.getDirections(
        layout.layoutId,
        entranceId,
        selected.id,
      );
      if (res.data?.ok && Array.isArray(res.data.points)) {
        setPath(res.data.points);
        setMapEffect(true);
        setTimeout(() => setMapEffect(false), 1500);
      } else {
        setErrorMsg("No route found to this location.");
      }
    } catch {
      setErrorMsg("Error fetching directions. Please try again.");
    } finally {
      setLoadingPath(false);
    }
  };

  const entrance = layout?.entrance;

return (
  <Box
    sx={{
      height: "100vh",
      display: "flex",
      flexDirection: "column",
      position: "relative",
      bgcolor: "background.default",
    }}
  >
    {!layout ? (
      // ✅ LOADING STATE (moved inside return)
      <Box
        sx={{
          height: "100vh",
          display: "grid",
          placeItems: "center",
          bgcolor: "background.default",
        }}
      >
        <CircularProgress />
        <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
          Loading map…
        </Typography>
      </Box>
    ) : (
      <>
        {/* 🔍 Search Bar + Drawer Results */}
        <SearchDrawer
          layout={layout}
          streetViewOpen={streetViewOpen}
          onPick={(stall) => {
            setLayout((prev) => ({
              ...prev,
              stalls: Array.isArray(prev?.stalls)
                ? [...prev.stalls.filter((s) => s.id !== stall.id), stall]
                : [stall],
            }));

            setPath([]);
            setMapEffect(false);
            setSelected(stall);
            setDestinationStall(stall);
            setFocusPoint({
              x: stall.x + stall.width / 2,
              y: stall.y + stall.height / 2,
            });

            setTimeout(() => setShowInfoCard(true), 500);
          }}
        />

        {/* 🗺️ Map */}
        <Box
          sx={{
            flexGrow: streetViewOpen ? 0 : 1,
            overflow: "hidden",
            mt: streetViewOpen ? 0 : { xs: 10, sm: 12 },
            height: streetViewOpen ? "100vh" : "auto",
          }}
        >
          <MapCanvas
            layout={layout}
            entrance={entrance}
            path={path}
            mapEffect={mapEffect}
            focusPoint={focusPoint}
            destinationStall={destinationStall}
            streetViewOpen={streetViewOpen}
            setStreetViewOpen={setStreetViewOpen}
            activeStreetView={activeStreetView}
            setActiveStreetView={setActiveStreetView}
            onSelectStall={(s) => {
              setPath([]);
              setMapEffect(false);
              setSelected(s);
              setDestinationStall(s);
              setFocusPoint({
                x: s.x + s.width / 2,
                y: s.y + s.height / 2,
              });
              setShowInfoCard(false);
              setTimeout(() => setShowInfoCard(true), 500);
            }}
          />
        </Box>

        {/* 🧾 Stall Info Card */}
        <Fade in={showInfoCard && !!selected}>
          <Card
            elevation={10}
            sx={{
              position: "fixed",
              left: "50%",
              transform: "translateX(-50%)",
              bottom: 20,
              width: "min(92%, 520px)",
              zIndex: 25,
              transition: "all 0.3s ease",
            }}
          >
            <CardContent sx={{ py: 2, px: 2.5 }}>
              <Typography variant="h6" gutterBottom noWrap>
                {selected?.name || selected?.label || "Selected Stall"}
              </Typography>

              {selected?.meta?.business && (
                <Box sx={{ mb: 1.5 }}>
                  {selected.meta.business.description && (
                    <Typography variant="body2" sx={{ mb: 1 }}>
                      {selected.meta.business.description}
                    </Typography>
                  )}
                  {Array.isArray(selected.meta.business.services) &&
                    selected.meta.business.services.length > 0 && (
                      <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
                        {selected.meta.business.services.map((srv, idx) => (
                          <Chip
                            key={idx}
                            label={srv}
                            color="primary"
                            variant="outlined"
                            size="small"
                          />
                        ))}
                      </Box>
                    )}
                </Box>
              )}

              <Divider sx={{ my: 1.5 }} />

              <Box
                sx={{ display: "flex", justifyContent: "flex-end", gap: 1.5 }}
              >
                <Button
                  variant="outlined"
                  onClick={clearSelection}
                  size={isMobile ? "small" : "medium"}
                >
                  Close
                </Button>

                <Button
                  variant="contained"
                  disableElevation
                  onClick={handleDirection}
                  disabled={loadingPath}
                  size={isMobile ? "small" : "medium"}
                  sx={{ borderRadius: 3, px: 2.5 }}
                >
                  {loadingPath ? "Finding…" : "Get Directions"}
                </Button>
              </Box>
            </CardContent>
          </Card>
        </Fade>

        {/* ⚠️ Snackbar Feedback */}
        <Snackbar
          open={!!errorMsg}
          autoHideDuration={4000}
          onClose={() => setErrorMsg("")}
          anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
        >
          <Alert
            severity="error"
            onClose={() => setErrorMsg("")}
            variant="filled"
          >
            {errorMsg}
          </Alert>
        </Snackbar>
      </>
    )}
  </Box>
);
}
