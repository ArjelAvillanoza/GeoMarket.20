import React, { useEffect, useMemo, useState } from "react";
import {
  Container,
  Typography,
  Box,
  Paper,
  Avatar,
  Button,
  Stack,
  Divider,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  useTheme,
  alpha,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { setUser } from "../../redux/slices/authSlice";
import userApi from "../../api/userApi";
import { regions, provinces, cities, barangays } from "select-philippines-address";
import { resolveImageUrl } from "../../utils/url";
import PersonAddIcon from "@mui/icons-material/PersonAdd";
import SaveRoundedIcon from "@mui/icons-material/SaveRounded";
import CancelRoundedIcon from "@mui/icons-material/CancelRounded";

export default function ProfilePage () {
  const dispatch = useDispatch();
  const theme = useTheme();
  const user = useSelector((s) => s.auth.user);
  const userId = user?._id;

  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    businessName: "",
  });
  const [profilePicture, setProfilePicture] = useState(null);
  const [preview, setPreview] = useState("");
  const [regionList, setRegionList] = useState([]);
  const [provinceList, setProvinceList] = useState([]);
  const [cityList, setCityList] = useState([]);
  const [barangayList, setBarangayList] = useState([]);
  const [address, setAddress] = useState({
    region: "",
    province: "",
    city: "",
    barangay: "",
    regionCode: "",
    provinceCode: "",
    cityCode: "",
    barangayCode: "",
  });

  // Prefill from Redux
  useEffect(() => {
    if (!user) return;
    setForm({
      name: user.name || "",
      email: user.email || "",
      phone: user.phone || "",
      businessName: user.businessName || "",
    });
    const path = user.profilePicture || "/uploads/default-admin.png";
    setPreview(resolveImageUrl(path));
    const a = user.address || {};
    setAddress({
      region: a.region || "",
      province: a.province || "",
      city: a.city || "",
      barangay: a.barangay || "",
      regionCode: a.regionCode || "",
      provinceCode: a.provinceCode || "",
      cityCode: a.cityCode || "",
      barangayCode: a.barangayCode || "",
    });
  }, [user]);

  useEffect(() => {
    regions().then(setRegionList);
  }, []);

  // Cascades
  useEffect(() => {
    (async () => {
      if (address.regionCode) setProvinceList(await provinces(address.regionCode));
      if (address.provinceCode) setCityList(await cities(address.provinceCode));
      if (address.cityCode) setBarangayList(await barangays(address.cityCode));
    })();
  }, [address.regionCode, address.provinceCode, address.cityCode]);

  // Handlers
  const onPickFile = (e) => {
    const file = e.target.files?.[0];
    setProfilePicture(file);
    if (file) setPreview(URL.createObjectURL(file));
    else setPreview(resolveImageUrl(user?.profilePicture || "/uploads/default-admin.png"));
  };

  const removeAvatar = () => {
    setProfilePicture(null);
    setPreview(resolveImageUrl(user?.profilePicture || "/uploads/default-admin.png"));
  };

  const handleSave = async () => {
  try {
    const fd = new FormData();

    fd.append("name", form.name);
    fd.append("phone", form.phone);
    fd.append("businessName", form.businessName);
    fd.append("address", JSON.stringify(address));

    if (profilePicture) {
      fd.append("profilePicture", profilePicture); // 👈 MUST MATCH
    }

    const res = await userApi.updateProfile(fd);

    console.log("✅ RESPONSE:", res.data);

    dispatch(setUser(res.data.user));

    alert("Profile updated!");
  } catch (err) {
    console.error("❌ ERROR:", err.response?.data || err.message);
  }
};

  const title = useMemo(
    () => (user?.role === "ceemo_admin" ? "Ceemo Admin Profile" : "Vendor Profile"),
    [user?.role]
  );

  return (
    <Box
      sx={{
        minHeight: "100vh",
        bgcolor: "background.default",
        pt: { xs: 10, md: 12 },
        pb: 6,
      }}
    >
      <Container maxWidth="md">
        <Box
          sx={{
            p: 7,
            borderRadius: 1,
            border: `1px solid ${theme.palette.divider}`,
            bgcolor:
              theme.palette.mode === "light"
                ? alpha(theme.palette.background.paper, 0.8)
                : alpha(theme.palette.background.paper, 0.15),
            backdropFilter: "blur(8px)",
            boxShadow:
              theme.palette.mode === "light"
                ? "0 4px 20px rgba(0,0,0,0.06)"
                : "0 4px 24px rgba(0,0,0,0.4)",
          }}
        >
          <Box
            sx={{
              background: "transparent",
              mb:3,
             color:
               theme.palette.mode === "light"
                 ? theme.palette.text.primary
                 : "rgba(255,255,255,0.9)",
            }}
          >
            <Typography variant="h5" sx={{ fontWeight: 700, mb: 0.5 }}>
              {title}
            </Typography>
            <Typography variant="body2" sx={{ opacity: 0.9 }}>
              Manage your personal and business details
            </Typography>
          </Box>
          {/* Avatar */}
          <Stack direction="row" spacing={3} alignItems="center" sx={{ mb: 3 }}>
            <Avatar
              src={preview}
              sx={{
                width: 96,
                height: 96,
                border: `3px solid ${theme.palette.background.paper}`,
                boxShadow:
                  theme.palette.mode === "light"
                    ? "0 4px 14px rgba(0,0,0,0.1)"
                    : "0 4px 18px rgba(139, 92, 246, 0.3)",
              }}
            />
            <Box>
              <Button
                variant="outlined"
                component="label"
                startIcon={<PersonAddIcon />}
                sx={{
                  borderRadius: 2,
                  fontWeight: 600,
                  textTransform: "none",
                  mr: 1.5,
                }}
              >
                Upload New
                <input type="file" hidden accept="image/*" onChange={onPickFile} />
              </Button>
              <Button
                variant="text"
                color="error"
                onClick={removeAvatar}
                sx={{ textTransform: "none", fontWeight: 600 }}
              >
                Remove
              </Button>
            </Box>
          </Stack>

          <Divider sx={{ my: 3 }} />

          {/* Basic Info */}
          <Typography
            variant="subtitle1"
            sx={{
              fontWeight: 700,
              mb: 2,
              color:
                theme.palette.mode === "light"
                  ? "text.primary"
                  : "rgba(255,255,255,0.9)",
            }}
          >
            Basic Information
          </Typography>
          <Stack spacing={2} sx={{ mb: 3 }}>
            <TextField
              label="Full Name"
              fullWidth
              value={form.name}
              onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
            />
            <TextField
              label="Email"
              fullWidth
              value={form.email}
              InputProps={{ readOnly: true }}
            />
            <TextField
              label="Phone"
              fullWidth
              value={form.phone}
              onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))}
            />
            <TextField
              label="Business Name"
              fullWidth
              value={form.businessName}
              onChange={(e) => setForm((p) => ({ ...p, businessName: e.target.value }))}
            />
          </Stack>

          <Divider sx={{ my: 3 }} />

          {/* Address Section */}
          <Typography
            variant="subtitle1"
            sx={{
              fontWeight: 700,
              mb: 2,
              color:
                theme.palette.mode === "light"
                  ? "text.primary"
                  : "rgba(255,255,255,0.9)",
            }}
          >
            Address
          </Typography>
          <Stack spacing={2} sx={{ mb: 4 }}>
            <FormControl fullWidth>
              <InputLabel>Region</InputLabel>
              <Select
                value={address.region}
                label="Region"
                onChange={async (e) => {
                  const regionName = e.target.value;
                  const r = regionList.find((x) => x.region_name === regionName);
                  const regionCode = r ? r.region_code : "";
                  const provs = regionCode ? await provinces(regionCode) : [];
                  setProvinceList(provs);
                  setCityList([]);
                  setBarangayList([]);
                  setAddress({
                    region: regionName,
                    regionCode,
                    province: "",
                    provinceCode: "",
                    city: "",
                    cityCode: "",
                    barangay: "",
                    barangayCode: "",
                  });
                }}
              >
                {regionList.map((r) => (
                  <MenuItem key={r.region_code} value={r.region_name}>
                    {r.region_name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl fullWidth disabled={!provinceList.length}>
              <InputLabel>Province</InputLabel>
              <Select
                value={address.province}
                label="Province"
                onChange={async (e) => {
                  const name = e.target.value;
                  const p = provinceList.find((x) => x.province_name === name);
                  const code = p ? p.province_code : "";
                  const cits = code ? await cities(code) : [];
                  setCityList(cits);
                  setBarangayList([]);
                  setAddress((prev) => ({
                    ...prev,
                    province: name,
                    provinceCode: code,
                    city: "",
                    barangay: "",
                    cityCode: "",
                    barangayCode: "",
                  }));
                }}
              >
                {provinceList.map((p) => (
                  <MenuItem key={p.province_code} value={p.province_name}>
                    {p.province_name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl fullWidth disabled={!cityList.length}>
              <InputLabel>City/Municipality</InputLabel>
              <Select
                value={address.city}
                label="City/Municipality"
                onChange={async (e) => {
                  const name = e.target.value;
                  const c = cityList.find((x) => x.city_name === name);
                  const code = c ? c.city_code : "";
                  const brgys = code ? await barangays(code) : [];
                  setBarangayList(brgys);
                  setAddress((prev) => ({
                    ...prev,
                    city: name,
                    cityCode: code,
                    barangay: "",
                    barangayCode: "",
                  }));
                }}
              >
                {cityList.map((c) => (
                  <MenuItem key={c.city_code} value={c.city_name}>
                    {c.city_name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl fullWidth disabled={!barangayList.length}>
              <InputLabel>Barangay</InputLabel>
              <Select
                value={address.barangay}
                label="Barangay"
                onChange={(e) => {
                  const name = e.target.value;
                  const b = barangayList.find((x) => x.brgy_name === name);
                  setAddress((prev) => ({
                    ...prev,
                    barangay: name,
                    barangayCode: b ? b.brgy_code : "",
                  }));
                }}
              >
                {barangayList.map((b) => (
                  <MenuItem key={b.brgy_code} value={b.brgy_name}>
                    {b.brgy_name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Stack>

          {/* Buttons */}
          <Box sx={{ display: "flex", gap: 1.5, justifyContent: "flex-end" }}>
            <Button
              variant="text"
              startIcon={<CancelRoundedIcon />}
              onClick={() => window.history.back()}
              sx={{
                textTransform: "none",
                fontWeight: 600,
                color: "text.secondary",
                "&:hover": { color: "error.main" },
              }}
            >
              Cancel
            </Button>
            <Button
              variant="contained"
              startIcon={<SaveRoundedIcon />}
              onClick={handleSave}
              sx={{
                borderRadius: 2,
                textTransform: "none",
                fontWeight: 700,
                px: 3,
                background:
                  theme.palette.mode === "light"
                    ? "linear-gradient(135deg, #667eea 0%, #764ba2 100%)"
                    : "linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)",
                boxShadow:
                  theme.palette.mode === "light"
                    ? "0 4px 14px rgba(75, 86, 210, 0.3)"
                    : "0 4px 20px rgba(139, 92, 246, 0.4)",
                "&:hover": {
                  background:
                    theme.palette.mode === "light"
                      ? "linear-gradient(135deg, #764ba2 0%, #667eea 100%)"
                      : "linear-gradient(135deg, #a78bfa 0%, #818cf8 100%)",
                  transform: "translateY(-2px)",
                },
              }}
            >
              Save Changes
            </Button>
          </Box>
        </Box>
      </Container>
    </Box>
  );
}
