// src/pages/ResetPasswordPage.jsx
import React, { useState } from "react";
import userApi from "../../api/userApi";
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Fade,
  InputAdornment,
  IconButton,
  useTheme,
} from "@mui/material";
import VpnKeyOutlinedIcon from "@mui/icons-material/VpnKeyOutlined";
import LockResetOutlinedIcon from "@mui/icons-material/LockResetOutlined";
import MapOutlinedIcon from "@mui/icons-material/MapOutlined";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import { useLocation, useNavigate } from "react-router-dom";

export default function ResetPasswordPage () {
  const { state } = useLocation();
  const navigate = useNavigate();
  const email = state?.email || "";

  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [message, setMessage] = useState("");

  const theme = useTheme();
  const isLight = theme.palette.mode === "light";

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setMessage("Passwords do not match");
      return;
    }
    try {
      await userApi.resetPassword({ email, otp, newPassword });
      setMessage("Password reset successful!");
      setTimeout(() => navigate("/"), 2000);
    } catch (err) {
      setMessage(err.response?.data?.message || "Reset failed");
    }
  };

  return (
    <Fade in timeout={600}>
      <Box
        sx={{
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
          background: isLight
            ? "linear-gradient(180deg, #c7cdf5 0%, #b8bef0 50%, #c7cdf5 100%)"
            : "linear-gradient(180deg, #1a1a1f 0%, #18181c 100%)",
          px: 3,
        }}
      >
        {/* ===== Header / Logo ===== */}
        <Box sx={{ textAlign: "center", mb: 4 }}>
          <Box
            sx={{
              width: 72,
              height: 72,
              mx: "auto",
              mb: 2,
              borderRadius: "50%",
              backgroundColor: theme.palette.background.paper,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 2px 8px rgba(0,0,0,0.25)",
            }}
          >
            <MapOutlinedIcon
              sx={{ fontSize: 40, color: theme.palette.primary.main }}
            />
          </Box>
          <Typography
            variant="h5"
            sx={{
              fontWeight: 700,
              color: theme.palette.text.primary,
              letterSpacing: 1,
            }}
          >
            GEOMARKET
          </Typography>
          <Typography
            variant="body2"
            sx={{
              mt: 1,
              color: theme.palette.text.secondary,
              fontSize: "0.95rem",
            }}
          >
            Reset your password securely
          </Typography>
        </Box>

        {/* ===== Reset Password Card ===== */}
        <Paper
          elevation={8}
          sx={{
            p: { xs: 3, sm: 4 },
            width: "100%",
            maxWidth: 400,
            backgroundColor: theme.palette.background.paper,
            boxShadow: "0 6px 18px rgba(0,0,0,0.15)",
          }}
        >
          <Typography
            variant="h6"
            sx={{
              fontWeight: 600,
              textAlign: "center",
              color: theme.palette.primary.main,
              mb: 3,
            }}
          >
            Reset Password
          </Typography>

          <Box component="form" onSubmit={handleSubmit}>
            {/* OTP Field */}
            <TextField
              label="OTP"
              variant="outlined"
              fullWidth
              margin="normal"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <VpnKeyOutlinedIcon
                      sx={{ color: theme.palette.text.secondary }}
                    />
                  </InputAdornment>
                ),
              }}
            />

            {/* New Password */}
            <TextField
              label="New Password"
              type={showNew ? "text" : "password"}
              variant="outlined"
              fullWidth
              margin="normal"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <LockResetOutlinedIcon
                      sx={{ color: theme.palette.text.secondary }}
                    />
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() => setShowNew(!showNew)}
                      edge="end"
                      size="small"
                    >
                      {showNew ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />

            {/* Confirm Password */}
            <TextField
              label="Confirm Password"
              type={showConfirm ? "text" : "password"}
              variant="outlined"
              fullWidth
              margin="normal"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <LockResetOutlinedIcon
                      sx={{ color: theme.palette.text.secondary }}
                    />
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() => setShowConfirm(!showConfirm)}
                      edge="end"
                      size="small"
                    >
                      {showConfirm ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />

            {/* Message */}
            {message && (
              <Typography
                sx={{
                  mt: 2,
                  textAlign: "center",
                  fontWeight: 500,
                  color: message.includes("successful")
                    ? theme.palette.primary.main
                    : theme.palette.error.main,
                }}
              >
                {message}
              </Typography>
            )}

            {/* Submit Button */}
            <Button
              type="submit"
              variant="contained"
              fullWidth
              sx={{
                mt: 3,
                py: 1.3,
                borderRadius: 2,
                textTransform: "none",
                fontWeight: 600,
              }}
            >
              Reset Password
            </Button>
          </Box>
        </Paper>

        {/* ===== Footer ===== */}
        <Typography
          variant="caption"
          sx={{
            mt: 5,
            color: theme.palette.text.secondary,
            opacity: 0.7,
            letterSpacing: 0.3,
          }}
        >
          © {new Date().getFullYear()} GeoMarket. All rights reserved.
        </Typography>
      </Box>
    </Fade>
  );
}
