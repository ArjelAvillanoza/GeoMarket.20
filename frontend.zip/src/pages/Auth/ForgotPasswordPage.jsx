// src/pages/ForgotPasswordPage.jsx
import React, { useState } from "react";
import userApi from "../../api/userApi";
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Fade,
  InputAdornment,
  useTheme,
} from "@mui/material";
import EmailOutlinedIcon from "@mui/icons-material/EmailOutlined";
import MapOutlinedIcon from "@mui/icons-material/MapOutlined";
import { useNavigate } from "react-router-dom";

export default function ForgotPasswordPage () {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const navigate = useNavigate();
  const theme = useTheme();
  const isLight = theme.palette.mode === "light";

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await userApi.forgotPassword({ email });
      setMessage("OTP sent! Check your email.");
      setTimeout(() => navigate("/reset-password", { state: { email } }), 2000);
    } catch (err) {
      setMessage(err.response?.data?.message || "Error sending OTP");
    }
  };

  return (
    <Fade in timeout={600}>
      <Box
        sx={{
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
          background: isLight
            ? "linear-gradient(180deg, #c7cdf5 0%, #b8bef0 50%, #c7cdf5 100%)"
            : "linear-gradient(180deg, #1a1a1f 0%, #18181c 100%)",
          px: 3,
        }}
      >
        {/* ===== Header / Logo ===== */}
        <Box sx={{ textAlign: "center", mb: 4 }}>
          <Box
            sx={{
              width: 72,
              height: 72,
              mx: "auto",
              mb: 2,
              borderRadius: "50%",
              backgroundColor: theme.palette.background.paper,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 2px 8px rgba(0,0,0,0.25)",
            }}
          >
            <MapOutlinedIcon
              sx={{
                fontSize: 40,
                color: theme.palette.primary.main,
              }}
            />
          </Box>
          <Typography
            variant="h5"
            sx={{
              fontWeight: 700,
              color: theme.palette.text.primary,
              letterSpacing: 1,
            }}
          >
            GEOMARKET
          </Typography>
          <Typography
            variant="body2"
            sx={{
              mt: 1,
              color: theme.palette.text.secondary,
              fontSize: "0.95rem",
            }}
          >
            Forgot your password? No worries!
          </Typography>
        </Box>

        {/* ===== Forgot Password Card ===== */}
        <Paper
          elevation={8}
          sx={{
            p: { xs: 3, sm: 4 },
            width: "100%",
            maxWidth: 400,
            backgroundColor: theme.palette.background.paper,
            boxShadow: "0 6px 18px rgba(0,0,0,0.15)",
          }}
        >
          <Typography
            variant="h6"
            sx={{
              fontWeight: 600,
              textAlign: "center",
              color: theme.palette.primary.main,
              mb: 3,
            }}
          >
            Forgot Password
          </Typography>

          <Box component="form" onSubmit={handleSubmit}>
            <TextField
              label="Email Address"
              variant="outlined"
              fullWidth
              margin="normal"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <EmailOutlinedIcon
                      sx={{ color: theme.palette.text.secondary }}
                    />
                  </InputAdornment>
                ),
              }}
            />

            <Button
              type="submit"
              variant="contained"
              fullWidth
              sx={{
                mt: 3,
                py: 1.3,
                borderRadius: 2,
                textTransform: "none",
                fontWeight: 600,
              }}
            >
              Send OTP
            </Button>

            {message && (
              <Typography
                textAlign="center"
                sx={{
                  mt: 2,
                  fontWeight: 500,
                  color: message.includes("Error")
                    ? theme.palette.error.main
                    : theme.palette.primary.main,
                }}
              >
                {message}
              </Typography>
            )}
          </Box>

          {/* ===== Back to Login Button ===== */}
          <Box sx={{ textAlign: "center", mt: 3 }}>
            <Button
              variant="text"
              onClick={() => navigate("/")}
              sx={{
                color: theme.palette.primary.main,
                fontWeight: 500,
                textTransform: "none",
              }}
            >
              ← Back to Login
            </Button>
          </Box>
        </Paper>

        {/* ===== Footer ===== */}
        <Typography
          variant="caption"
          sx={{
            mt: 5,
            color: theme.palette.text.secondary,
            opacity: 0.7,
            letterSpacing: 0.3,
          }}
        >
          © {new Date().getFullYear()} GeoMarket. All rights reserved.
        </Typography>
      </Box>
    </Fade>
  );
}
