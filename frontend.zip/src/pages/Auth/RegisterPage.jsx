import React, { useState, useEffect } from "react";
import {
  Box,
  Container,
  Typography,
  Paper,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
  Stack,
  Avatar,
  useTheme,
  alpha,
  InputAdornment,
  useMediaQuery,
} from "@mui/material";
import { useDispatch } from "react-redux";
import { registerUser } from "../../redux/slices/authSlice";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import { regions, provinces, cities, barangays } from "select-philippines-address";

import PersonAddIcon from "@mui/icons-material/PersonAdd";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import EmailOutlinedIcon from "@mui/icons-material/EmailOutlined";
import PhoneIphoneOutlinedIcon from "@mui/icons-material/PhoneIphoneOutlined";
import BusinessOutlinedIcon from "@mui/icons-material/BusinessOutlined";
import SaveRoundedIcon from "@mui/icons-material/SaveRounded";
import CancelRoundedIcon from "@mui/icons-material/CancelRounded";
import PersonOutlineOutlinedIcon from "@mui/icons-material/PersonOutlineOutlined";
import PlaceOutlinedIcon from "@mui/icons-material/PlaceOutlined";
import MapOutlinedIcon from "@mui/icons-material/MapOutlined";

export default function RegisterPage() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const theme = useTheme();
  const mode = theme.palette.mode;
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  const [inviteToken, setInviteToken] = useState("");
  useEffect(() => {
    const token = searchParams.get("invite");
    if (token) setInviteToken(token);
  }, [searchParams]);

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    phone: "",
    businessName: "",
  });

  const [profilePicture, setProfilePicture] = useState(null);
  const [preview, setPreview] = useState("");

  const [regionList, setRegionList] = useState([]);
  const [provinceList, setProvinceList] = useState([]);
  const [cityList, setCityList] = useState([]);
  const [barangayList, setBarangayList] = useState([]);
  const [address, setAddress] = useState({
    region: "",
    province: "",
    city: "",
    barangay: "",
    regionCode: "",
    provinceCode: "",
    cityCode: "",
    barangayCode: "",
  });

  useEffect(() => {
    regions().then(setRegionList);
  }, []);

  // Cascading address selects
  const handleRegionChange = async (e) => {
    const name = e.target.value;
    const r = regionList.find((x) => x.region_name === name);
    const code = r?.region_code || "";
    const provs = code ? await provinces(code) : [];
    setProvinceList(provs);
    setCityList([]);
    setBarangayList([]);
    setAddress({
      region: name,
      regionCode: code,
      province: "",
      provinceCode: "",
      city: "",
      cityCode: "",
      barangay: "",
      barangayCode: "",
    });
  };
  const handleProvinceChange = async (e) => {
    const name = e.target.value;
    const p = provinceList.find((x) => x.province_name === name);
    const code = p?.province_code || "";
    const cits = code ? await cities(code) : [];
    setCityList(cits);
    setBarangayList([]);
    setAddress((prev) => ({
      ...prev,
      province: name,
      provinceCode: code,
      city: "",
      cityCode: "",
      barangay: "",
      barangayCode: "",
    }));
  };
  const handleCityChange = async (e) => {
    const name = e.target.value;
    const c = cityList.find((x) => x.city_name === name);
    const code = c?.city_code || "";
    const brgys = code ? await barangays(code) : [];
    setBarangayList(brgys);
    setAddress((prev) => ({
      ...prev,
      city: name,
      cityCode: code,
      barangay: "",
      barangayCode: "",
    }));
  };
  const handleBarangayChange = (e) => {
    const name = e.target.value;
    const b = barangayList.find((x) => x.brgy_name === name);
    setAddress((prev) => ({
      ...prev,
      barangay: name,
      barangayCode: b ? b.brgy_code : "",
    }));
  };

  const onPickFile = (e) => {
    const file = e.target.files?.[0];
    setProfilePicture(file);
    if (file) setPreview(URL.createObjectURL(file));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([key, val]) => fd.append(key, val));
      if (profilePicture) fd.append("profilePicture", profilePicture);
      fd.append("address", JSON.stringify(address));
      if (inviteToken) fd.append("inviteToken", inviteToken);
      await dispatch(registerUser(fd)).unwrap();
      alert("✅ Registration successful!");
      navigate("/");
    } catch (err) {
      alert("❌ " + (err.response?.data?.message || err.message));
    }
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        background:
          mode === "light"
            ? "linear-gradient(135deg, #eef1fb 0%, #f8f9ff 100%)"
            : "linear-gradient(135deg, #0d0d12 0%, #1a1a1f 100%)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        py: { xs: 4, md: 8 },
        px: { xs: 1.5, sm: 3, md: 4 },
      }}
    >
      <Container maxWidth="lg" sx={{ px: { xs: 0, sm: 2 } }}>
        <Paper
          elevation={12}
          sx={{
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            overflow: "hidden",
            boxShadow:
              mode === "light"
                ? "0 10px 40px rgba(0,0,0,0.08)"
                : "0 10px 40px rgba(0,0,0,0.6)",
          }}
        >
          {/* ===== Left Side ===== */}
          <Box
            sx={{
              flex: 1,
              background:
                mode === "light"
                  ? "linear-gradient(135deg, #a5b4fc 0%, #818cf8 100%)"
                  : "linear-gradient(135deg, #3730a3 0%, #312e81 100%)",
              color: "#fff",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              textAlign: "center",
              p: { xs: 4, sm: 5, md: 6 },
              minHeight: { xs: 220, sm: 260, md: "auto" },
            }}
          >
            <MapOutlinedIcon
              sx={{
                fontSize: { xs: 60, sm: 80, md: 90 },
                mb: 2,
                opacity: 0.95,
              }}
            />
            <Typography
              variant={isMobile ? "h5" : "h4"}
              sx={{ fontWeight: 700, mb: 1 }}
            >
              Welcome to GeoMarket
            </Typography>
            <Typography
              sx={{
                opacity: 0.9,
                fontSize: { xs: "0.9rem", sm: "1rem" },
                maxWidth: 340,
                lineHeight: 1.5,
              }}
            >
              Connect your business to your local marketplace map and join
              hundreds of vendors growing their reach online.
            </Typography>
          </Box>

          {/* ===== Right Side ===== */}
          <Box
            sx={{
              flex: 1,
              backgroundColor: theme.palette.background.paper,
              p: { xs: 3, sm: 5, md: 6 },
              transition: "background-color 0.3s ease",
            }}
          >
            <Typography
              variant={isMobile ? "h5" : "h4"}
              sx={{
                textAlign: "center",
                fontWeight: 700,
                mb: 0.5,
                color: theme.palette.primary.main,
              }}
            >
              Vendor Registration
            </Typography>
            <Typography
              variant="body2"
              sx={{
                textAlign: "center",
                color: theme.palette.text.secondary,
                mb: { xs: 3, sm: 4 },
                fontSize: { xs: "0.85rem", sm: "0.95rem" },
              }}
            >
              Create your vendor account to start managing your business on GeoMarket
            </Typography>

            {/* Avatar Upload */}
            <Stack
              direction={isMobile ? "column" : "row"}
              alignItems="center"
              spacing={2}
              sx={{ mb: 3, textAlign: isMobile ? "center" : "left" }}
            >
              <Avatar
                src={preview || ""}
                sx={{
                  width: isMobile ? 64 : 72,
                  height: isMobile ? 64 : 72,
                  mx: isMobile ? "auto" : 0,
                  border: `2px solid ${theme.palette.divider}`,
                }}
              />
              <Button
                variant="outlined"
                component="label"
                startIcon={<PersonAddIcon />}
                sx={{
                  borderRadius: 2,
                  textTransform: "none",
                  fontWeight: 600,
                  alignSelf: isMobile ? "center" : "flex-start",
                }}
              >
                Upload Photo
                <input type="file" hidden accept="image/*" onChange={onPickFile} />
              </Button>
            </Stack>

            {/* Form */}
            <form onSubmit={handleSubmit}>
              <Stack spacing={2}>
                <TextField
                  label="Full Name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <PersonOutlineOutlinedIcon sx={{ color: "text.secondary" }} />
                      </InputAdornment>
                    ),
                  }}
                  required
                />
                <TextField
                  label="Email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <EmailOutlinedIcon sx={{ color: "text.secondary" }} />
                      </InputAdornment>
                    ),
                  }}
                  required
                />
                <TextField
                  label="Password"
                  type="password"
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <LockOutlinedIcon sx={{ color: "text.secondary" }} />
                      </InputAdornment>
                    ),
                  }}
                  required
                />
                <TextField
                  label="Phone Number"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <PhoneIphoneOutlinedIcon sx={{ color: "text.secondary" }} />
                      </InputAdornment>
                    ),
                  }}
                />
                <TextField
                  label="Business Name"
                  value={form.businessName}
                  onChange={(e) =>
                    setForm({ ...form, businessName: e.target.value })
                  }
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <BusinessOutlinedIcon sx={{ color: "text.secondary" }} />
                      </InputAdornment>
                    ),
                  }}
                />
              </Stack>

              {/* Address Section */}
              <Box sx={{ mt: 3 }}>
                <Typography
                  variant="subtitle1"
                  sx={{
                    fontWeight: 700,
                    mb: 2,
                    display: "flex",
                    alignItems: "center",
                    gap: 1,
                    color: theme.palette.primary.main,
                    fontSize: { xs: "0.95rem", sm: "1rem" },
                  }}
                >
                  <PlaceOutlinedIcon fontSize="small" />
                  Address Information
                </Typography>

                <Stack spacing={2}>
                  <FormControl fullWidth>
                    <InputLabel>Region</InputLabel>
                    <Select
                      label="Region"
                      value={address.region}
                      onChange={handleRegionChange}
                    >
                      <MenuItem disabled value="">
                        — Select Region —
                      </MenuItem>
                      {regionList.map((r) => (
                        <MenuItem key={r.region_code} value={r.region_name}>
                          {r.region_name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <FormControl fullWidth disabled={!provinceList.length}>
                    <InputLabel>Province</InputLabel>
                    <Select
                      label="Province"
                      value={address.province}
                      onChange={handleProvinceChange}
                    >
                      {provinceList.map((p) => (
                        <MenuItem key={p.province_code} value={p.province_name}>
                          {p.province_name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <FormControl fullWidth disabled={!cityList.length}>
                    <InputLabel>City / Municipality</InputLabel>
                    <Select
                      label="City / Municipality"
                      value={address.city}
                      onChange={handleCityChange}
                    >
                      {cityList.map((c) => (
                        <MenuItem key={c.city_code} value={c.city_name}>
                          {c.city_name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <FormControl fullWidth disabled={!barangayList.length}>
                    <InputLabel>Barangay</InputLabel>
                    <Select
                      label="Barangay"
                      value={address.barangay}
                      onChange={handleBarangayChange}
                    >
                      {barangayList.map((b) => (
                        <MenuItem key={b.brgy_code} value={b.brgy_name}>
                          {b.brgy_name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Stack>
              </Box>

              {/* Buttons */}
              <Stack
                direction={isMobile ? "column" : "row"}
                justifyContent="flex-end"
                alignItems={isMobile ? "stretch" : "center"}
                spacing={2}
                sx={{ mt: 4 }}
              >
                <Button
                  variant="outlined"
                  startIcon={<CancelRoundedIcon />}
                  onClick={() => navigate("/")}
                  fullWidth={isMobile}
                  sx={{
                    textTransform: "none",
                    fontWeight: 600,
                    color: "text.secondary",
                    "&:hover": { color: "error.main" },
                  }}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="contained"
                  startIcon={<SaveRoundedIcon />}
                  fullWidth={isMobile}
                  sx={{
                    borderRadius: 2,
                    textTransform: "none",
                    fontWeight: 700,
                    px: 3,
                    py: 1.2,
                    background:
                      "linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)",
                    boxShadow:
                      mode === "light"
                        ? "0 4px 14px rgba(99,102,241,0.3)"
                        : "0 4px 18px rgba(139,92,246,0.4)",
                    "&:hover": {
                      background:
                        "linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%)",
                      transform: "translateY(-2px)",
                    },
                  }}
                >
                  Register
                </Button>
              </Stack>
            </form>

            <Typography
              variant="body2"
              align="center"
              sx={{
                mt: 3,
                color: theme.palette.text.secondary,
                fontSize: { xs: "0.85rem", sm: "0.95rem" },
              }}
            >
              Already have an account?{" "}
              <Link
                to="/"
                style={{
                  textDecoration: "none",
                  color: theme.palette.primary.main,
                  fontWeight: 600,
                }}
              >
                Log in
              </Link>
            </Typography>
          </Box>
        </Paper>
      </Container>
    </Box>
  );
}
