import React, { useState, useEffect } from "react";
import {
  Box,
  Button,
  Typography,
  Stack,
  useTheme,
  Fade,
  alpha,
  Dialog,
  DialogTitle,
  DialogContent,
  List,
  ListItemButton,
  ListItemText,
  IconButton,
  CircularProgress,
} from "@mui/material";
import logo from "/web-app-manifest-192x192.png"
import MapRoundedIcon from "@mui/icons-material/MapRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import { useNavigate } from "react-router-dom";
import publicApi from "../../api/publicApi";

export default function LandingPage () {
  const theme = useTheme();
  const navigate = useNavigate();
  const [chooseOpen, setChooseOpen] = useState(false);
  const [entrances, setEntrances] = useState([]);
  const [loading, setLoading] = useState(false);

  const isLight = theme.palette.mode === "light";

  useEffect(() => {
    const fetchEntrances = async () => {
      try {
        setLoading(true);
        const res = await publicApi.getEntrances();
        console.log('response to get entrance' + res.data)
        setEntrances(res.data);
      } catch (err) {
        console.error("Failed to load entrances:", err);
      } finally {
        setLoading(false);
      }
    };
    if (chooseOpen && entrances.length === 0) fetchEntrances();
  }, [chooseOpen]);

  return (
    <Fade in timeout={600}>
      <Box
        sx={{
          minHeight: "100vh",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          textAlign: "center",
          background: isLight
            ? "linear-gradient(180deg,#c7cdf5 0%,#b8bef0 100%)"
            : "linear-gradient(180deg,#1a1a1f 0%,#18181c 100%)",
          color: isLight ? "#fff" : "#e0e0e0",
          px: 3,
        }}
      >
        {/* Logo + App Name */}
        <Stack spacing={1} alignItems="center" sx={{ mb: 8 }}>
          <Box
            sx={{
              width: 100,
              height: 100,
              //borderRadius: "50%",
              //backgroundColor: alpha("#fff", 0.15),
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              //boxShadow: isLight
              //  ? "0 6px 20px rgba(0,0,0,0.15)"
              //  : "0 6px 20px rgba(255,255,255,0.08)",
            }}
          >
              <img
               src={logo}
               alt="GeoMarket Logo"
               style={{
               width: "120%",
               height: "120%",
                objectFit: "contain"
             }}
          />
          </Box>

          <Typography variant="h4" sx={{ fontWeight: 700, color: "#fff" }}>
            GEOMARKET
          </Typography>

          <Typography
            variant="body2"
            sx={{
              maxWidth: 280,
              color: alpha("#fff", 0.85),
              fontSize: "0.95rem",
              mt: 1,
              lineHeight: 1.6,
              fontWeight: 550
            }}
          >
            Welcome to GeoMarket — your public market navigation companion.
          </Typography>
        </Stack>

        {/* Buttons */}
        <Stack spacing={5} sx={{ width: "100%", maxWidth: 280 }}>
          <Button
            fullWidth
            variant="contained"
            startIcon={<MapRoundedIcon />}
            sx={{
              py: 1.4,
              fontWeight: 600,
              textTransform: "none",
              borderRadius: 2,
              backgroundColor: "#fff",
              color: theme.palette.primary.main,
              "&:hover": {
                backgroundColor: alpha("#fff", 0.9),
                transform: "translateY(-2px)",
                boxShadow: "0 6px 16px rgba(0,0,0,0.1)",
              },
              transition: "all 0.3s ease",
            }}
            onClick={() => setChooseOpen(true)}
          >
            View Map
          </Button>

          <Button
            fullWidth
            variant="contained"
            sx={{
              py: 1.4,
              fontWeight: 600,
              textTransform: "none",
              borderRadius: 2,
              backgroundColor: "#000",
              color: "#fff",
              "&:hover": {
                backgroundColor: "#222",
                transform: "translateY(-1px)",
              },
              transition: "all 0.3s ease",
            }}
            onClick={() => navigate("/login")}
          >
            Login For Admin & Vendor
          </Button>
        </Stack>

        {/* Footer */}
        <Typography
          variant="caption"
          sx={{
            position: "absolute",
            bottom: 20,
            color: alpha("#fff", 0.8),
            letterSpacing: 0.3,
          }}
        >
          © {new Date().getFullYear()} GeoMarket
        </Typography>

        {/* 🧭 Entrance Selection Dialog */}
        <Dialog open={chooseOpen} fullWidth maxWidth="xs">
          <DialogTitle>
            Choose Entrance
            <IconButton
              onClick={() => setChooseOpen(false)}
              sx={{ position: "absolute", right: 8, top: 8 }}
            >
              <CloseRoundedIcon />
            </IconButton>
          </DialogTitle>
          <DialogContent dividers>
            {loading ? (
              <Stack alignItems="center" sx={{ py: 4 }}>
                <CircularProgress />
                <Typography sx={{ mt: 2 }}>Loading entrances...</Typography>
              </Stack>
            ) : entrances.length > 0 ? (
              <List>
                {entrances.map((e) => (
                  <ListItemButton
                    key={e.id}
                    onClick={() => {
                      setChooseOpen(false);
                      navigate(`/public/entrance/${e.id}`);
                    }}
                  >
                    <ListItemText primary={e.name} />
                  </ListItemButton>
                ))}
              </List>
            ) : (
              <Typography align="center" sx={{ py: 3 }} color="text.secondary">
                No entrances found.
              </Typography>
            )}
          </DialogContent>
        </Dialog>
      </Box>
    </Fade>
  );
}
