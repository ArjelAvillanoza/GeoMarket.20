// src/pages/LoginPage.jsx
import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { loginUser } from "../../redux/slices/authSlice";
import { useNavigate } from "react-router-dom";
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  InputAdornment,
  Divider,
  Fade,
  IconButton,
  useTheme,
} from "@mui/material";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import EmailOutlinedIcon from "@mui/icons-material/EmailOutlined";
import MapOutlinedIcon from "@mui/icons-material/MapOutlined";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";

export default function LoginPage () {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const theme = useTheme();
  const { loading, error } = useSelector((state) => state.auth);
  const [form, setForm] = useState({ email: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(loginUser(form))
      .unwrap()
      .then((res) => {
        const role = res?.user?.role;
        const segment = role === "ceemo_admin" ? "ceemo" : "vendor";
        navigate(`/dashboard/${segment}`);
      })
      .catch(() => { });
  };

  const isLight = theme.palette.mode === "light";

  return (
    <Fade in timeout={600}>
      <Box
        sx={{
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
          background: isLight
            ? "linear-gradient(180deg, #c7cdf5 0%, #b8bef0 50%, #c7cdf5 100%)"
            : "linear-gradient(180deg, #1a1a1f 0%, #18181c 100%)",
          px: 3,
        }}
      >
        {/* ===== Logo Section ===== */}
        <Box sx={{ textAlign: "center", mb: 4 }}>
          <Box
          >
              <Box
              component="img"
             src="/favicon.svg"
             alt="GeoMarket Logo"
              sx={{
              width: 100,
              height: 100,
              }}
            />
          </Box>
          <Typography
            variant="h5"
            sx={{
              fontWeight: 700,
              color: theme.palette.text.primary,
              letterSpacing: 1,
            }}
          >
            GEOMARKET
          </Typography>
          <Typography
            variant="body2"
            sx={{
              mt: 1,
              color: theme.palette.text.secondary,
              fontSize: "0.95rem",
            }}
          >
            Log in to access your account
          </Typography>
        </Box>

        {/* ===== Login Card ===== */}
        <Paper
          elevation={8}
          sx={{
            p: { xs: 3, sm: 4 },
            width: "100%",
            maxWidth: 400,
            backgroundColor: theme.palette.background.paper,
            boxShadow: "0 6px 18px rgba(0,0,0,0.15)",
          }}
        >
          <Typography
            variant="h6"
            sx={{
              fontWeight: 600,
              textAlign: "center",
              color: theme.palette.primary.main,
              mb: 3,
            }}
          >
            Welcome Back
          </Typography>

          <Box component="form" onSubmit={handleSubmit}>
            {/* Email Field */}
            <TextField
              label="E-mail"
              variant="outlined"
              fullWidth
              margin="normal"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <EmailOutlinedIcon
                      sx={{ color: theme.palette.text.secondary }}
                    />
                  </InputAdornment>
                ),
              }}
            />

            {/* Password Field with Eye Toggle */}
            <TextField
              label="Password"
              type={showPassword ? "text" : "password"}
              variant="outlined"
              fullWidth
              margin="normal"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <LockOutlinedIcon
                      sx={{ color: theme.palette.text.secondary }}
                    />
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() => setShowPassword(!showPassword)}
                      edge="end"
                      size="small"
                    >
                      {showPassword ? <Visibility /> : <VisibilityOff />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />

            {error && (
              <Typography
                color="error"
                variant="body2"
                sx={{ mt: 1, textAlign: "center" }}
              >
                {error}
              </Typography>
            )}

            <Button
              type="submit"
              fullWidth
              variant="contained"
              disabled={loading}
              sx={{
                mt: 3,
                py: 1.3,
                borderRadius: 2,
                textTransform: "none",
                fontWeight: 600,
              }}
            >
              {loading ? "Signing in..." : "Log In"}
            </Button>
          </Box>

          <Divider sx={{ my: 3 }} />

          <Box sx={{ textAlign: "center" }}>
            <Button
              variant="text"
              onClick={() => navigate("/forgot-password")}
              sx={{
                color: theme.palette.primary.main,
                fontWeight: 500,
                textTransform: "none",
              }}
            >
              Forgot Password?
            </Button>
          </Box>
        </Paper>

        {/* ===== Footer Section ===== */}
        <Typography
          variant="caption"
          sx={{
            mt: 5,
            color: theme.palette.text.secondary,
            opacity: 0.7,
            letterSpacing: 0.3,
          }}
        >
          © {new Date().getFullYear()} GeoMarket. All rights reserved.
        </Typography>
      </Box>
    </Fade>
  );
}
