import React, { useEffect, useState, useMemo } from "react";
import userApi from "../../api/userApi";
import {
  Container,
  Typography,
  Table,
  TableHead,
  TableBody,
  TableCell,
  TableRow,
  Button,
  Box,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Avatar,
  Stack,
  TablePagination,
  Breadcrumbs,
  Link,
  InputAdornment,
  useTheme,
  Paper,
  Chip,
  IconButton,
  Tooltip,
  alpha,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Slide,
  Zoom,
} from "@mui/material";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import EditIcon from "@mui/icons-material/Edit";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import PersonAddIcon from "@mui/icons-material/PersonAdd";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CloseIcon from "@mui/icons-material/Close";
import PeopleAltRoundedIcon from "@mui/icons-material/PeopleAltRounded";
import AdminPanelSettingsRoundedIcon from "@mui/icons-material/AdminPanelSettingsRounded";
import StorefrontRoundedIcon from "@mui/icons-material/StorefrontRounded";
import { regions, provinces, cities, barangays } from "select-philippines-address";
import { resolveImageUrl } from "../../utils/url";

const Transition = React.forwardRef(function Transition (props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function CeemoDashboard () {
  const theme = useTheme();

  // States
  const [users, setUsers] = useState([]);
  const [inviteLink, setInviteLink] = useState("");
  const [openInviteDialog, setOpenInviteDialog] = useState(false);
  const [openEdit, setOpenEdit] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [copied, setCopied] = useState(false);
  const [imagePreview, setImagePreview] = useState(null);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    businessName: "",
    role: "vendor",
    profilePicture: null,
    address: {
      region: "",
      province: "",
      city: "",
      barangay: "",
      regionCode: "",
      provinceCode: "",
      cityCode: "",
      barangayCode: "",
    },
  });

  // Cascading select lists
  const [regionList, setRegionList] = useState([]);
  const [provinceList, setProvinceList] = useState([]);
  const [cityList, setCityList] = useState([]);
  const [barangayList, setBarangayList] = useState([]);

  // Pagination and search
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [search, setSearch] = useState("");

  // Fetch data
  const fetchUsers = async () => {
    const res = await userApi.getUsers();
    setUsers(res.data);
  };

  useEffect(() => {
    fetchUsers();
    regions().then(setRegionList);
  }, []);

  // Delete user
  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this user?")) return;
    await userApi.deleteUser(id);
    fetchUsers();
  };

  // Generate invite link
  const handleGenerateLink = async () => {
    try {
      const res = await userApi.generateInvite();
      setInviteLink(res.data.link);
      setOpenInviteDialog(true);
      setCopied(false);
    } catch (err) {
      alert("Failed to generate link: " + err);
    }
  };

  // Copy to clipboard with auto-close
  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(inviteLink);
      setCopied(true);
      setTimeout(() => {
        setOpenInviteDialog(false);
        setTimeout(() => setCopied(false), 300);
      }, 1500);
    } catch (err) {
      console.error("Failed to copy:", err);
    }
  };

  // Edit user
  const handleEdit = async (user) => {
    setSelectedUser(user);
    setImagePreview(null);
    setForm({
      name: user.name || "",
      email: user.email || "",
      phone: user.phone || "",
      businessName: user.businessName || "",
      role: user.role || "vendor",
      profilePicture: null,
      address: user.address || {
        region: "",
        province: "",
        city: "",
        barangay: "",
        regionCode: "",
        provinceCode: "",
        cityCode: "",
        barangayCode: "",
      },
    });

    // Load cascading data
    if (user.address) {
      if (user.address.regionCode) {
        const provs = await provinces(user.address.regionCode);
        setProvinceList(provs);
        if (user.address.provinceCode) {
          const cits = await cities(user.address.provinceCode);
          setCityList(cits);
          if (user.address.cityCode) {
            const brgys = await barangays(user.address.cityCode);
            setBarangayList(brgys);
          }
        }
      }
    }
    setOpenEdit(true);
  };

  // Cascading selects
  const handleRegionChange = async (e) => {
    const regionName = e.target.value;
    const regionData = regionList.find((r) => r.region_name === regionName);
    const code = regionData ? regionData.region_code : "";
    const provs = code ? await provinces(code) : [];
    setProvinceList(provs);
    setCityList([]);
    setBarangayList([]);
    setForm((prev) => ({
      ...prev,
      address: {
        region: regionName,
        regionCode: code,
        province: "",
        provinceCode: "",
        city: "",
        cityCode: "",
        barangay: "",
        barangayCode: "",
      },
    }));
  };

  const handleProvinceChange = async (e) => {
    const provinceName = e.target.value;
    const provinceData = provinceList.find((p) => p.province_name === provinceName);
    const code = provinceData ? provinceData.province_code : "";
    const cits = code ? await cities(code) : [];
    setCityList(cits);
    setBarangayList([]);
    setForm((prev) => ({
      ...prev,
      address: {
        ...prev.address,
        province: provinceName,
        provinceCode: code,
        city: "",
        cityCode: "",
        barangay: "",
        barangayCode: "",
      },
    }));
  };

  const handleCityChange = async (e) => {
    const cityName = e.target.value;
    const cityData = cityList.find((c) => c.city_name === cityName);
    const code = cityData ? cityData.city_code : "";
    const brgys = code ? await barangays(code) : [];
    setBarangayList(brgys);
    setForm((prev) => ({
      ...prev,
      address: {
        ...prev.address,
        city: cityName,
        cityCode: code,
        barangay: "",
        barangayCode: "",
      },
    }));
  };

  const handleBarangayChange = (e) => {
    const brgyName = e.target.value;
    const brgyData = barangayList.find((b) => b.brgy_name === brgyName);
    setForm((prev) => ({
      ...prev,
      address: {
        ...prev.address,
        barangay: brgyName,
        barangayCode: brgyData ? brgyData.brgy_code : "",
      },
    }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files?.[0] || null;
    setForm((prev) => ({ ...prev, profilePicture: file }));

    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    } else {
      setImagePreview(null);
    }
  };

  const handleUpdate = async () => {
    try {
      const formData = new FormData();
      formData.append("name", form.name);
      formData.append("email", form.email);
      formData.append("phone", form.phone);
      formData.append("businessName", form.businessName);
      formData.append("role", form.role);
      formData.append("address", JSON.stringify(form.address));
      if (form.profilePicture) formData.append("profilePicture", form.profilePicture);
      await userApi.updateUser(selectedUser._id, formData);
      alert("✅ User updated successfully!");
      setOpenEdit(false);
      fetchUsers();
    } catch (err) {
      alert("❌ Update failed: " + (err.response?.data?.message || err.message));
    }
  };

  // Filtering + pagination
  const filteredUsers = useMemo(() => {
    const query = search.toLowerCase();
    return users.filter(
      (u) =>
        u.name?.toLowerCase().includes(query) ||
        u.email?.toLowerCase().includes(query) ||
        u.role?.toLowerCase().includes(query)
    );
  }, [users, search]);

  const paginatedUsers = useMemo(() => {
    const start = page * rowsPerPage;
    return filteredUsers.slice(start, start + rowsPerPage);
  }, [filteredUsers, page, rowsPerPage]);

  // Role color mapping
  const getRoleColor = (role) => {
    switch (role?.toLowerCase()) {
      case "admin":
      case "ceemo_admin":
        return "error";
      case "vendor":
        return "primary";
      case "customer":
        return "success";
      default:
        return "default";
    }
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        bgcolor: "background.default",
        pt: { xs: 5, md: 5 },
        p: 6,
      }}
    >


        {/* Header Section */}
        <Box sx={{ mb: 4 }}>
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              flexWrap: "wrap",
              gap: 3,
              mb: 3,
            }}
          >
            <Box>
              <Typography
                variant="h4"
                sx={{
                  fontWeight: 700,
                  mb: 0.5,
                  background:
                    theme.palette.mode === "light"
                      ? "#000000 "
                      : "#ffff",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                }}
              >
                User Management
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Manage and monitor all users in the system
              </Typography>
            </Box>
            <Button
              variant="contained"
              size="large"
              startIcon={<PersonAddIcon />}
              onClick={handleGenerateLink}
              sx={{
                px: 3,
                py: 1.5,
                textTransform: "none",
                fontWeight: 600,
                boxShadow: theme.palette.mode === "light"
                  ? "0 4px 14px rgba(75, 86, 210, 0.25)"
                  : "0 4px 20px rgba(75, 86, 210, 0.4)",
                "&:hover": {
                  transform: "translateY(-2px)",
                  boxShadow: theme.palette.mode === "light"
                    ? "0 6px 20px rgba(75, 86, 210, 0.35)"
                    : "0 6px 24px rgba(75, 86, 210, 0.5)",
                },
                transition: "all 0.3s ease",
              }}
            >
              Generate Invite Link
            </Button>
          </Box>

          {/* Stats Section */}
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "stretch",
              flexWrap: "wrap",
              gap: 3,
              mt: 4,
              mb: 5,
            }}
          >
            {[
              {
                title: "Total Users",
                value: users.length,
                icon: <PeopleAltRoundedIcon sx={{ fontSize: 34 }} />,
                gradientLight: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
                gradientDark: "linear-gradient(135deg, #5b6eea 0%, #8f68f7 100%)",
              },
              {
                title: "Ceemo Admins",
                value: users.filter((u) => u.role === "ceemo_admin" || u.role === "admin").length,
                icon: <AdminPanelSettingsRoundedIcon sx={{ fontSize: 34 }} />,
                gradientLight: "linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%)",
                gradientDark: "linear-gradient(135deg, #fcd34d 0%, #f59e0b 100%)",
              },
              {
                title: "Vendors",
                value: users.filter((u) => u.role === "vendor").length,
                icon: <StorefrontRoundedIcon sx={{ fontSize: 34 }} />,
                gradientLight: "linear-gradient(135deg, #10b981 0%, #059669 100%)",
                gradientDark: "linear-gradient(135deg, #34d399 0%, #059669 100%)",
              },
            ].map((card, i) => (
              <Paper
                key={i}
                elevation={0}
                sx={{
                  flex: "1 1 280px",
                  p: 3,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  background:
                    theme.palette.mode === "light"
                      ? alpha(theme.palette.background.paper, 0.7)
                      : alpha(theme.palette.background.paper, 0.2),
                  backdropFilter: "blur(6px)",
                  border: `1px solid ${theme.palette.divider}`,
                  transition: "all 0.3s ease",
                  "&:hover": {
                    transform: "translateY(-4px)",
                    boxShadow:
                      theme.palette.mode === "light"
                        ? "0 8px 20px rgba(102, 126, 234, 0.25)"
                        : "0 8px 26px rgba(102, 126, 234, 0.35)",
                  },
                }}
              >
                <Box
                  sx={{
                    minWidth: 64,
                    height: 64,
                    borderRadius: "50%",
                    background:
                      theme.palette.mode === "light"
                        ? card.gradientLight
                        : card.gradientDark,
                    color: "#fff",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    boxShadow:
                      theme.palette.mode === "light"
                        ? "0 4px 10px rgba(0,0,0,0.15)"
                        : "0 4px 12px rgba(0,0,0,0.35)",
                  }}
                >
                  {card.icon}
                </Box>
                <Box sx={{ textAlign: "right", flex: 1 }}>
                  <Typography
                    variant="body2"
                    sx={{ fontWeight: 600, color: "text.secondary", mb: 0.4 }}
                  >
                    {card.title}
                  </Typography>
                  <Typography
                    variant="h3"
                    sx={{
                      fontWeight: 700,
                      background: card.gradientLight,
                      WebkitBackgroundClip: "text",
                      WebkitTextFillColor: "transparent",
                      fontSize: { xs: "1.8rem", md: "2.2rem" },
                      lineHeight: 1,
                    }}
                  >
                    {card.value}
                  </Typography>
                </Box>
              </Paper>
            ))}
          </Box>

          {/* Search Bar */}
          <TextField
            placeholder="Search by name, email, or role..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchRoundedIcon sx={{ color: "text.secondary" }} />
                </InputAdornment>
              ),
            }}
            sx={{
              width: "100%",
              "& .MuiOutlinedInput-root": {
                bgcolor: theme.palette.mode === "light" ? "#fff" : alpha(theme.palette.background.paper, 0.6),
                transition: "all 0.3s ease",
                "&:hover": {
                  bgcolor: theme.palette.mode === "light" ? "#fff" : alpha(theme.palette.background.paper, 0.8),
                },
                "&.Mui-focused": {
                  bgcolor: theme.palette.mode === "light" ? "#fff" : theme.palette.background.paper,
                  boxShadow: `0 0 0 2px ${alpha(theme.palette.primary.main, 0.2)}`,
                },
              },
            }}
          />
        </Box>

        {/* Users Table */}
        <Paper
          elevation={0}
          sx={{
            overflow: "hidden",
            border: `1px solid ${theme.palette.divider}`,
            boxShadow: theme.palette.mode === "light"
              ? "0 4px 20px rgba(0,0,0,0.06)"
              : "0 4px 20px rgba(0,0,0,0.4)",
          }}
        >
          <Table>
            <TableHead>
              <TableRow
                sx={{
                  bgcolor: theme.palette.mode === "light"
                    ? alpha(theme.palette.primary.main, 0.05)
                    : alpha(theme.palette.primary.main, 0.15),
                }}
              >
                <TableCell sx={{ fontWeight: 700, fontSize: "0.875rem" }}>User</TableCell>
                <TableCell sx={{ fontWeight: 700, fontSize: "0.875rem" }}>Contact</TableCell>
                <TableCell sx={{ fontWeight: 700, fontSize: "0.875rem" }}>Role</TableCell>
                <TableCell align="right" sx={{ fontWeight: 700, fontSize: "0.875rem" }}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedUsers.map((u) => (
                <TableRow
                  key={u._id}
                  hover
                  sx={{
                    "&:hover": {
                      bgcolor: theme.palette.mode === "light"
                        ? alpha(theme.palette.primary.main, 0.02)
                        : alpha(theme.palette.primary.main, 0.05),
                    },
                    transition: "background-color 0.2s ease",
                  }}
                >
                  <TableCell>
                    <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
                      <Avatar
                        src={resolveImageUrl(u.profilePicture || "/uploads/default-admin.png")}
                        sx={{
                          width: 40,
                          height: 40,
                          border: `2px solid ${theme.palette.divider}`,
                        }}
                      />
                      <Box>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {u.name}
                        </Typography>
                        {u.businessName && (
                          <Typography variant="caption" color="text.secondary">
                            {u.businessName}
                          </Typography>
                        )}
                      </Box>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2">{u.email}</Typography>
                    {u.phone && (
                      <Typography variant="caption" color="text.secondary">
                        {u.phone}
                      </Typography>
                    )}
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={u.role}
                      color={getRoleColor(u.role)}
                      size="small"
                      sx={{
                        textTransform: "capitalize",
                        fontWeight: 600,
                      }}
                    />
                  </TableCell>
                  <TableCell align="right">
                    <Box sx={{ display: "flex", justifyContent: "flex-end", gap: 1 }}>
                      <Tooltip title="Edit user">
                        <IconButton
                          size="small"
                          onClick={() => handleEdit(u)}
                          sx={{
                            color: "primary.main",
                            "&:hover": {
                              bgcolor: alpha(theme.palette.primary.main, 0.1),
                            },
                          }}
                        >
                          <EditIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Delete user">
                        <IconButton
                          size="small"
                          onClick={() => handleDelete(u._id)}
                          sx={{
                            color: "error.main",
                            "&:hover": {
                              bgcolor: alpha(theme.palette.error.main, 0.1),
                            },
                          }}
                        >
                          <DeleteOutlineIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
              {paginatedUsers.length === 0 && (
                <TableRow>
                  <TableCell colSpan={4} align="center" sx={{ py: 8 }}>
                    <Typography variant="body1" color="text.secondary" sx={{ mb: 1 }}>
                      No users found
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {search ? "Try adjusting your search" : "Start by adding users to the system"}
                    </Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>

          <TablePagination
            component="div"
            count={filteredUsers.length}
            page={page}
            onPageChange={(e, newPage) => setPage(newPage)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={(e) => {
              setRowsPerPage(parseInt(e.target.value, 10));
              setPage(0);
            }}
            rowsPerPageOptions={[5, 10, 25, 50]}
            sx={{
              borderTop: `1px solid ${theme.palette.divider}`,
              bgcolor: theme.palette.mode === "light"
                ? alpha(theme.palette.primary.main, 0.02)
                : alpha(theme.palette.primary.main, 0.05),
            }}
          />
        </Paper>

        {/* Invite Link Dialog */}
        <Dialog
          open={openInviteDialog}
          TransitionComponent={Transition}
          onClose={() => setOpenInviteDialog(false)}
          maxWidth="sm"
          fullWidth
          PaperProps={{
            sx: {
              overflow: "hidden",
              bgcolor: theme.palette.mode === "light" ? "#fff" : "#1a1a1a",
              border: theme.palette.mode === "dark" ? "1px solid rgba(139, 92, 246, 0.3)" : "none",
              boxShadow: theme.palette.mode === "dark"
                ? "0 8px 32px rgba(0, 0, 0, 0.8)"
                : "0 8px 32px rgba(0, 0, 0, 0.15)",
            },
          }}
        >
          <Box
            sx={{
              background:
                theme.palette.mode === "light"
                  ? "linear-gradient(135deg, #AFBDF2 0%, #636CCB 100%)"
                  : "linear-gradient(135deg, #AFBDF2 0%, #636CCB 100%)",
              p: 3.5,
              position: "relative",
              boxShadow: theme.palette.mode === "dark" ? "0 4px 20px rgba(139, 92, 246, 0.4)" : "none",
            }}
          >
            <IconButton
              onClick={() => setOpenInviteDialog(false)}
              sx={{
                position: "absolute",
                right: 12,
                top: 12,
                color: "white",
                bgcolor: "rgba(255,255,255,0.1)",
                backdropFilter: "blur(10px)",
                "&:hover": {
                  bgcolor: "rgba(255,255,255,0.2)",
                  transform: "scale(1.05)",
                },
                transition: "all 0.2s ease",
              }}
            >
              <CloseIcon fontSize="small" />
            </IconButton>
            <Box sx={{ display: "flex", alignItems: "center", gap: 2.5 }}>
              <Zoom in={openInviteDialog} style={{ transitionDelay: "100ms" }}>
                <Box
                  sx={{
                    bgcolor: "rgba(255,255,255,0.15)",
                    p: 2,
                    display: "flex",
                    backdropFilter: "blur(10px)",
                    boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
                  }}
                >
                  <CheckCircleIcon sx={{ fontSize: 40, color: "#fff" }} />
                </Box>
              </Zoom>
              <Box>
                <Typography variant="h6" sx={{ fontWeight: 700, mb: 0.5, color: "#fff", fontSize: "1.25rem" }}>
                  Invitation Link Generated!
                </Typography>
                <Typography variant="body2" sx={{ opacity: 0.95, color: "#fff", fontSize: "0.9rem" }}>
                  Share this link with the new vendor
                </Typography>
              </Box>
            </Box>
          </Box>

          <DialogContent sx={{ p: 3.5 }}>
            <Box sx={{ mb: 2.5 }}>
              <Typography
                variant="body2"
                sx={{
                  mb: 1.5,
                  fontWeight: 600,
                  color: theme.palette.mode === "light" ? "text.secondary" : "rgba(255,255,255,0.9)",
                  fontSize: "0.875rem",
                  letterSpacing: "0.5px",
                }}
              >
                Registration Link:
              </Typography>
              <Paper
                variant="outlined"
                sx={{
                  p: 2.5,
                  bgcolor: theme.palette.mode === "light"
                    ? alpha(theme.palette.primary.main, 0.04)
                    : "rgba(30, 30, 40, 0.8)",
                  border: `1.5px solid ${theme.palette.mode === "light"
                    ? alpha(theme.palette.primary.main, 0.2)
                    : "rgba(139, 92, 246, 0.3)"}`,
                  backdropFilter: "blur(10px)",
                  transition: "all 0.3s ease",
                  "&:hover": {
                    borderColor: theme.palette.mode === "light"
                      ? alpha(theme.palette.primary.main, 0.4)
                      : "rgba(139, 92, 246, 0.5)",
                    bgcolor: theme.palette.mode === "light"
                      ? alpha(theme.palette.primary.main, 0.06)
                      : "rgba(30, 30, 40, 0.9)",
                  },
                }}
              >
                <Typography
                  variant="body2"
                  sx={{
                    fontFamily: "monospace",
                    wordBreak: "break-all",
                    color: theme.palette.mode === "light" ? "#667eea" : "#ffffffff",
                    fontWeight: 500,
                    fontSize: "0.9rem",
                    lineHeight: 1.7,
                    letterSpacing: "0.3px",
                  }}
                >
                  {inviteLink}
                </Typography>
              </Paper>
            </Box>

            <Button
              fullWidth
              variant="contained"
              size="large"
              onClick={handleCopyLink}
              disabled={copied}
              startIcon={copied ? <CheckCircleIcon /> : <ContentCopyIcon />}
              sx={{
                py: 1.75,
                textTransform: "none",
                fontWeight: 700,
                fontSize: "1rem",
                letterSpacing: "0.5px",
                background: copied
                  ? "linear-gradient(135deg, #10b981 0%, #059669 100%)"
                  : theme.palette.mode === "light"
                    ? "linear-gradient(135deg, #AFBDF2 0%, #636CCB 100%)"
                    : "linear-gradient(135deg, #AFBDF2 0%, #636CCB 100%)",
                boxShadow: theme.palette.mode === "light"
                  ? "0 4px 16px rgba(75, 86, 210, 0.35)"
                  : "0 4px 20px rgba(139, 92, 246, 0.5)",
                color: "#fff",
                border: theme.palette.mode === "dark" ? "1px solid rgba(255,255,255,0.1)" : "none",
                "&:hover": {
                  background: copied
                    ? "linear-gradient(135deg, #10b981 0%, #059669 100%)"
                    : theme.palette.mode === "light"
                      ? "linear-gradient(135deg, #764ba2 0%, #667eea 100%)"
                      : "linear-gradient(135deg, #a78bfa 0%, #818cf8 100%)",
                  transform: copied ? "none" : "translateY(-3px)",
                  boxShadow: theme.palette.mode === "light"
                    ? "0 6px 24px rgba(75, 86, 210, 0.45)"
                    : "0 6px 28px rgba(139, 92, 246, 0.65)",
                },
                "&:disabled": {
                  background: "linear-gradient(135deg, #10b981 0%, #059669 100%)",
                  color: "#fff",
                  opacity: 1,
                  boxShadow: "0 4px 16px rgba(16, 185, 129, 0.4)",
                },
                "&:active": {
                  transform: "translateY(-1px)",
                },
                transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
              }}
            >
              {copied ? "Copied! Closing..." : "Copy to Clipboard"}
            </Button>
          </DialogContent>
        </Dialog>

        {/* Edit Dialog */}
        <Dialog
          open={openEdit}
          onClose={() => setOpenEdit(false)}
          fullWidth
          maxWidth="md"
          TransitionComponent={Transition}
          PaperProps={{
            sx: {
              background: theme.palette.background.paper,
              border: theme.palette.mode === "dark" ? "1px solid rgba(139, 92, 246, 0.2)" : "none",
              boxShadow: theme.palette.mode === "dark"
                ? "0 8px 32px rgba(0, 0, 0, 0.8)"
                : "0 8px 32px rgba(0, 0, 0, 0.15)",
            },
          }}
        >
          <DialogTitle sx={{ pb: 2, pt: 3, px: 3 }}>
            <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <Box>
                <Typography variant="h5" sx={{ fontWeight: 700, mb: 0.5 }}>
                  Edit User Profile
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Update user information and settings
                </Typography>
              </Box>
              <IconButton
                onClick={() => setOpenEdit(false)}
                sx={{
                  color: "text.secondary",
                  "&:hover": {
                    bgcolor: alpha(theme.palette.error.main, 0.1),
                    color: "error.main",
                  },
                }}
              >
                <CloseIcon />
              </IconButton>
            </Box>
          </DialogTitle>

          <DialogContent sx={{ px: 3, pb: 2 }}>
            {/* Profile Section */}
            <Paper
              elevation={0}
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 3,
                mb: 3,
                p: 3,
                border: `1.5px solid ${theme.palette.divider}`,
                bgcolor: theme.palette.mode === "light"
                  ? alpha(theme.palette.primary.main, 0.03)
                  : alpha(theme.palette.primary.main, 0.08),
                transition: "all 0.3s ease",
                "&:hover": {
                  borderColor: theme.palette.mode === "light"
                    ? alpha(theme.palette.primary.main, 0.3)
                    : alpha(theme.palette.primary.main, 0.4),
                  bgcolor: theme.palette.mode === "light"
                    ? alpha(theme.palette.primary.main, 0.05)
                    : alpha(theme.palette.primary.main, 0.12),
                },
              }}
            >
              <Avatar
                src={
                  imagePreview ||
                  resolveImageUrl(selectedUser?.profilePicture || "/uploads/default-admin.png")
                }
                sx={{
                  width: 90,
                  height: 90,
                  border: `3px solid ${theme.palette.background.paper}`,
                  boxShadow: theme.palette.mode === "light"
                    ? "0 4px 16px rgba(0,0,0,0.12)"
                    : "0 4px 20px rgba(139, 92, 246, 0.3)",
                  transition: "all 0.3s ease",
                }}
              />
              <Box sx={{ flex: 1 }}>
                <Typography
                  variant="subtitle2"
                  sx={{
                    fontWeight: 600,
                    mb: 1,
                    color: theme.palette.mode === "light" ? "text.primary" : "rgba(255,255,255,0.9)",
                  }}
                >
                  Profile Picture
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ display: "block", mb: 1.5 }}>
                  {imagePreview
                    ? "New image selected - Click Save to update"
                    : "Recommended: Square image, at least 200x200px"}
                </Typography>
                <Button
                  component="label"
                  variant="outlined"
                  size="small"
                  startIcon={<PersonAddIcon />}
                  sx={{
                    textTransform: "none",
                    fontWeight: 600,
                    borderColor: theme.palette.mode === "light"
                      ? theme.palette.divider
                      : alpha(theme.palette.primary.main, 0.3),
                    color: theme.palette.mode === "light" ? "text.primary" : "primary.light",
                    "&:hover": {
                      borderColor: "primary.main",
                      bgcolor: alpha(theme.palette.primary.main, 0.08),
                    },
                  }}
                >
                  Choose Image
                  <input
                    type="file"
                    hidden
                    accept="image/*"
                    onChange={handleFileChange}
                  />
                </Button>
              </Box>
            </Paper>

            {/* Form Fields */}
            <Stack spacing={2.5}>
              {/* Personal Information Section */}
              <Box>
                <Typography
                  variant="subtitle2"
                  sx={{
                    fontWeight: 700,
                    mb: 2,
                    color: theme.palette.mode === "light" ? "text.primary" : "rgba(255,255,255,0.95)",
                    display: "flex",
                    alignItems: "center",
                    gap: 1,
                  }}
                >
                  <Box
                    sx={{
                      width: 4,
                      height: 20,
                      bgcolor: "primary.main",
                      borderRadius: 1,
                    }}
                  />
                  Personal Information
                </Typography>
                <Stack spacing={2}>
                  <TextField
                    label="Full Name"
                    fullWidth
                    value={form.name}
                    onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        borderRadius: 2,
                        bgcolor: theme.palette.mode === "light" ? "#fff" : alpha("#fff", 0.02),
                      }
                    }}
                  />
                  <TextField
                    label="Email Address"
                    type="email"
                    fullWidth
                    value={form.email}
                    onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        borderRadius: 2,
                        bgcolor: theme.palette.mode === "light" ? "#fff" : alpha("#fff", 0.02),
                      }
                    }}
                  />
                  <TextField
                    label="Phone Number"
                    fullWidth
                    value={form.phone}
                    onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        borderRadius: 2,
                        bgcolor: theme.palette.mode === "light" ? "#fff" : alpha("#fff", 0.02),
                      }
                    }}
                  />
                </Stack>
              </Box>

              {/* Business Information Section */}
              <Box>
                <Typography
                  variant="subtitle2"
                  sx={{
                    fontWeight: 700,
                    mb: 2,
                    color: theme.palette.mode === "light" ? "text.primary" : "rgba(255,255,255,0.95)",
                    display: "flex",
                    alignItems: "center",
                    gap: 1,
                  }}
                >
                  <Box
                    sx={{
                      width: 4,
                      height: 20,
                      bgcolor: "primary.main",
                      borderRadius: 1,
                    }}
                  />
                  Business Information
                </Typography>
                <Stack spacing={2}>
                  <TextField
                    label="Business Name"
                    fullWidth
                    value={form.businessName}
                    onChange={(e) =>
                      setForm((p) => ({ ...p, businessName: e.target.value }))
                    }
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        borderRadius: 2,
                        bgcolor: theme.palette.mode === "light" ? "#fff" : alpha("#fff", 0.02),
                      }
                    }}
                  />
                  <FormControl fullWidth>
                    <InputLabel>Role</InputLabel>
                    <Select
                      value={form.role}
                      label="Role"
                      onChange={(e) => setForm((p) => ({ ...p, role: e.target.value }))}
                      sx={{
                        borderRadius: 2,
                        bgcolor: theme.palette.mode === "light" ? "#fff" : alpha("#fff", 0.02),
                      }}
                    >
                      <MenuItem value="admin">Admin</MenuItem>
                      <MenuItem value="ceemo_admin">Ceemo Admin</MenuItem>
                      <MenuItem value="vendor">Vendor</MenuItem>
                      <MenuItem value="customer">Customer</MenuItem>
                    </Select>
                  </FormControl>
                </Stack>
              </Box>

              {/* Address Section */}
              <Box>
                <Typography
                  variant="subtitle2"
                  sx={{
                    fontWeight: 700,
                    mb: 2,
                    color: theme.palette.mode === "light" ? "text.primary" : "rgba(255,255,255,0.95)",
                    display: "flex",
                    alignItems: "center",
                    gap: 1,
                  }}
                >
                  <Box
                    sx={{
                      width: 4,
                      height: 20,
                      bgcolor: "primary.main",
                      borderRadius: 1,
                    }}
                  />
                  Address Information
                </Typography>
                <Stack spacing={2}>
                  <FormControl fullWidth>
                    <InputLabel>Region</InputLabel>
                    <Select
                      value={form.address.region}
                      label="Region"
                      onChange={handleRegionChange}
                      sx={{
                        borderRadius: 2,
                        bgcolor: theme.palette.mode === "light" ? "#fff" : alpha("#fff", 0.02),
                      }}
                    >
                      {regionList.map((r) => (
                        <MenuItem key={r.region_code} value={r.region_name}>
                          {r.region_name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <FormControl fullWidth disabled={!provinceList.length}>
                    <InputLabel>Province</InputLabel>
                    <Select
                      value={form.address.province}
                      label="Province"
                      onChange={handleProvinceChange}
                      sx={{
                        borderRadius: 2,
                        bgcolor: theme.palette.mode === "light" ? "#fff" : alpha("#fff", 0.02),
                      }}
                    >
                      {provinceList.map((p) => (
                        <MenuItem key={p.province_code} value={p.province_name}>
                          {p.province_name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <FormControl fullWidth disabled={!cityList.length}>
                    <InputLabel>City/Municipality</InputLabel>
                    <Select
                      value={form.address.city}
                      label="City/Municipality"
                      onChange={handleCityChange}
                      sx={{
                        borderRadius: 2,
                        bgcolor: theme.palette.mode === "light" ? "#fff" : alpha("#fff", 0.02),
                      }}
                    >
                      {cityList.map((c) => (
                        <MenuItem key={c.city_code} value={c.city_name}>
                          {c.city_name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <FormControl fullWidth disabled={!barangayList.length}>
                    <InputLabel>Barangay</InputLabel>
                    <Select
                      value={form.address.barangay}
                      label="Barangay"
                      onChange={handleBarangayChange}
                      sx={{
                        borderRadius: 2,
                        bgcolor: theme.palette.mode === "light" ? "#fff" : alpha("#fff", 0.02),
                      }}
                    >
                      {barangayList.map((b) => (
                        <MenuItem key={b.brgy_code} value={b.brgy_name}>
                          {b.brgy_name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Stack>
              </Box>
            </Stack>
          </DialogContent>

          <DialogActions
            sx={{
              px: 3,
              py: 2.5,
              gap: 1.5,
              borderTop: `1px solid ${theme.palette.divider}`,
              bgcolor: theme.palette.mode === "light"
                ? alpha(theme.palette.primary.main, 0.02)
                : alpha(theme.palette.primary.main, 0.05),
            }}
          >
            <Button
              onClick={() => setOpenEdit(false)}
              size="large"
              sx={{
                borderRadius: 2,
                textTransform: "none",
                px: 3,
                fontWeight: 600,
                color: "text.secondary",
                "&:hover": {
                  bgcolor: alpha(theme.palette.error.main, 0.08),
                  color: "error.main",
                },
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleUpdate}
              variant="contained"
              size="large"
              sx={{
                borderRadius: 2,
                textTransform: "none",
                px: 4,
                fontWeight: 700,
                background: theme.palette.mode === "light"
                  ? "linear-gradient(135deg, #667eea 0%, #764ba2 100%)"
                  : "linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)",
                boxShadow: theme.palette.mode === "light"
                  ? "0 4px 14px rgba(75, 86, 210, 0.3)"
                  : "0 4px 20px rgba(139, 92, 246, 0.4)",
                "&:hover": {
                  background: theme.palette.mode === "light"
                    ? "linear-gradient(135deg, #764ba2 0%, #667eea 100%)"
                    : "linear-gradient(135deg, #a78bfa 0%, #818cf8 100%)",
                  transform: "translateY(-2px)",
                  boxShadow: theme.palette.mode === "light"
                    ? "0 6px 20px rgba(75, 86, 210, 0.4)"
                    : "0 6px 28px rgba(139, 92, 246, 0.5)",
                },
                transition: "all 0.3s ease",
              }}
            >
              Save Changes
            </Button>
          </DialogActions>
        </Dialog>
    </Box>
  );
}