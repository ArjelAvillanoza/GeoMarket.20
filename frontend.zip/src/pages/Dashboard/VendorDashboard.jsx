import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  Paper,
  CircularProgress,
  Stack,
  Divider,
  useTheme,
  alpha,
} from "@mui/material";
import StorefrontRoundedIcon from "@mui/icons-material/StorefrontRounded";
import AttachMoneyRoundedIcon from "@mui/icons-material/AttachMoneyRounded";
import MapRoundedIcon from "@mui/icons-material/MapRounded";
import stallApi from "../../api/stallApi";
import { format } from "date-fns";
import rentalApi from "../../api/rentalApi";


export default function VendorDashboard () {
  const [stall, setStall] = useState(null);
  const [loading, setLoading] = useState(true);
  const theme = useTheme();
  const [coveredUntil, setCoveredUntil] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const [stallsRes, paymentsRes] = await Promise.all([
          stallApi.getMyStalls(),
          rentalApi.getMyPayments(),
        ]);

        if (stallsRes.data?.length) {
          setStall(stallsRes.data[0]);
        }

        const paid = (paymentsRes.data || []).filter(
          (p) => p.status === "paid"
        );

        if (paid.length) {
          // find latest periodEnd among all paid payments
          let latest = null;
          paid.forEach((p) => {
            const end = new Date(p.periodEnd);
            if (!latest || end > latest) latest = end;
          });
          setCoveredUntil(latest);
        }
      } catch (err) {
        console.error("Vendor dashboard load error:", err);
      } finally {
        setLoading(false);
      }
    };

    load();
  }, []);


  if (loading)
    return (
      <Box sx={{ display: "flex", justifyContent: "center", mt: 6 }}>
        <CircularProgress size={28} />
      </Box>
    );

  return (
    <Box
      sx={{
        p: { xs: 2.5, sm: 4 },
        maxWidth: 700,
        mx: "auto",
      }}
    >
      {/* Header */}
      <Typography
        variant="h5"
        sx={{
          fontWeight: 700,
          mb: 2,
          color: theme.palette.text.primary,
          textAlign: { xs: "center", sm: "left" },
        }}
      >
        Welcome Vendor!
      </Typography>

      {/* Stall Card */}
      {stall ? (
        <Paper
          elevation={0}
          sx={{
            p: 3,
            border: `1px solid ${alpha(theme.palette.divider, 0.5)}`,
            background:
              theme.palette.mode === "light"
                ? "#fff"
                : alpha("#1f1f2f", 0.85),
            boxShadow:
              theme.palette.mode === "light"
                ? "0 4px 12px rgba(0,0,0,0.05)"
                : "0 4px 14px rgba(0,0,0,0.4)",
            transition: "all 0.25s ease",
            "&:hover": {
              transform: "translateY(-2px)",
              boxShadow:
                theme.palette.mode === "light"
                  ? "0 6px 18px rgba(0,0,0,0.07)"
                  : "0 6px 20px rgba(0,0,0,0.6)",
            },
          }}
        >
          <Stack direction="row" alignItems="center" spacing={2} mb={2}>
            <Box
              sx={{
                width: 52,
                height: 52,
                borderRadius: 2,
                backgroundColor: theme.palette.primary.main,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "#fff",
              }}
            >
              <StorefrontRoundedIcon fontSize="medium" />
            </Box>
            <Box>
              <Typography
                variant="subtitle1"
                sx={{
                  fontWeight: 700,
                  color: theme.palette.text.primary,
                }}
              >
                {stall.name}
              </Typography>
              <Typography
                variant="body2"
                sx={{
                  color: theme.palette.text.secondary,
                }}
              >
                Layout: {stall.layoutName}
              </Typography>
            </Box>
          </Stack>

          <Divider sx={{ mb: 2 }} />

          <Stack direction="row" alignItems="center" spacing={1.5} mb={1.5}>
            <Typography variant="body2" sx={{ fontWeight: 500 }}>
              Rate: ₱{stall.rate}
            </Typography>
          </Stack>

          {coveredUntil && (
            <Typography variant="body2" color="text.secondary">
              Rent covered until:{" "}
              <strong>{format(coveredUntil, "MMM dd, yyyy")}</strong>
            </Typography>
          )}

        </Paper>
      ) : (
        <Typography
          variant="body2"
          color="text.secondary"
          sx={{ mt: 4, textAlign: "center" }}
        >
          No assigned stall yet.
        </Typography>
      )}
    </Box>
  );
}
