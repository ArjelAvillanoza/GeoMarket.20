// src/hooks/usePathfinder.js
export function usePathfinder(layout) {
  if (!layout) return () => [];

  const nodes = layout.pathNodes || [];
  const edges = layout.pathEdges || [];

  const getNode = (id) => nodes.find((n) => n.id === id);

  const findPath = (fromId, toId) => {
    const dist = {};
    const prev = {};
    const queue = new Set(nodes.map((n) => n.id));

    nodes.forEach((n) => (dist[n.id] = Infinity));
    dist[fromId] = 0;

    while (queue.size) {
      const u = [...queue].reduce((a, b) => (dist[a] < dist[b] ? a : b));
      queue.delete(u);
      if (u === toId) break;

      const neighbors = edges.filter((e) => e.from === u || e.to === u);
      for (const edge of neighbors) {
        const v = edge.from === u ? edge.to : edge.from;
        if (!queue.has(v) || !edge.walkable) continue;
        const alt = dist[u] + edge.weight;
        if (alt < dist[v]) {
          dist[v] = alt;
          prev[v] = u;
        }
      }
    }

    const path = [];
    let u = toId;
    while (u) {
      path.unshift(getNode(u));
      u = prev[u];
    }
    return path;
  };

  return findPath;
}
