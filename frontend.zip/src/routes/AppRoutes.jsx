import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { useSelector } from "react-redux";

import LoginPage from "../pages/Auth/LoginPage";
import RegisterPage from "../pages/Auth/RegisterPage";
import ForgotPasswordPage from "../pages/Auth/ForgotPasswordPage";
import ResetPasswordPage from "../pages/Auth/ResetPasswordPage";
import CeemoDashboard from "../pages/Dashboard/CeemoDashboard";
import VendorDashboard from "../pages/Dashboard/VendorDashboard";
import DashboardLayout from "../layouts/DashboardLayout";
import ProtectedRoute from "./ProtectedRoute";
import ProfilePage from "../pages/Profile/ProfilePage";
import MapLayoutsList from "../pages/MapLayouts/MapLayoutsList";
import MapLayoutEditorPage from "../pages/MapLayouts/MapLayoutEditorPage";
import StallListPage from "../pages/Stalls/StallListPage";
import MyStallPage from "../pages/Vendor/MyStallPage";
import BusinessInfoPage from "../pages/Vendor/BusinessInfoPage";
import LandingPage from "../pages/Auth/LandingPage";
import StallMasterlistPage from "../pages/Stalls/StallMasterlistPage";
import RentalManagementPage from "../pages/Rentals/RentalManagementPage";
import VendorPaymentHistoryPage from "../pages/Rentals/VendorPaymentHistoryPage";

const PublicMapViewLazy = React.lazy(() => import("../pages/Public/PublicMapView"));

function Placeholder ({ text }) {
  return <div style={{ padding: 16 }}>{text}</div>;
}

function DashboardIndexRedirect () {
  const user =
    useSelector((s) => s.auth.user) ||
    (typeof window !== "undefined" &&
      JSON.parse(localStorage.getItem("user") || "null"));
  const role = user?.role || "vendor";
  const seg = role === "ceemo_admin" ? "ceemo" : "vendor";
  return <Navigate to={`/dashboard/${seg}`} replace />;
}

export default function AppRoutes ({ toggleMode }) {
  return (
    <Routes>
      {/* Public routes */}
      <Route path="/" element={<LandingPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/reset-password" element={<ResetPasswordPage />} />
      {/* ✅ Public Map View Route */}
      <Route
        path="/public/entrance/:entranceId"
        element={<React.Suspense fallback={<div>Loading map...</div>}>
          <PublicMapViewLazy />
        </React.Suspense>}
      />


      {/* Protected dashboard */}
      <Route
        path="/dashboard/*"
        element={
          <ProtectedRoute>
            <DashboardLayout toggleMode={toggleMode} />
          </ProtectedRoute>
        }
      >
        {/* Ceemo Routes */}
        <Route index element={<DashboardIndexRedirect />} />
        <Route path="ceemo" element={<CeemoDashboard />} />
        <Route path="ceemo/stalls" element={<StallListPage />} />
        <Route path="ceemo/profile" element={<ProfilePage />} />
        <Route path="ceemo/stall-masterlist" element={<StallMasterlistPage />} />
        <Route path="ceemo/map-layouts" element={<MapLayoutsList />} />
        <Route path="ceemo/map-layouts/:id" element={<MapLayoutEditorPage />} />
        <Route path="ceemo/rentals" element={<RentalManagementPage />} />

        {/* Vendor Routes */}
        <Route path="vendor" element={<VendorDashboard />} />
        <Route path="vendor/stalls" element={<MyStallPage />} />
        <Route path="vendor/profile" element={<ProfilePage />} />
        <Route path="vendor/business" element={<BusinessInfoPage />} />
        <Route path="vendor/payments" element={<VendorPaymentHistoryPage />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
