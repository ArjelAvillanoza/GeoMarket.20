import React, { useEffect, useRef, useState, useCallback } from "react";
import {
  CircularProgress,
  Box,
  Typography,
  IconButton,
  Fade,
  Stack,
} from "@mui/material";
import ChevronLeftRoundedIcon from "@mui/icons-material/ChevronLeftRounded";
import ChevronRightRoundedIcon from "@mui/icons-material/ChevronRightRounded";
import ArrowUpwardIcon from "@mui/icons-material/ArrowUpward";
import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";

let pannellumReady; // promise cache

function ensurePannellum() {
  if (pannellumReady) return pannellumReady;
  pannellumReady = new Promise((resolve, reject) => {
    if (window.pannellum) return resolve();
    const css = document.createElement("link");
    css.rel = "stylesheet";
    css.href = "https://unpkg.com/pannellum/build/pannellum.css";
    const js = document.createElement("script");
    js.src = "https://unpkg.com/pannellum/build/pannellum.js";
    let left = 2;
    const ok = () => (--left === 0 ? resolve() : null);
    css.onload = ok;
    js.onload = ok;
    css.onerror = reject;
    js.onerror = reject;
    document.head.appendChild(css);
    document.body.appendChild(js);
  });
  return pannellumReady;
}

function tinyPreview(src) {
  if (!src) return "";
  const u = new URL(src, window.location.origin);
  u.searchParams.set("w", "320");
  u.searchParams.set("q", "40");
  return u.toString();
}

export default function Street360Viewer({
  src,
  nextViews = [],
  currentId,
  onNavigate,
  height = "100%",
}) {
  const containerRef = useRef(null);
  const viewerRef = useRef(null);

  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [visible, setVisible] = useState(false);
  const [currentIdx, setCurrentIdx] = useState(null);
    useEffect(() => {
  console.log("📍 Street360Viewer:");
  console.log("currentId:", currentId);
  console.log("currentIdx:", currentIdx);
  console.log("nextViews:", nextViews);
}, [currentId, currentIdx, nextViews]);
  // figure out currentIdx from currentId / src
  useEffect(() => {
    if (currentId) {
      const byId = nextViews.findIndex((v) => v?.id === currentId);
      if (byId >= 0) {
        setCurrentIdx(byId);
        return;
      }
    }
    const norm = (s) => (s || "").replace(/\?.*$/, "");
    const idx = nextViews.findIndex((v) => norm(v.imagePath) === norm(src));
    setCurrentIdx(idx >= 0 ? idx : null);
  }, [currentId, src, nextViews]);

  // preload neighbors (forward/back)
  useEffect(() => {
    if (!nextViews.length || currentIdx == null) return;
    [currentIdx - 1, currentIdx + 1]
      .filter((i) => i >= 0 && i < nextViews.length)
      .forEach(async (i) => {
        const url = nextViews[i].imagePath;
        if (!url) return;
        if (url.toLowerCase().endsWith(".json")) {
          try {
            await fetch(url, { cache: "no-store" });
          } catch {}
        } else {
          const im = new Image();
          im.src = url;
        }
      });
  }, [currentIdx, nextViews]);

  const navigateTo = useCallback(
    (off) => {
      if (!nextViews.length || currentIdx == null) return;
      const i = currentIdx + off;
      if (i < 0 || i >= nextViews.length) return;
      onNavigate?.(nextViews[i]);
    },
    [currentIdx, nextViews, onNavigate]
  );

  const navigateToId = useCallback(
    (id) => {
      if (!id) return;
      const t = nextViews.find((v) => v.id === id);
      if (t) onNavigate?.(t);
    },
    [nextViews, onNavigate]
  );

  // create / load pannellum viewer
  useEffect(() => {
    let cancelled;
    let viewer;
    if (!src) {
      setErr("No 360° image available.");
      setVisible(false);
      return;
    }

    setLoading(true);
    setErr("");
    setVisible(false);

    const cleanSrc = src.split("?")[0];
    const isJson = cleanSrc.toLowerCase().endsWith(".json");

    const waitAssets = ensurePannellum();
    const waitImage = isJson
      ? Promise.resolve(true)
      : new Promise((res, rej) => {
          const im = new Image();
          im.onload = () => res(true);
          im.onerror = rej;
          im.src = src;
        });

    Promise.all([waitAssets, waitImage])
      .then(async () => {
        if (cancelled || !window.pannellum) return;
        const el = containerRef.current;
        if (!el) return;

        if (el.viewerInstance?.destroy) {
          try {
            el.viewerInstance.destroy();
          } catch {}
        }

        if (isJson) {
          const cfg = await fetch(src, {
            cache: "no-store",
          }).then((r) => r.json());

          const basePath = cleanSrc.replace(/\/[^/]+\.json$/i, "");
          const baseOpts = {
            autoLoad: true,
            showControls: true,
            compass: false,
            hfov: 95,
          };
          const yaw = cfg?.meta?.initialYaw ?? undefined;
          const pitch = cfg?.meta?.initialPitch ?? undefined;

          viewer = (el.viewerInstance = window.pannellum.viewer(el, {
            ...baseOpts,
            type: "multires",
            multiRes: { ...cfg.multiRes, basePath },
            ...(yaw != null ? { yaw } : {}),
            ...(pitch != null ? { pitch } : {}),
          }));
        } else {
          viewer = (el.viewerInstance = window.pannellum.viewer(el, {
            type: "equirectangular",
            panorama: src,
            autoLoad: true,
            showControls: true,
            compass: false,
            hfov: 95,
            yaw: curr?.initialYaw ?? 0,
            pitch: curr?.initialPitch ?? 0,
            preview: tinyPreview(src),
          }));
        }

        viewerRef.current = viewer;

        setTimeout(() => !cancelled && setVisible(true), 120);
      })
      .catch((e) => {
        console.error("360 load error:", e);
        setErr("⚠️ Failed to load 360° view.");
        setVisible(false);
      })
      .finally(() => !cancelled && setLoading(false));

    return () => {
      cancelled = true;
      if (viewer?.destroy) {
        try {
          viewer.destroy();
        } catch {}
      }
      viewerRef.current = null;
    };
  }, [src]);

  // optional: still allow fine panning with up/down if you want
  const panStep = 10;
  const panBy = (dyaw = 0, dpitch = 0) => {
    const v = viewerRef.current;
    if (!v) return;
    v.setYaw(v.getYaw() + dyaw);
    v.setPitch(v.getPitch() + dpitch);
  };

  // figure which arrows should be visible for current scene
  const curr = currentIdx != null ? nextViews[currentIdx] : null;
const nextPoint =
  currentIdx != null && currentIdx < nextViews.length - 1
    ? nextViews[currentIdx + 1]
    : null;

let direction = null;

if (curr && nextPoint) {
  const dx = nextPoint.x - curr.x;
  const dy = nextPoint.y - curr.y;

  if (Math.abs(dx) > Math.abs(dy)) {
    direction = dx > 0 ? "right" : "left";
  } else {
    direction = "up";
  }
}

  const canForward = currentIdx != null && currentIdx < nextViews.length - 1;
  const canBack = currentIdx != null && currentIdx > 0;

  // Determine whether the adjacent scenes lie to the left/right of the current
  // view using map coordinates (fallback to simple x-comparison). The
  // `MapCanvas` now includes `_side` when available which indicates left/right
  // of the path; prefer that when present.
  // Prefer explicit flags computed in `MapCanvas` when available.
  let hasLeft = !!curr?.hasLeft;
  let hasRight = !!curr?.hasRight;
  if (!hasLeft || !hasRight) {
  if (curr && currentIdx != null) {
  const prev = nextViews[currentIdx - 1];
  const next = nextViews[currentIdx + 1];

  if (prev) {
    const dx = prev.x - curr.x;
    hasLeft = dx < 0;
  }

  if (next) {
    const dx = next.x - curr.x;
    hasRight = dx > 0;
  }
}
}

  return (
    <Box sx={{ width: "100%", height, position: "relative" }}>
      <div
        ref={containerRef}
        style={{
          width: "100%",
          height: "100%",
          borderRadius: 8,
          overflow: "hidden",
          background: "#000",
          opacity: visible ? 1 : 0,
          transition: "opacity 0.25s ease",
        }}
      />

      {loading && (
        <Box
          sx={{
            position: "absolute",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            bgcolor: "rgba(0,0,0,0.3)",
          }}
        >
          <CircularProgress size={48} thickness={4} sx={{ color: "#fff" }} />
        </Box>
      )}

      {!!err && (
        <Typography
          variant="body2"
          sx={{
            position: "absolute",
            bottom: 12,
            left: "50%",
            transform: "translateX(-50%)",
            bgcolor: "rgba(255,255,255,0.9)",
            color: "#d32f2f",
            px: 2,
            py: 1,
            borderRadius: 2,
            fontWeight: 600,
            fontSize: 13,
          }}
        >
          {err}
        </Typography>
      )}
{!loading && visible && currentIdx != null && (
  <>
    {/* 🔙 BACK */}
    {currentIdx > 0 && (
      <IconButton
        onClick={() => {
          const prev = nextViews[currentIdx - 1];
          if (prev) onNavigate(prev);
        }}
        sx={{
          position: "absolute",
          bottom: 40,
          left: "50%",
          transform: "translateX(-50%)",
          bgcolor: "rgba(0,0,0,0.6)",
          color: "#fff",
        }}
      >
        <ArrowDownwardIcon />
      </IconButton>
    )}

    {/* 🔼 / ◀ / ▶ FORWARD */}
    {nextPoint && (
      <IconButton
        onClick={() => onNavigate(nextPoint)} // ALWAYS +1
        sx={{
          position: "absolute",
          top: "70%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          bgcolor: "rgba(0,0,0,0.6)",
          color: "#fff",
        }}
      >
        {direction === "up" && <ArrowUpwardIcon />}
        {direction === "left" && <ArrowBackIcon />}
        {direction === "right" && <ArrowForwardIcon />}
      </IconButton>
    )}
  </>
)}
      {/* You can now remove the old side prev/next arrows if the D-pad replaces them.
          Leaving them here commented for reference. */}
      {/*
      {!loading && visible && nextViews.length > 1 && currentIdx != null && (
        <Fade in>
          <Stack ...> ... </Stack>
        </Fade>
      )}
      */}
    </Box>
  );
}
