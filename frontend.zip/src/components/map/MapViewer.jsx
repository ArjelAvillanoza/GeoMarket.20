import React, {
  useEffect,
  useRef,
  forwardRef,
  useImperativeHandle,
  useMemo,
} from "react";
import {
  Stage,
  Layer,
  Rect,
  Text,
  Line,
  Circle,
  Group,
  RegularPolygon,
} from "react-konva";
import Konva from "konva";
import { Box } from "@mui/material";
import useImage from "use-image";
import { resolveImageUrl } from "../../utils/url";

/* ANGLE */
function getAngle(x1, y1, x2, y2) {
  return (Math.atan2(y2 - y1, x2 - x1) * 180) / Math.PI;
}

/* TURN DETECTION */
function getTurn(p1, p2, p3) {
  const a1 = Math.atan2(p2.y - p1.y, p2.x - p1.x);
  const a2 = Math.atan2(p3.y - p2.y, p3.x - p2.x);

  let diff = (a2 - a1) * (180 / Math.PI);

  if (diff > 180) diff -= 360;
  if (diff < -180) diff += 360;

  // 🔥 IMPORTANT: inverted for canvas
  if (diff < -10) return "RIGHT";
  if (diff > 10) return "LEFT";
  return "STRAIGHT";
}

const MapViewer = forwardRef(function MapViewer(
  { layout, stalls, route, selected, onSelect, activeStreetView },
  ref
) {
  const stageRef = useRef();

  const [bgImage] = useImage(
    layout?.backgroundImage ? resolveImageUrl(layout.backgroundImage) : "",
    "Anonymous"
  );

  useImperativeHandle(ref, () => ({
    getStage: () => stageRef.current?.getStage(),
  }));

  /* FIT */
  useEffect(() => {
    if (!layout?.size || !stageRef.current) return;

    const stage = stageRef.current.getStage();
    const parent = stage.container().parentNode;

    const width = parent.offsetWidth;
    const height = parent.offsetHeight;

    const scale = Math.min(
      width / layout.size.width,
      height / layout.size.height
    );

    stage.width(width);
    stage.height(height);
    stage.scale({ x: scale, y: scale });

    stage.x((width - layout.size.width * scale) / 2);
    stage.y((height - layout.size.height * scale) / 2);
  }, [layout]);

  /* 🔥 FIND CURRENT SEGMENT */
 const segmentData = useMemo(() => {
  console.log("🧭 activeStreetView:", activeStreetView);
  console.log("🧭 route:", route);

  if (!activeStreetView || !route?.points?.length) return null;

  const px = activeStreetView.x;
  const py = activeStreetView.y;
  const pts = route.points;

  let best = null;
  let bestIndex = 0;

  for (let i = 0; i < pts.length - 5; i += 2) {
    const x1 = pts[i], y1 = pts[i + 1];
    const x2 = pts[i + 2], y2 = pts[i + 3];

    const dx = x2 - x1;
    const dy = y2 - y1;
    const len2 = dx * dx + dy * dy || 1;

    let t = ((px - x1) * dx + (py - y1) * dy) / len2;
    t = Math.max(0, Math.min(1, t));

    const projX = x1 + t * dx;
    const projY = y1 + t * dy;
    const dist = Math.hypot(px - projX, py - projY);

    if (!best || dist < best.dist) {
      best = { x1, y1, x2, y2, dist };
      bestIndex = i;
    }
  }

  const result = { ...best, index: bestIndex };

  console.log("📍 segmentData:", result);

  return result;
}, [activeStreetView, route]);


  /* 🔥 FORWARD HEADING */
  const streetHeading = useMemo(() => {
    if (!segmentData) return 0;

    const angle = getAngle(
      segmentData.x1,
      segmentData.y1,
      segmentData.x2,
      segmentData.y2
    );

    return angle + 90; // fix orientation
  }, [segmentData]);

  /* 🔥 TURN DETECTION */
const turnDirection = useMemo(() => {
  if (!segmentData || !route?.points) return "STRAIGHT";

  const i = segmentData.index;
  const pts = route.points;

  if (i + 5 >= pts.length) return "STRAIGHT";

  const p1 = { x: pts[i], y: pts[i + 1] };
  const p2 = { x: pts[i + 2], y: pts[i + 3] };
  const p3 = { x: pts[i + 4], y: pts[i + 5] };

  const turn = getTurn(p1, p2, p3);

  console.log("↩️ turnDirection:", turn);

  return turn;
}, [segmentData, route]);
  /* 🔥 FINAL ROTATION */
  let arrowRotation = streetHeading;

  if (turnDirection === "RIGHT") arrowRotation += 35;
  if (turnDirection === "LEFT") arrowRotation -= 35;

  return (
    <Box sx={{ width: "100%", height: "100%" }}>
      <Stage ref={stageRef} draggable>
        <Layer>
          {bgImage && (
            <Rect
              width={layout.size.width}
              height={layout.size.height}
              fillPatternImage={bgImage}
              opacity={0.3}
            />
          )}

          {route?.points && (
            <Line points={route.points} stroke="#4285f4" strokeWidth={4} />
          )}
        </Layer>

        <Layer>
          {activeStreetView && (
            <Group>
              {/* YOU ARE HERE */}
              <Circle
                x={activeStreetView.x}
                y={activeStreetView.y}
                radius={10}
                fill="#4caf50"
              />

              {/* 🔥 FORWARD ARROW */}
              <RegularPolygon
                x={activeStreetView.x}
                y={activeStreetView.y}
                sides={3}
                radius={10}
                fill="#fff"
                rotation={arrowRotation}
                offsetY={-12}
              />
            </Group>
          )}
        </Layer>
      </Stage>
    </Box>
  );
});

export default MapViewer;